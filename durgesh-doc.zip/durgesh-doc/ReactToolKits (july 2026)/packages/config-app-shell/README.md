# `@msbc/config-app-shell`

`@msbc/config-app-shell` is a reusable React package designed to provide a cohesive application layout, app shell, generic routing, and protected routes. It is ideal for scaffolding micro-frontends or consistent dashboard experiences across a monorepo.

## Table of Contents
1. [Installation / Setup](#installation--setup)
2. [Components](#components)
   - [LayoutRoute](#layoutroute)
   - [ShellRoutes](#shellroutes)
   - [AppShell](#appshell)
   - [AppLayout](#applayout)
3. [Styling](#styling)
4. [Usage Example](#usage-example)

---

## Installation / Setup

Ensure the package is part of your local monorepo workspaces and installed. 

Depending on your bundler settings, you'll need to import the CSS styles alongside the components to correctly format the shell dimensions.

```tsx
import { LayoutRoute, ShellRoutes } from "@msbc/config-app-shell";
// Make sure to import the generic package styles if not handled via Webpack/Vite plugins automatically
import "@msbc/config-app-shell/dist/index.css";
```

---

## Components

### `LayoutRoute`

A wrapper component intended to be used with `react-router-dom` to provide a persistent `Header` and `Sidebar` while allowing the `<Outlet />` to swap the main content dynamically.

**Props (`LayoutProps`)**
- `header` (`React.ReactNode`, optional): Fixed header component.
- `sidebar` (`React.ReactNode`, optional): Fixed sidebar component.

```tsx
import { LayoutRoute } from "@msbc/config-app-shell";

const ProtectedLayout = () => {
  return (
    <LayoutRoute header={<Header />} sidebar={<Sidebar />} />
  );
};
```

### `ShellRoutes`

A helper component to dynamically render a list of React Router `<Route>` instances based on a JSON configuration array. It takes a mapping object of your component functions to resolve string based names.

**Props**
- `routes` (`ShellRoute[]`): Configuration array for rendering routes.
- `components` (`Record<string, React.FC<any>>`): String-to-Component mapping dictionary.

**`ShellRoute` Type Map**
- `path` (`string`): The route URI path (e.g., `"dashboard"`).
- `title` (`string`, optional): A title string mapping.
- `component` (`string`): Key identifying a component in the `components` map prop.
- `config` (`string`, optional): A configuration path prop automatically passed down as `configPath` to the rendered component.
- `index` (`boolean`, optional): Indicates if this is the index route of its parent.

```tsx
<ShellRoutes routes={shellRoutes} components={shellComponents} />
```

### `AppShell`

A higher-level component that wraps the layout in its own `<BrowserRouter>`. Use this for standalone micro-frontends when you **don't** need a global `<BrowserRouter>` wrapped around the entire application in the main `App.tsx`.

**Props (`AppShellProps`)**
- `routes` (`ShellRoute[]`): The configuration array of routes.
- `components` (`Record<string, React.FC<any>>`): String-to-Component mapping dictionary.
- `header` (`React.ReactNode`, optional): Fixed header component.
- `sidebar` (`React.ReactNode`, optional): Fixed sidebar component.

### `AppLayout`

The raw layout container that accepts `header`, `sidebar`, and `children`. Unlike `LayoutRoute` which assumes `<Outlet />` routing, `AppLayout` is a dumb presentation controller for `children`.

**Props (`LayoutProps`)**
- `header`: (`React.ReactNode`, optional)
- `sidebar`: (`React.ReactNode`, optional)
- `children`: (`React.ReactNode`)

---

## Styling

This package ships with a rigid CSS grid/flexbox layout defined in `layout.css`. It uses the following structural classes determining full widths and flex heights:

- `.app-shell-container`
- `.app-shell-sidebar`
- `.app-shell-main`
- `.app-shell-header`
- `.app-shell-content`

---

## Usage Example

Below is a complete, real-world example combining custom Providers, layout styling, and conditional rendering through `@msbc/config-app-shell`.

```tsx
import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { LayoutRoute, ShellRoutes } from "@msbc/config-app-shell";

// Local imports
import { Header } from "./components/Header";
import Sidebar from "./components/sidebar/Sidebar";
import { LandingPage } from "./pages/dashboard/LandingPage";
import Chat from "./pages/captain/Captain";
import UserManagement from "./pages/dashboard/UserManagement";
import UserDetails from "./pages/dashboard/UserDetails";

const ProtectedLayout = () => {
  const navigate = useNavigate();

  useEffect(() => {
    if (window.location.pathname === "/compass/app") {
      navigate("/app/dashboard");
    }
  }, [navigate]);

  return (
    <LayoutRoute header={<Header />} sidebar={<Sidebar />} />
  );
};

const App = () => {
  const shellRoutes = [
    { path: "dashboard", title: "Dashboard", component: "LandingPage" },
    { path: "chat", title: "Captain", component: "Chat" },
    { path: "users", title: "Users", component: "UserManagement" },
    { path: "users/:id", title: "User Details", component: "UserDetails" },
  ];

  const shellComponents = {
    LandingPage,
    Chat,
    UserManagement,
    UserDetails,
  };

  return (
    <BrowserRouter basename="/compass">
      <Routes>
        {/* Unprotected Routes go here */}

        {/* Protected App Shell Layout */}
        <Route path="/app/*" element={<ProtectedLayout />}>
          <Route
            path="*"
            element={<ShellRoutes routes={shellRoutes} components={shellComponents} />}
          />
        </Route>
      </Routes>
    </BrowserRouter>
  );
};

export default App;
```
