import React from "react";
import { Route, Routes } from "react-router-dom";

export interface ShellRoute {
  path: string;              // e.g. "dashboard"
  title?: string;
  component: string;         // key into components map
  config?: string;           // optional JSON path
  index?: boolean;           // allow index route
}

export function ShellRoutes({
  routes,
  components
}: {
  routes: ShellRoute[];
  components: Record<string, React.FC<any>>;
}) {
  return (
    <Routes>
      {routes.map((r) => {
        const Cmp = components[r.component];
        if (!Cmp) {
          const Missing = () => <div>Component not found: {r.component}</div>;
          return r.index ? (
            <Route index key="index-missing" element={<Missing />} />
          ) : (
            <Route key={r.path} path={r.path} element={<Missing />} />
          );
        }
        return r.index ? (
          <Route index key="index" element={<Cmp configPath={r.config} />} />
        ) : (
          <Route key={r.path} path={r.path} element={<Cmp configPath={r.config} />} />
        );
      })}
    </Routes>
  );
}
