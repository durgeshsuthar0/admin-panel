import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AppLayout } from "./AppLayout";

export interface AppShellProps {
  routes: { path: string; title: string; component: string; config?: string }[];
  components: Record<string, React.FC<any>>;
  header?: React.ReactNode;
  sidebar?: React.ReactNode;
}

export const AppShell: React.FC<AppShellProps> = ({
  routes,
  components,
  header,
  sidebar,
}) => {
  return (
    <Router>
      <AppLayout header={header} sidebar={sidebar}>
        <Routes>
          {routes.map((r) => {
            const Component = components[r.component];
            if (!Component)
              return <Route key={r.path} path={r.path} element={<div>Component not found: {r.component}</div>} />;
            return <Route key={r.path} path={r.path} element={<Component configPath={r.config} />} />;
          })}
        </Routes>
      </AppLayout>
    </Router>
  );
};