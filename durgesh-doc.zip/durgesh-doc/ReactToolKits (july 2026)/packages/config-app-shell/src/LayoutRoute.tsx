import React from "react";
import { Outlet } from "react-router-dom";
import "./layout.css";

export interface LayoutProps {
  header?: React.ReactNode;
  sidebar?: React.ReactNode;
  children?: React.ReactNode; // 👈 ADD THIS
}

export const LayoutRoute: React.FC<LayoutProps> = ({
  header,
  sidebar,
  children,
}) => {
  return (
    <div className="app-shell-container">
      <div className="app-shell-sidebar">{sidebar}</div>

      <div className="app-shell-main">
        <div className="app-shell-header">{header}</div>

        <div className="app-shell-content">
          {/* 👇 support BOTH patterns */}
          {children ? children : <Outlet />}
        </div>
      </div>
    </div>
  );
};