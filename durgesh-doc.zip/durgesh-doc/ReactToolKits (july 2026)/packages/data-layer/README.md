# `@msbc/data-layer` Developer Documentation

`@msbc/data-layer` is a React toolkit package designed to standardize API interactions and remote data management across the monorepo. It provides pre-configured Axios instances, reusable hooks for API calls, and scalable state slices.

## Table of Contents

- [Overview](#overview)
- [Installation](#installation)
- [Core Features](#core-features)
  - [useApiRequest Hook](#useapirequest-hook)
  - [Authentication & Refreshing Tokens](#authentication--refreshing-tokens)
- [Usage Examples](#usage-examples)
  - [Fetching Data](#fetching-data)
  - [Dynamic Endpoint Configuration](#dynamic-endpoint-configuration)

---

## Overview

The `data-layer` abstracts away boilerplate networking code, providing developers with a clean `useApiRequest` hook to manage requests, loading states, and API errors simultaneously. It is designed to work with authenticated API sessions and handles token refreshing automatically via `setRefreshEndpoint`.

---

## Core Features

### `useApiRequest` Hook

The primary hook exported by `@msbc/data-layer` to execute REST API requests.

**Parameters:**

The hook takes an object with the following properties (similar to Axios request configs):

- `url` (string): The API endpoint path.
- `method` (string): HTTP method (`"get"`, `"post"`, `"put"`, `"delete"`, etc.).
- `autoFetch` (boolean): If `true`, the request is executed immediately on mount. If `false`, it's deferred until manually invoked via the `execute` function.
- `config` (object): Extended configurations such as `authRequired: true` or specific response settings like `responseType: "blob"`.

**Return Values:**

The hook returns an object containing:

- `execute` (function): The function to trigger the API call manually. Accepts an optional object to override parameters (e.g., dynamic URLs, body payload, or query `params`).
- `loading` (boolean): `true` while the request is in flight.
- `apiError` (Error | null | any): Holds error details if the API call fails.

### Authentication & Refreshing Tokens

You can configure the global API instance to handle token refreshes automatically. Set the refresh endpoint early in your application's lifecycle (e.g., near routing initialization).

```tsx
import { setRefreshEndpoint } from "@msbc/data-layer";

// Configure token refreshing globally
setRefreshEndpoint("/auth/api/v1/users/refresh_token/");
```

You can also manually save or clear the authentication tokens:

```tsx
import { clearTokens, setTokens } from "@msbc/data-layer";

// Save tokens after successful login
setTokens(
  verifyEmail_details.access_token,
  verifyEmail_details.refresh_token
);

// Clear tokens on logout
clearTokens();
```

---

## Usage Examples

### Fetching Data

A typical scenario for handling GET requests using deferred fetching (`autoFetch: false`). Since the data might be binary, you can also inject `responseType: "blob"`.

```tsx
import { useApiRequest } from "@msbc/data-layer";
import { ApiUrls } from "../utils/constants";

export const useDownloadDocument = () => {
  const { execute, loading, apiError } = useApiRequest({
    url: ApiUrls.downloadDocument,
    method: "get",
    autoFetch: false,
    config: { authRequired: true, responseType: "blob" },
  });

  const downloadDocument = async (documentId: string) => {
    try {
      const response = await execute({
        params: { document_id: documentId },
      });
      return response;
    } catch (error) {
      console.error("Document download failed:", error);
      throw error;
    }
  };

  return { downloadDocument, loading, error: apiError };
};
```

**Using the hook in your component:**

```tsx
import { useDownloadDocument } from "../../services/useDownloadDocument";

const MyComponent = ({ documentId }) => {
  const { downloadDocument, loading, error } = useDownloadDocument();

  const handleDownload = async () => {
    try {
      const response = await downloadDocument(documentId);
      // Process binary response...
    } catch (err) {
      // Handle error visually
    }
  };

  return (
    <button onClick={handleDownload} disabled={loading}>
      {loading ? "Downloading..." : "Download"}
    </button>
  );
};
```

### Dynamic Endpoint Configuration

Sometimes the URL isn't known during the hook initialization (for example, if it requires an ID path variable). You can initialize an empty `url` and pass the dynamic generated URL directly to the `execute` function override.

```tsx
import { useApiRequest } from "@msbc/data-layer";
import { ApiUrls } from "../utils/constants";

export const useRetryUploadDocument = () => {
  const { execute, loading, apiError } = useApiRequest({
    url: "",
    method: "post",
    autoFetch: false,
  });

  const retryUploadDocument = (id: string) =>
    execute({ url: ApiUrls.retryUploadDocument(id) });

  return { retryUploadDocument, loading, error: apiError };
};
```
