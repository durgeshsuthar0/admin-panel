import axios, { AxiosInstance, AxiosRequestConfig, InternalAxiosRequestConfig } from 'axios';
import { clearTokens, getAccessToken, refreshAccessToken } from './tokenManager';

/**
 * Augment axios types so we can attach custom flags to request config
 * (authRequired and _retry) and keep strong typing across interceptors.
 */
declare module 'axios' {
  interface AxiosRequestConfig {
    authRequired?: boolean;
    _retry?: boolean;
  }

  interface InternalAxiosRequestConfig {
    authRequired?: boolean;
    _retry?: boolean;
  }
}

// Export augmented types for external use
export interface CustomAxiosRequestConfig extends AxiosRequestConfig {
  authRequired?: boolean;
  _retry?: boolean;
}

/**
 * Factory to create a configured axios instance.
 */
export const createAxiosInstance = (options?: {
  baseURL?: string;
  timeoutMs?: number;
}): AxiosInstance => {
  const instance = axios.create({
    baseURL: options?.baseURL,
    timeout: options?.timeoutMs ?? 120000,
  });

  instance.interceptors.request.use((config: InternalAxiosRequestConfig) => {
    const authRequired = config.authRequired ?? true;

    if (authRequired) {
      const token = getAccessToken();
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }

    return config;
  });

  instance.interceptors.response.use(
    (res) => res,
    async (error) => {
      const originalRequest = error.config as InternalAxiosRequestConfig | undefined;

      const shouldRetry =
        error?.response?.status === 401 &&
        !!originalRequest &&
        !originalRequest._retry &&
        originalRequest.authRequired !== false;

      if (!shouldRetry || !originalRequest) {
        throw normalizeError(error);
      }

      originalRequest._retry = true;

      const newToken = await refreshAccessToken();
      if (!newToken) {
        clearTokens();
        throw normalizeError(error);
      }

      instance.defaults.headers.common.Authorization = `Bearer ${newToken}`;
      originalRequest.headers.Authorization = `Bearer ${newToken}`;

      return instance.request(originalRequest);
    }
  );

  return instance;
};

function normalizeError(error: any) {
  const data = error?.response?.data;
  return {
    status: error?.response?.status,
    message: data?.message || data?.error || error?.message || 'Something went wrong',
    data,
  };
}

const api = createAxiosInstance();
export default api;
