type TokenResponse = {
  access_token: string;
  refresh_token?: string;
  [k: string]: any;
};

export interface TokenManagerOptions {
  storage?: Storage;
  accessKey?: string;
  refreshKey?: string;
  refreshEndpoint?: string;
  fetcher?: typeof fetch;
}

/**
 * Factory to create a reusable/token-manager instance.
 * - Allows injecting storage (sessionStorage/localStorage or in-memory for tests/SSR)
 * - Allows customizing storage keys and refresh endpoint
 * - Returns strongly typed methods
 */
export const createTokenManager = (opts?: Partial<TokenManagerOptions>) => {
  const {
    storage = typeof window !== 'undefined' && window.sessionStorage
      ? window.sessionStorage
      : createMemoryStorage(),
    accessKey = 'access_token',
    refreshKey = 'refresh_token',
    refreshEndpoint = '/auth/refresh',
    fetcher = typeof fetch !== 'undefined' ? fetch.bind(globalThis) : undefined,
  } = opts || {};

  let inMemoryAccess: string | null = null;
  let inMemoryRefresh: string | null = null;
  let currentRefreshEndpoint = refreshEndpoint;
  let redirectUri: string | undefined = undefined;

  const setTokens = (access: string, refresh: string) => {
    inMemoryAccess = access;
    inMemoryRefresh = refresh;
    try {
      storage.setItem(accessKey, access);
      storage.setItem(refreshKey, refresh);
    } catch {
      // storage may be unavailable (e.g. private mode) — keep in memory
    }
  };

  const getAccessToken = (): string | null => {
    if (inMemoryAccess) return inMemoryAccess;
    try {
      return storage.getItem(accessKey);
    } catch {
      return inMemoryAccess ?? null;
    }
  };

  const getRefreshToken = (): string | null => {
    if (inMemoryRefresh) return inMemoryRefresh;
    try {
      return storage.getItem(refreshKey);
    } catch {
      return inMemoryRefresh ?? null;
    }
  };

  const clearTokens = () => {
    inMemoryAccess = null;
    inMemoryRefresh = null;
    try {
      storage.removeItem(accessKey);
      storage.removeItem(refreshKey);
    } catch {
      /* ignore */
    }
  };

  const isAuthenticated = (): boolean => {
    return !!getAccessToken();
  };

  const refreshAccessToken = async <T extends TokenResponse = TokenResponse>(): Promise<
    string | null
  > => {
    const token = getRefreshToken();
    if (!token) return null;
    if (!fetcher) return null;

    try {
      const res = await fetcher(currentRefreshEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: token }),
      });

      if (!res.ok) {
        if (typeof window !== 'undefined' && res.status === 401) {
          window.location.replace(redirectUri!);
        }
        return null;
      }

      const data = (await res.json()) as T;
      if (data && data.access_token) {
        setTokens(data.access_token, data.refresh_token ?? token);
        return data.access_token;
      }
    } catch (err) {
      // caller can inspect logs if needed; swallow here and return null
    }

    return null;
  };

  const getAllTokens = () => ({
    access: getAccessToken(),
    refresh: getRefreshToken(),
  });

  const setRefreshEndpoint = (endpoint: string, redirectUri?: string) => {
    currentRefreshEndpoint = endpoint;
    if (redirectUri) {
      redirectUri = redirectUri;
    }
  };

  return {
    setTokens,
    getAccessToken,
    getRefreshToken,
    clearTokens,
    isAuthenticated,
    refreshAccessToken,
    getAllTokens,
    setRefreshEndpoint,
  } as const;
};

/** default instance for convenience (keeps backward compatibility) */
export const defaultTokenManager = createTokenManager();

/** explicit named exports (stable references for other modules) */
export const setTokens = defaultTokenManager.setTokens;
export const getAccessToken = defaultTokenManager.getAccessToken;
export const getRefreshToken = defaultTokenManager.getRefreshToken;
export const clearTokens = defaultTokenManager.clearTokens;
export const isAuthenticated = defaultTokenManager.isAuthenticated;
export const refreshAccessToken = defaultTokenManager.refreshAccessToken;
export const getAllTokens = defaultTokenManager.getAllTokens;
export const setRefreshEndpoint = defaultTokenManager.setRefreshEndpoint;

/* -- helpers -- */
function createMemoryStorage(): Storage {
  const map = new Map<string, string>();
  return {
    length: 0,
    clear() {
      map.clear();
      // update length
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (this as any).length = map.size;
    },
    getItem(key: string) {
      return map.has(key) ? (map.get(key) as string) : null;
    },
    key(index: number) {
      return Array.from(map.keys())[index] ?? null;
    },
    removeItem(key: string) {
      map.delete(key);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (this as any).length = map.size;
    },
    setItem(key: string, value: string) {
      map.set(key, String(value));
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (this as any).length = map.size;
    },
  } as unknown as Storage;
}
