import type { AxiosInstance, AxiosRequestConfig } from 'axios';
import api from './axiosInstance';

export type ApiRequestConfig = AxiosRequestConfig;

export type ApiClient = {
  get: <TResponse = any, TParams = any>(
    url: string,
    params?: TParams,
    config?: ApiRequestConfig
  ) => Promise<TResponse>;
  post: <TResponse = any, TBody = any>(
    url: string,
    body?: TBody,
    config?: ApiRequestConfig
  ) => Promise<TResponse>;
  put: <TResponse = any, TBody = any>(
    url: string,
    body?: TBody,
    config?: ApiRequestConfig
  ) => Promise<TResponse>;
  patch: <TResponse = any, TBody = any>(
    url: string,
    body?: TBody,
    config?: ApiRequestConfig
  ) => Promise<TResponse>;
  delete: <TResponse = any, TBody = any>(
    url: string,
    body?: TBody,
    config?: ApiRequestConfig
  ) => Promise<TResponse>;
};

const client: AxiosInstance = api;

export const apiClient: ApiClient = {
  async get<TResponse = any, TParams = any>(
    url: string,
    params?: TParams,
    config?: ApiRequestConfig
  ): Promise<TResponse> {
    const mergedConfig = { ...(config || {}), params } as ApiRequestConfig;
    const res = await client.get<TResponse>(url, mergedConfig);
    return res.data;
  },

  async post<TResponse = any, TBody = any>(
    url: string,
    body?: TBody,
    config?: ApiRequestConfig
  ): Promise<TResponse> {
    const res = await client.post<TResponse>(url, body, config);
    return res.data;
  },

  async put<TResponse = any, TBody = any>(
    url: string,
    body?: TBody,
    config?: ApiRequestConfig
  ): Promise<TResponse> {
    const res = await client.put<TResponse>(url, body, config);
    return res.data;
  },

  async patch<TResponse = any, TBody = any>(
    url: string,
    body?: TBody,
    config?: ApiRequestConfig
  ): Promise<TResponse> {
    const res = await client.patch<TResponse>(url, body, config);
    return res.data;
  },

  async delete<TResponse = any, TBody = any>(
    url: string,
    body?: TBody,
    config?: ApiRequestConfig
  ): Promise<TResponse> {
    // axios supports sending body in delete via config.data
    const mergedConfig = { ...(config || {}), data: body } as ApiRequestConfig;
    const res = await client.delete<TResponse>(url, mergedConfig);
    return res.data;
  },
};
