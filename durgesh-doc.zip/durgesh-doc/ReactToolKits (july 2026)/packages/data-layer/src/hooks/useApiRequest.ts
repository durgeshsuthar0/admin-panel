import { useCallback, useEffect, useRef, useState } from 'react';
import { apiClient } from '../api/apiClient';
import type { ApiRequestConfig as _ApiRequestConfig } from '../api/apiClient';

type Method = 'get' | 'post' | 'put' | 'delete' | 'patch';

export interface UseApiOptions<TResponse = any, TParams = any, TBody = any> {
  url: string;
  method?: Method;
  params?: TParams;
  body?: TBody;
  config?: _ApiRequestConfig;
  autoFetch?: boolean;
  isMultipart?: boolean;
}

export type ApiError = {
  status?: number;
  message: string;
  data?: any;
};

/**
 * Shallow merge utility
 */
function merge<T>(base?: T, override?: Partial<T>): T {
  return { ...(base ?? {}), ...(override ?? {}) } as T;
}

/**
 * Generic API hook with auto-merge of params, body, and config.
 */
export function useApiRequest<TResponse = any, TParams = any, TBody = any>({
  url,
  method = 'get',
  params,
  body,
  config,
  autoFetch = true,
  isMultipart = false,
}: UseApiOptions<TResponse, TParams, TBody>) {
  const [data, setData] = useState<TResponse | null>(null);
  const [loading, setLoading] = useState(() => {
    return method == 'get' && autoFetch;
  });
  const [apiError, setApiError] = useState<ApiError>();

  const mountedRef = useRef(true);
  const hasFetchedRef = useRef(false);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const execute = useCallback(
    async (override?: {
      params?: Partial<TParams>;
      body?: Partial<TBody>;
      config?: _ApiRequestConfig;
      url?: string;
      method?: string;
    }): Promise<TResponse> => {
      setLoading(true);
      setApiError(undefined);

      try {
        let response: TResponse;

        const finalParams = merge(params, override?.params);
        const finalBody = isMultipart ? override?.body : merge(body, override?.body);
        const finalConfig = merge(config, override?.config);
        const finalUrl = override?.url ?? url;
        const finalMethod = (override?.method ?? method) as Method;

        switch (finalMethod) {
          case 'get':
            response = await apiClient.get<TResponse, TParams>(
              finalUrl,
              finalParams as TParams,
              finalConfig
            );
            break;

          case 'post':
            if (isMultipart) {
              finalConfig.headers = {
                ...finalConfig.headers,
                'Content-Type': 'multipart/form-data',
              };
            }
            response = await apiClient.post<TResponse, TBody>(
              finalUrl,
              finalBody as TBody,
              finalConfig
            );
            break;

          case 'put':
            response = await apiClient.put<TResponse, TBody>(
              finalUrl,
              finalBody as TBody,
              finalConfig
            );
            break;

          case 'patch':
            response = await apiClient.patch<TResponse, TBody>(
              finalUrl,
              finalBody as TBody,
              finalConfig
            );
            break;

          case 'delete':
            response = await apiClient.delete<TResponse, TBody>(
              finalUrl,
              finalBody as TBody,
              finalConfig
            );
            break;

          default:
            throw new Error(`Unsupported method ${method}`);
        }

        if (mountedRef.current) setData(response);
        return response;
      } catch (err: any) {
        const normalized: ApiError = {
          status: err?.status,
          message: err?.message ?? 'Something went wrong',
          data: err?.data,
        };
        if (mountedRef.current) setApiError(normalized);
        throw err;
      } finally {
        if (mountedRef.current) setLoading(false);
      }
    },
    [url, method, params, body, config, isMultipart]
  );

  useEffect(() => {
    if (!autoFetch) return;
    if (!hasFetchedRef.current) {
      hasFetchedRef.current = true;
      // eslint-disable-next-line @typescript-eslint/no-floating-promises
      execute();
    }
  }, [autoFetch, execute]);

  return {
    data,
    loading,
    apiError,
    execute,
  };
}
