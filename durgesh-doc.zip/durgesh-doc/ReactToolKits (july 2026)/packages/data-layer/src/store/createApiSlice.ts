import { createAsyncThunk, createSlice, type PayloadAction } from '@reduxjs/toolkit';
import type { ApiRequestConfig } from '../api/apiClient';
import { apiClient } from '../api/apiClient';
import { CustomAxiosRequestConfig } from '../api/axiosInstance';

interface ApiState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

/**
 * createApiSlice
 */
export const createApiSlice = <
  TResponse = any,
  TRequestBody = any,
  TParams = any,
  TConfig extends ApiRequestConfig = CustomAxiosRequestConfig
>(
  name: string,
  endpoint: string,
  method: 'get' | 'post' | 'put' | 'delete' = 'get',
  configParams?: TConfig
) => {
  type ThunkArg = { body?: TRequestBody; params?: TParams; config?: TConfig } | undefined;

  const fetchData = createAsyncThunk<TResponse, ThunkArg, { rejectValue: string }>(
    `${name}/fetch`,
    async (arg, { rejectWithValue }) => {
      try {
        const cfg = arg?.config ?? configParams;
        const params = arg?.params;
        const body = arg?.body;

        switch (method) {
          case 'get':
            return await apiClient.get<TResponse, TParams>(
              endpoint,
              params as TParams,
              cfg as ApiRequestConfig
            );
          case 'post':
            return await apiClient.post<TResponse, TRequestBody>(
              endpoint,
              body as TRequestBody,
              cfg as ApiRequestConfig
            );
          case 'put':
            return await apiClient.put<TResponse, TRequestBody>(
              endpoint,
              body as TRequestBody,
              cfg as ApiRequestConfig
            );
          case 'delete':
            return await apiClient.delete<TResponse, TRequestBody>(
              endpoint,
              body as TRequestBody,
              cfg as ApiRequestConfig
            );
          default:
            return rejectWithValue('Unsupported method') as unknown as TResponse;
        }
      } catch (err: any) {
        return rejectWithValue(err?.message ?? 'Request failed');
      }
    }
  );

  const initialState: ApiState<TResponse> = {
    data: null,
    loading: false,
    error: null,
  };

  const slice = createSlice({
    name,
    initialState,
    reducers: {},
    extraReducers: (builder) => {
      builder
        .addCase(fetchData.pending, (state) => {
          state.loading = true;
          state.error = null;
        })
        .addCase(fetchData.fulfilled, (state, action: PayloadAction<TResponse>) => {
          state.loading = false;
          state.data = action.payload as unknown as typeof state.data;
        })
        .addCase(fetchData.rejected, (state, action) => {
          state.loading = false;
          state.error = action.payload ?? action.error.message ?? 'Request failed';
        });
    },
  });

  return {
    reducer: slice.reducer,
    actions: { fetchData },
  } as {
    reducer: typeof slice.reducer;
    actions: { fetchData: typeof fetchData };
  };
};
