import React from "react";
import "./TabNav.scss";
import { TabId, TabsNavProps } from "./TabNav.types";

/**
 * Tabs navigation with optional controlled/uncontrolled state.
 * - Supports keyboard navigation (Arrow keys, Home/End).
 * - Can lazy-render tab panels and optionally keep inactive panels mounted.
 *
 * @example
 * ```tsx
 * import { TabsNav } from "./TabNav";
 *
 * const tabs = [
 *   { id: "overview", label: "Overview", content: <div>Overview</div> },
 *   { id: "details", label: "Details", content: <div>Details</div>, badge: 3 },
 *   { id: "settings", label: "Settings", content: <div>Settings</div>, disabled: true },
 * ];
 *
 * export function Example() {
 *   const [activeId, setActiveId] = React.useState("overview");
 *
 *   return (
 *     <TabsNav
 *       tabs={tabs}
 *       activeId={activeId}
 *       onChange={setActiveId}
 *       lazy
 *       keepAlive={false}
 *     />
 *   );
 * }
 * ```
 */
export function TabsNav({
  tabs,
  activeId,
  onChange,
  defaultActiveId,

  className = "tab-navigation",
  listClassName = "tab-navigation-list",
  itemClassName = "tab-navigation-item focus-ring",
  activeItemClassName = "active",
  badgeClassName = "tab-navigation-badge",
  contentClassName = "tab-navigation-content",

  renderTab,
  renderActiveContent,

  lazy = true,
  keepAlive = false,
}: TabsNavProps) {
  const isControlled = activeId !== undefined;

  const firstEnabled = React.useMemo(
    () => tabs.find((t) => !t.disabled)?.id,
    [tabs]
  );

  const [internalActiveId, setInternalActiveId] = React.useState<TabId | undefined>(
    defaultActiveId ?? firstEnabled ?? tabs[0]?.id
  );

  // Sync when tabs change
  React.useEffect(() => {
    if (isControlled) return;

    const exists = tabs.some(
      (t) => t.id === internalActiveId && !t.disabled
    );

    if (!exists) {
      setInternalActiveId(defaultActiveId ?? firstEnabled ?? tabs[0]?.id);
    }
  }, [tabs, defaultActiveId, firstEnabled, isControlled, internalActiveId]);

  const currentId = isControlled ? activeId : internalActiveId;

  const setActive = (id: TabId) => {
    if (!isControlled) setInternalActiveId(id);
    onChange?.(id);
  };

  /** Keyboard navigation */
  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    const enabledTabs = tabs.filter((t) => !t.disabled);
    const idx = enabledTabs.findIndex((t) => t.id === currentId);
    if (idx < 0) return;

    const go = (nextIdx: number) => setActive(enabledTabs[nextIdx].id);

    switch (e.key) {
      case "ArrowRight":
      case "ArrowDown":
        e.preventDefault();
        go((idx + 1) % enabledTabs.length);
        break;
      case "ArrowLeft":
      case "ArrowUp":
        e.preventDefault();
        go((idx - 1 + enabledTabs.length) % enabledTabs.length);
        break;
      case "Home":
        e.preventDefault();
        go(0);
        break;
      case "End":
        e.preventDefault();
        go(enabledTabs.length - 1);
        break;
      default:
        break;
    }
  };

  /** Lazy tracking */
  const [visited, setVisited] = React.useState<Set<TabId>>(
    () => new Set(currentId != null ? [currentId] : [])
  );

  React.useEffect(() => {
    if (currentId == null) return;
    setVisited((prev) => {
      if (prev.has(currentId)) return prev;
      const next = new Set(prev);
      next.add(currentId);
      return next;
    });
  }, [currentId]);

  const shouldRender = (tabId: TabId) =>
    !lazy || tabId === currentId || visited.has(tabId);

  return (
    <nav className={className}>
      {/* TAB LIST */}
      <div
        className={listClassName}
        role="tablist"
        aria-orientation="horizontal"
        onKeyDown={handleKeyDown}
      >
        {tabs.map((tab) => {
          const isActive = tab.id === currentId;

          const classes = [
            itemClassName,
            isActive ? activeItemClassName : "",
          ]
            .filter(Boolean)
            .join(" ");

          if (renderTab) {
            return (
              <React.Fragment key={String(tab.id)}>
                {renderTab({
                  tab,
                  isActive,
                  setActive,
                  className: classes,
                })}
              </React.Fragment>
            );
          }

          return (
            <button
              key={String(tab.id)}
              type="button"
              role="tab"
              className={classes}
              aria-selected={isActive}
              aria-current={isActive ? "page" : undefined}
              aria-label={tab.ariaLabel}
              disabled={tab.disabled}
              tabIndex={isActive ? 0 : -1}
              onClick={() => !tab.disabled && setActive(tab.id)}
            >
              {tab.icon}
              <span>{tab.label}</span>
              {tab.badge != null && tab.badge !== "" && (
                <span className={badgeClassName}>{tab.badge}</span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB PANELS */}
      <div className={contentClassName}>
        {tabs.map((tab) => {
          if (!shouldRender(tab.id)) return null;

          const isActive = tab.id === currentId;
          if (!keepAlive && !isActive) return null;

          return (
            <div
              key={String(tab.id)}
              role="tabpanel"
              hidden={!isActive}
              aria-labelledby={String(tab.id)}
            >
              {renderActiveContent
                ? renderActiveContent(tab)
                : tab.content}
            </div>
          );
        })}
      </div>
    </nav>
  );
}
