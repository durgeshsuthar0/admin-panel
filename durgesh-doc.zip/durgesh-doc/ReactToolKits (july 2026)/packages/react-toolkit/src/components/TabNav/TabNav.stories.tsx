import type { Meta, StoryObj } from "@storybook/react";
import React from "react";
import { TabsNav } from "./TabNav";
import { TabsNavProps } from "./TabNav.types";
import { expect, userEvent, within } from 'storybook/test';

const meta: Meta<typeof TabsNav> = {
  title: "Components/TabsNav",
  component: TabsNav,
  parameters: {
    layout: "centered",
  },
  argTypes: {
    lazy: {
      control: "boolean",
    },
    keepAlive: {
      control: "boolean",
    },
  },
};

export default meta;

type Story = StoryObj<typeof TabsNav>;

/* ---------------------------------- */
/* Base Tabs Config                    */
/* ---------------------------------- */

const baseTabs: TabsNavProps["tabs"] = [
  {
    id: "home",
    label: "Home",
    icon: <span>🏠</span>,
    content: <div style={{ padding: 20 }}>Home Content Area</div>,
  },
  {
    id: "info",
    label: "Info",
    icon: <span>ℹ️</span>,
    badge: 5,
    content: <div style={{ padding: 20 }}>Info Content Area</div>,
  },
  {
    id: "settings",
    label: "Settings",
    icon: <span>⚙️</span>,
    content: <div style={{ padding: 20 }}>Settings Content Area</div>,
  },
];

/* ---------------------------------- */
/* 1️⃣ Default (Uncontrolled) Story    */
/* ---------------------------------- */

export const Default: Story = {
  args: {
    tabs: baseTabs,
    defaultActiveId: "home",
    lazy: true,
    keepAlive: false,
  },

    play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    // Home should be visible initially
    await expect(
      canvas.getByText("Home Content Area")
    ).toBeInTheDocument();

    // Click Info tab
    await userEvent.click(canvas.getByRole("tab", { name: /info/i }));

    // Info content should appear
    await expect(
      canvas.getByText("Info Content Area")
    ).toBeInTheDocument();
  },
};

/* ---------------------------------- */
/* 2️⃣ Controlled Mode Story           */
/* ---------------------------------- */

export const Controlled: Story = {
  render: (args) => {
    const [active, setActive] = React.useState("home");

    return (
      <TabsNav
        {...args}
        activeId={active}
        onChange={setActive}
      />
    );
  },
  args: {
    tabs: baseTabs,
    lazy: true,
    keepAlive: false,
  },

   play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    // Click Settings
    await userEvent.click(
      canvas.getByRole("tab", { name: /settings/i })
    );

    // Settings content should appear
    await expect(
      canvas.getByText("Settings Content Area")
    ).toBeInTheDocument();
  },
};

/* ---------------------------------- */
/* 3️⃣ With Disabled Tab               */
/* ---------------------------------- */

export const WithDisabledTab: Story = {
  args: {
    tabs: [
      ...baseTabs,
      {
        id: "disabled",
        label: "Disabled",
        icon: <span>🚫</span>,
        disabled: true,
        content: <div style={{ padding: 20 }}>Disabled Content</div>,
      },
    ],
    defaultActiveId: "home",
  },

    play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    const disabledTab = canvas.getByRole("tab", {
      name: /disabled/i,
    });

    await expect(disabledTab).toBeDisabled();

    // Try clicking (should not activate)
    await userEvent.click(disabledTab);

    await expect(
      canvas.queryByText("Disabled Content")
    ).not.toBeInTheDocument();
  },
};

/* ---------------------------------- */
/* 4️⃣ Keep Alive Example              */
/* ---------------------------------- */

export const KeepAlive: Story = {
  args: {
    tabs: baseTabs,
    defaultActiveId: "home",
    lazy: true,
    keepAlive: true,
  },

    play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    // 1️⃣ Home should be visible initially
    const homeContent = canvas.getByText("Home Content Area");
    await expect(homeContent).toBeInTheDocument();
    await expect(homeContent.closest('[role="tabpanel"]'))
      .not.toHaveAttribute("hidden");

    // 2️⃣ Switch to Info
    await userEvent.click(
      canvas.getByRole("tab", { name: /info/i })
    );

    const infoContent = canvas.getByText("Info Content Area");
    await expect(infoContent).toBeInTheDocument();

    // 3️⃣ Home should still exist in DOM (keepAlive)
    const homeStillInDOM = canvas.getByText("Home Content Area");
    await expect(homeStillInDOM).toBeInTheDocument();

    // But it should now be hidden
    await expect(homeStillInDOM.closest('[role="tabpanel"]'))
      .toHaveAttribute("hidden");

    // 4️⃣ Switch back to Home
    await userEvent.click(
      canvas.getByRole("tab", { name: /home/i })
    );

    // Home should be visible again
    await expect(homeStillInDOM.closest('[role="tabpanel"]'))
      .not.toHaveAttribute("hidden");
  },
};

/* ---------------------------------- */
/* 5️⃣ Custom Render Tab               */
/* ---------------------------------- */

export const CustomRenderTab: Story = {
  render: (args) => (
    <TabsNav
      {...args}
      renderTab={({ tab, isActive, setActive }) => (
        <button
          key={String(tab.id)}
          onClick={() => setActive(tab.id)}
          style={{
            marginRight: 10,
            padding: "8px 16px",
            borderRadius: 20,
            border: "1px solid #ccc",
            cursor: "pointer",
            background: isActive ? "#1976d2" : "#f5f5f5",
            color: isActive ? "#fff" : "#000",
          }}
        >
          {tab.icon} {tab.label}
          {tab.badge ? ` (${tab.badge})` : ""}
        </button>
      )}
    />
  ),
  args: {
    tabs: baseTabs,
    defaultActiveId: "home",
  },


};