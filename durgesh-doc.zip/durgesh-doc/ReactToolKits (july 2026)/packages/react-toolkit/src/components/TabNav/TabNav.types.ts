export type TabId = string | number;

export type TabItem = {
  id: TabId;
  label: string;
  icon?: React.ReactNode;
  badge?: number | string;
  disabled?: boolean;
  ariaLabel?: string;

  /** Tab panel content */
  content?: React.ReactNode;
};

export type RenderTabProps = {
  tab: TabItem;
  isActive: boolean;
  setActive: (id: TabId) => void;
  className: string;
};

export type TabsNavProps = {
  tabs: TabItem[];

  /** Controlled */
  activeId?: TabId;
  onChange?: (id: TabId) => void;

  /** Uncontrolled */
  defaultActiveId?: TabId;

  /** Classes */
  className?: string;
  listClassName?: string;
  itemClassName?: string;
  activeItemClassName?: string;
  badgeClassName?: string;
  contentClassName?: string;

  /** Render hooks */
  renderTab?: (props: RenderTabProps) => React.ReactNode;
  renderActiveContent?: (tab: TabItem) => React.ReactNode;

  /** Lazy behavior */
  lazy?: boolean; // default true
  keepAlive?: boolean; // default false
};
