import React, { CSSProperties, useMemo } from "react";
import chroma from "chroma-js";
import { getMinContrastForeground } from "@msbc/utils";

export type BadgeSize = "sm" | "md" | "lg";

export interface BadgeProps {
  text: string;
  color?: string;
  size?: BadgeSize;
  className?: string;
  style?: CSSProperties;
}

const DEFAULT_COLOR = "#e5e7eb";

const sizeStyles: Record<BadgeSize, CSSProperties> = {
  sm: {
    fontSize: "10px",
    padding: "2px 6px",
  },
  md: {
    fontSize: "12px",
    padding: "4px 8px",
  },
  lg: {
    fontSize: "14px",
    padding: "6px 10px",
  },
};

const normalizeColor = (color?: string) => {
  if (!color) return DEFAULT_COLOR;

  try {
    return chroma(color).hex();
  } catch {
    return DEFAULT_COLOR;
  }
};

export const Badge: React.FC<BadgeProps> = ({
  text,
  color,
  size = "md",
  className,
  style,
}) => {
  const normalizedColor = useMemo(() => normalizeColor(color), [color]);

  const textColor = useMemo(
    () => getMinContrastForeground(normalizedColor),
    [normalizedColor]
  );

  const baseStyle: CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: "999px",
    fontWeight: 500,
    backgroundColor: normalizedColor,
    color: textColor,
    whiteSpace: "nowrap",
  };

  return (
    <span
      className={className}
      style={{
        ...baseStyle,
        ...sizeStyles[size],
        ...style,
      }}
    >
      {text.toUpperCase()}
    </span>
  );
};