import React from "react";
import { Badge } from "../badge/Badge";
import type { FilterChipProps } from "./FilterChip.types";


export const FilterChip: React.FC<FilterChipProps> = ({
  label,
  color,
  selected,
  removable,
  onClick,
  onRemove,
}) => {
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: "6px",
        cursor: onClick ? "pointer" : "default",
        opacity: selected ? 1 : 0.75,
      }}
      onClick={onClick}
    >
      <Badge
        text={label}
        color={selected ? color : "#e5e7eb"}
        style={{
          paddingRight: removable ? "4px" : undefined,
        }}
      />

      {removable && (
        <span
          onClick={(e) => {
            e.stopPropagation();
            onRemove?.();
          }}
          style={{
            cursor: "pointer",
            fontSize: "12px",
            fontWeight: 600,
          }}
        >
          ×
        </span>
      )}
    </span>
  );
};