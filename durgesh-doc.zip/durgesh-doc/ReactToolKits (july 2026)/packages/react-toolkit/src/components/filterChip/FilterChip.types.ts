export interface FilterChipProps {
  label: string;
  color?: string;
  selected?: boolean;
  removable?: boolean;
  onClick?: () => void;
  onRemove?: () => void;
}
