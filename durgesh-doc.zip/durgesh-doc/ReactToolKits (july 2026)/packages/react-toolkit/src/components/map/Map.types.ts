import { Autocomplete, AutocompleteProps, GoogleMap } from '@react-google-maps/api';

// Map.internal.ts
export interface InternalAddressResult {
  formattedAddress: string;
  lat: number;
  lng: number;
  placeId: string;
  postalCode?: string;
  city?: string;
  state?: string;
  country?: string;
}

/* ------------------------------------------------------------------ */
/* Types                                                              */
/* ------------------------------------------------------------------ */

export type AddressKeyMap = Partial<Record<keyof InternalAddressResult, string>>;

export interface MapProps<TExternal = Record<string, any>> {
  className?: string;
  apiKey: string;
  value?: TExternal | null;
  onChange: (val: TExternal) => void;

  keyMap?: AddressKeyMap;

  height?: string | number;
  zoom?: number;
  enableMarkerMove?: boolean;
}
