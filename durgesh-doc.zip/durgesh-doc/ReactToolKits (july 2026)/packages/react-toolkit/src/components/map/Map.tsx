import React, { useEffect, useMemo, useRef, useState } from "react";
import type { MapProps, InternalAddressResult, AddressKeyMap } from "./Map.types";
import {
  GoogleMap,
  Marker,
  Autocomplete,
  useLoadScript
} from "@react-google-maps/api";
import { classname, cns } from "@msbc/utils";
import './Map.scss';
import { MapMarker_svg } from "../../assets/svg";

const containerStyle: React.CSSProperties = {
  width: "100%",
  borderRadius: "8px",
  overflow: "hidden"
};

const libraries: ("places")[] = ["places"];

function mapInternalToExternal<T>(
  internal: InternalAddressResult,
  keyMap?: AddressKeyMap
): T {
  if (!keyMap) return internal as unknown as T;

  const result: any = {};
  Object.keys(keyMap).forEach((internalKey) => {
    const externalKey = keyMap[internalKey as keyof InternalAddressResult];
    if (externalKey) {
      result[externalKey] =
        internal[internalKey as keyof InternalAddressResult];
    }
  });
  return result;
}

function mapExternalToInternal(
  external?: Record<string, any> | null,
  keyMap?: AddressKeyMap
): InternalAddressResult | null {
  if (!external) return null;

  // no mapping → assume already internal
  if (!keyMap) return external as InternalAddressResult;

  const internal: Partial<InternalAddressResult> = {};

  Object.keys(keyMap).forEach((internalKey) => {
    const externalKey = keyMap[internalKey as keyof InternalAddressResult];
    if (externalKey && external[externalKey] !== undefined) {
      internal[internalKey as keyof InternalAddressResult] =
        external[externalKey];
    }
  });

  if (
    typeof internal.lat !== "number" ||
    typeof internal.lng !== "number"
  ) {
    return null;
  }

  return internal as InternalAddressResult;
}

export function Map<TExternal = Record<string, any>>({
  className = '',
  apiKey,
  value,
  onChange,
  keyMap,
  height = "400px",
  zoom = 14,
  enableMarkerMove = true,
}: MapProps<TExternal>) {
  const cn = classname("map");

  const { isLoaded } = useLoadScript({
    googleMapsApiKey: apiKey,
    libraries,
  });

  const autocompleteRef =
    useRef<google.maps.places.Autocomplete | null>(null);

  const internalValue = useMemo(
    () => mapExternalToInternal(value as any, keyMap),
    [value, keyMap]
  );

  const [center, setCenter] = useState(() => ({
    lat: internalValue?.lat ?? 19.076,
    lng: internalValue?.lng ?? 72.8777,
  }));

  useEffect(() => {
    if (!internalValue) return;
    setCenter({
      lat: internalValue.lat,
      lng: internalValue.lng,
    });
  }, [internalValue]);

  function extractAddress(
    place: google.maps.places.PlaceResult
  ): InternalAddressResult {
    const comps = place.address_components || [];

    const get = (type: string) =>
      comps.find((c) => c.types.includes(type))?.long_name || "";

    return {
      formattedAddress: place.formatted_address || "",
      lat: place.geometry?.location?.lat() || 0,
      lng: place.geometry?.location?.lng() || 0,
      placeId: place.place_id || "",
      postalCode: get("postal_code"),
      city: get("locality") || get("administrative_area_level_2"),
      state: get("administrative_area_level_1"),
      country: get("country"),
    };
  }

  function onPlaceChanged() {
    if (!autocompleteRef.current) return;

    const place = autocompleteRef.current.getPlace();
    if (!place || !place.geometry) return;

    const internal = extractAddress(place);

    setCenter({ lat: internal.lat, lng: internal.lng });
    onChange(mapInternalToExternal<TExternal>(internal, keyMap));
  }

  function onMarkerDragEnd(e: google.maps.MapMouseEvent) {
    if (!e.latLng) return;

    const latLng = e.latLng;
    const geocoder = new google.maps.Geocoder();

    geocoder.geocode({ location: latLng }, (results) => {
      if (!results?.[0]) return;

      const place = results[0];
      const internal: InternalAddressResult = {
        formattedAddress: place.formatted_address || "",
        lat: latLng.lat(),
        lng: latLng.lng(),
        placeId: place.place_id || "",
        postalCode: "",
        city: "",
        state: "",
        country: "",
      };

      place.address_components?.forEach((c) => {
        if (c.types.includes("postal_code")) internal.postalCode = c.long_name;
        if (c.types.includes("locality")) internal.city = c.long_name;
        if (c.types.includes("administrative_area_level_1"))
          internal.state = c.long_name;
        if (c.types.includes("country")) internal.country = c.long_name;
      });

      setCenter({ lat: internal.lat, lng: internal.lng });
      onChange(mapInternalToExternal<TExternal>(internal, keyMap));
    });
  }

  if (!isLoaded) return <div>Loading map…</div>;

  return (
    <div className={cns(cn(), className)}>
      <Autocomplete
        className={cn("autocomplete")}
        onLoad={(ref) => (autocompleteRef.current = ref)}
        onPlaceChanged={onPlaceChanged}
      >
        <div className={cn("autocomplete-container")} >
          <div className={cn("autocomplete-icon")}>{MapMarker_svg}</div>
          <input
            type="text"
            placeholder="Search address…"
            defaultValue={internalValue?.formattedAddress}
            className={cn("input")}
          />
        </div>
      </Autocomplete>

      <GoogleMap
        mapContainerStyle={{ ...containerStyle, height }}
        center={center}
        zoom={zoom}
        options={{
          fullscreenControl: false,
          streetViewControl: false,
          zoomControlOptions: { position: google.maps.ControlPosition.RIGHT_BOTTOM },
          mapTypeControlOptions: { position: google.maps.ControlPosition.LEFT_BOTTOM }
        }}
      >
        <Marker
          position={center}
          draggable={enableMarkerMove}
          onDragEnd={onMarkerDragEnd}
        />
      </GoogleMap>
    </div>
  );
}
