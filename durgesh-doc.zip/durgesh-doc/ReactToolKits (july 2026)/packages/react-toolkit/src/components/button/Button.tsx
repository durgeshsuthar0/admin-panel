import * as React from 'react';
import { ButtonProps } from './Button.types';
import { classname, cns } from '@msbc/utils';
import './Button.scss';

export const Button = ({
  className = '',
  text = '',
  onClick,
  variant = "primary",
  size = "medium",
  disabled = false,
  icon,
  iconPosition = "left",
  as: Component = "button",
  ...rest
}: ButtonProps): React.ReactElement => {
  const cn = classname("button");
  const hasIcon = Boolean(icon);

  return (
    <Component
      className={cns(
        cn({
          [`is-${variant}`]: true,
          [`is-${size}`]: true,
          'is-disabled': disabled,
          'has-icon': hasIcon,
          [`icon-${iconPosition}`]: hasIcon
        }),
        className
      )}
      onClick={onClick}
      disabled={disabled}
      {...rest}
    >
      {(icon && iconPosition === "left") && <span className={cn('icon')}>{icon}</span>}
      {text && <span className={cn('text')}>{text}</span>}
      {(icon && iconPosition === "right") && <span className={cn('icon')}>{icon}</span>}
    </Component>
  );
};
