import React, { useState } from "react";
import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button } from "./Button";
import { ButtonProps } from "./Button.types";
import { expect, fn, userEvent, within } from 'storybook/test';

export const ActionsData = {
  onClick: fn(),
};

const meta = {
  component: Button,
  title: 'Components/Button',
  tags: ['autodocs'],
  excludeStories: /.*Data$/,
  args: {
    ...ActionsData,
    text: "Button",
    variant: "primary",
    size: "medium",
    disabled: false,
  },
} satisfies Meta<typeof Button>;

export default meta;
type Story = StoryObj<typeof meta>;

const Template = (args: ButtonProps) => <Button {...args} />;

export const Primary: Story = {
  args: {
    text: "Primary Button",
    variant: "primary",
    size: "medium",
    disabled: false,
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', { name: /Primary Button/i });

    await expect(button).toBeInTheDocument();
    await expect(button).not.toBeDisabled();

    await userEvent.click(button);
    await expect(args.onClick).toHaveBeenCalled();
    await expect(args.onClick).toHaveBeenCalledTimes(1);
  },
};

export const Secondary: Story = {
  render: Template,
  args: {
    text: "Secondary Button",
    variant: "secondary",
    size: "medium",
    disabled: false,
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', { name: /Secondary Button/i });

    await expect(button).toBeInTheDocument();
    await expect(button).not.toBeDisabled();

    await userEvent.click(button);
    await expect(args.onClick).toHaveBeenCalled();
  },
};

export const Ghost: Story = {
  render: Template,
  args: {
    text: "Ghost Button",
    variant: "ghost",
    size: "medium",
    disabled: false,
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', { name: /Ghost Button/i });

    await expect(button).toBeInTheDocument();
    await userEvent.click(button);
    await expect(args.onClick).toHaveBeenCalled();
  },
};

export const Text: Story = {
  render: Template,
  args: {
    text: "Text Button",
    variant: "text",
    size: "medium",
    disabled: false,
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', { name: /Text Button/i });

    await expect(button).toBeInTheDocument();
    await userEvent.click(button);
    await expect(args.onClick).toHaveBeenCalled();
  }
};

export const Disabled: Story = {
  render: Template,
  args: {
    text: "Disabled Button",
    variant: "primary",
    size: "medium",
    disabled: true,
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', { name: /Disabled Button/i });

    await expect(button).toBeInTheDocument();
    await expect(button).toBeDisabled();

    await userEvent.click(button);
    await expect(args.onClick).not.toHaveBeenCalled();
  },
};

export const Sizes: Story = {
  render: () => (
    <div style={{ display: "grid", gap: "1rem", gridTemplateColumns: "repeat(4, auto)", alignItems: 'flex-end', justifyContent: 'flex-start' }}>
      <Button text="Label" variant="primary" size="small" />
      <Button text="Label" variant="primary" size="medium" />
      <Button text="Label" variant="primary" size="large" />
    </div>
  ),
  play: async ({canvasElement, args}) => {
    const canvas = within(canvasElement);

    const buttons = canvas.getAllByRole('button', { name: /Label/i});
    await expect(buttons).toHaveLength(3);

    for (const button of buttons) {
      await expect(button).toBeInTheDocument();
      await expect(button).not.toBeDisabled();
    }
  },
};

