import * as React from "react";
import { ModalProps } from "./Modal.types";
import { classname, cns } from "@msbc/utils";
import { closeButton_svg } from '../../assets/svg';
import "./Modal.scss";

export const Modal = React.forwardRef<HTMLDivElement, ModalProps>(
  ({
    className = "",
    show,
    title,
    size = "md",
    onClose,
    children,
    footer,
    hasCloseButton = true,
    ...rest
  },
    ref
  ): React.ReactElement | null => {
    const cn = classname("modal");

    React.useEffect(() => {
      if (!show) {
        document.documentElement.style.overflow = "";
        return;
      }

      const handleKeyDown = (e: KeyboardEvent) => {
        if (e.key === "Escape") {
          onClose?.(e, 'escapeKeyDown');
        }
      };

      window.addEventListener("keydown", handleKeyDown);
      document.documentElement.style.overflow = "hidden";

      return () => {
        window.removeEventListener("keydown", handleKeyDown);
        document.documentElement.style.overflow = "";
      }
    }, [show, onClose]);

    if (!show) return null;


    return (
      <div role="dialog" className={cn("overlay")}
        onClick={(event) => onClose(event, 'backdropClick')}
      >
        <div
          className={cns(
            cn("container"),
            cn({ [`size-${size}`]: true }),
            className
          )}
          onClick={(e) => e.stopPropagation()}
          {...rest}
        >
          <div className={cn("header")}>
            <h3 className={cn("title")}>{title}</h3>

            {hasCloseButton && (
              <button className={cn("close-btn")} onClick={(e) => onClose(e, "closeButtonClick")}>
                {closeButton_svg}
              </button>
            )}
          </div>

          <div className={cn("body")}>{children}</div>
          {footer && <div className={cn('footer')}>{footer}</div>}
        </div>
      </div>
    );
  }
);