export type ModalSize = 'sm' | 'md' | 'lg' | 'full';

export interface ModalProps extends React.HTMLAttributes<HTMLDivElement> {
  className?: string;
  show: boolean;
  title: string;
  size?: ModalSize;
  onClose: (event?: object, reason?: string) => void;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  hasCloseButton?: boolean;
}
