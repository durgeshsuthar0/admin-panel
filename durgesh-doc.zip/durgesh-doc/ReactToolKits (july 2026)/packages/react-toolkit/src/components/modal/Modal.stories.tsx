import type { Meta, StoryObj } from '@storybook/react';
import { Modal } from "./Modal";
import { ModalProps } from "./Modal.types";
import React, { Children, useState } from "react";
import { Button } from "../button";
import { expect, fn, userEvent, within } from 'storybook/test';


export const ActionsData = {
  onHide: fn(),
};

const meta = {
  title: "Components/Modal",
  component: Modal,
  tags: ["autodocs"],
  excludeStories: /.*Data$/,
  args: {
    ...ActionsData,
    show: false,
    title: "Modal",
    size: "md",
  },
} satisfies Meta<typeof Modal>;

export default meta;
type Story = StoryObj<typeof meta>;

const Template = (args: ModalProps) => {
  const [view, setView] = useState(args.show ?? false);

  const handleHide = () => {
    setView(false);
    args.onHide?.(); // Call the original onHide if provided
  };


  return (
    <>
      <Modal {...args} show={view} onHide={handleHide}>
        <span>This is modal content</span>
      </Modal>

      <Button text="Open Modal" onClick={() => setView(true)} />
    </>
  );
};

export const Default: Story = {
  render: Template,
  args: {
    show: false,
    title: "Default Modal",
    size: "md",
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    const openButton = canvas.getByRole('button', { name: /Open Modal/i });
    await expect(openButton).toBeInTheDocument();
    await userEvent.click(openButton);

    const modal = await canvas.findByRole('dialog');


    const modalTitle = within(modal).getByText('Default Modal');
    await expect(modalTitle).toBeInTheDocument();

    const modalContent = within(modal).getByText('This is modal content');
    await expect(modalContent).toBeInTheDocument();


  },
};

export const Small: Story = {
  render: Template,
  args: {
    show: false,
    title: "Small Modal",
    size: "sm",
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    const openButton = canvas.getByRole('button', { name: /Open Modal/i });
    await expect(openButton).toBeInTheDocument();
    await userEvent.click(openButton);

    const modal = await canvas.findByRole('dialog');

    const modalTitle = within(modal).getByText('Small Modal');
    await expect(modalTitle).toBeInTheDocument();

  },
};

export const Large: Story = {
  render: Template,
  args: {
    show: false,
    title: "Large Modal",
    size: "lg",
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    const openButton = canvas.getByRole('button', { name: /Open Modal/i });
    await expect(openButton).toBeInTheDocument();
    await userEvent.click(openButton);

    const modal = await canvas.findByRole('dialog');

    const modalTitle = within(modal).getByText('Large Modal');
    await expect(modalTitle).toBeInTheDocument();
  },
};

export const Fullscreen: Story = {
  render: Template,
  args: {
    show: false,
    title: "Fullscreen Modal",
    size: "full",
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    const openButton = canvas.getByRole('button', { name: /Open Modal/i });
    await expect(openButton).toBeInTheDocument();
    await userEvent.click(openButton);

    const modal = await canvas.findByRole('dialog');

    const modalTitle = within(modal).getByText('Fullscreen Modal');
    await expect(modalTitle).toBeInTheDocument();
  },
};

export const ActionModal: Story = {
  render: Template,
  args: {
    show: false,
    title: "Action Modal",
    size: "md",
    footer: (
      <>
        <button onClick={() => console.log("Close Clicked")}>Close</button>
        <button onClick={() => console.log("Ok Clicked")}>Ok</button>
      </>
    ),
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);


    const openButton = canvas.getByRole('button', { name: /Open Modal/i });
    await expect(openButton).toBeInTheDocument();
    await userEvent.click(openButton);

    const modal = await canvas.findByRole('dialog');

    const modalTitle = within(modal).getByText('Action Modal');
    await expect(modalTitle).toBeInTheDocument();

    const closeButton = within(modal).getByRole('button', { name: /Close/i });
    const okButton = within(modal).getByRole('button', { name: /Ok/i });

    await expect(closeButton).toBeInTheDocument();
    await expect(okButton).toBeInTheDocument();

    await userEvent.click(closeButton);
    
    await userEvent.click(openButton);
    const reopenedModal = await canvas.findByRole('dialog');
    const reopenedOkButton = within(reopenedModal).getByRole('button', { name: /Ok/i });
    await userEvent.click(reopenedOkButton);

  },
};
