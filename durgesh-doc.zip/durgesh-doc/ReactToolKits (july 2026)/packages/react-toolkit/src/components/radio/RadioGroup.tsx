import { RadioProps } from "./RadioGroup.types";
import { FormFieldWrapper } from "../formFieldWrapper/FormFieldWrapper";
import { useApiRequest } from "@msbc/data-layer";
import { useEffect, useMemo } from "react";
import { classname, cns } from "@msbc/utils";
import "./RadioGroup.scss";

export const RadioGroup = ({
  className = '',
  label,
  options,
  value,
  onChange,
  name,
  isRequired = false,
  error,
  isDisabled = false,
  direction = "vertical",
  api,
  labelKey = '',
  valueKey = '',
  apiResponseMapper,
  loadingComponent,
}: RadioProps) => {

  const cn = classname("radio-component");

  const {
    url,
    method,
    params,
    body,
    config,
    autoFetch
  } = api || {};

  const { data, loading, execute } = useApiRequest({
    url: url || "",
    method: method || "get",
    params: params,
    config: config,
    autoFetch: autoFetch || false,
  });

  const finalOptions = useMemo(() => {
    if (api && data) {
      const rawData: any[] = apiResponseMapper?.(data) || data;
      const apiOptions = Array.isArray(rawData)
        ? rawData.map((item: any) => ({
          label: labelKey ? item[labelKey] : item.label,
          value: valueKey ? item[valueKey] : item.value,
          ...item,
        }))
        : [];
      return apiOptions;
    }
    return options;
  }, [options, data, api]);

  useEffect(() => {
    if (url && !autoFetch) {
      execute({
        url: url,
        params: params,
        body: body,   // optional (only if needed)
        config: config // optional
      });
    }
  }, [url, params, body, config, autoFetch]);

  return (
    <>
      <FormFieldWrapper
        className={cns(className, cn())}
        label={label}
        isRequired={isRequired}
        error={error}
        isDisabled={isDisabled}
      >
        <div
          className={cn('wrapper', {
            [`is-${direction}`]: true
          })}
          data-testid={cn('wrapper')}
          data-direction={direction}
        >
          {/* Render each radio option */}
          {(!loading && finalOptions) ? finalOptions.map((opt) => (
            <label
              key={cn(opt.value)} // to make unique key
              className={cn('option', {
                'is-disabled': isDisabled
              })}
            >
              <input
                className={cn('input')}
                type="radio"
                name={name}
                value={opt.value}
                checked={value === opt.value}
                onChange={() => onChange?.(opt.value)}
                disabled={isDisabled}

              />
              <span className={cn('label')}>{opt.label}</span>
            </label>
          )) : (
            loadingComponent || <p>Loading...</p>
          )}
        </div>
      </FormFieldWrapper>
    </>
  );
};
