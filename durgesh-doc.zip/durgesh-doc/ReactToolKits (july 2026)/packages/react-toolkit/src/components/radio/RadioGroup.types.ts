import type { UseApiOptions } from '@msbc/data-layer';
import React from 'react';

export interface RadioOptions {
  value: string | number;
  label: React.ReactNode;
}

export interface RadioProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange'> {
  label?: React.ReactNode;
  options: RadioOptions[];
  value: string | number;
  checked?: boolean;
  onChange?: (value: string | number) => void;
  name: string;
  isDisabled?: boolean;
  isRequired?: boolean;
  error?: string;
  direction?: 'horizontal' | 'vertical';
  labelKey?: string;
  valueKey?: string;
  api?: UseApiOptions;
  // TODO: remove in favor of apiResponseMapper in future major version
  apiResponseMapper?: (data: any) => any[];
  loadingComponent?: React.ReactNode;
}
