import type { Meta, StoryObj } from '@storybook/react-vite';
import { RadioGroup } from "./RadioGroup";
import { RadioProps } from "./RadioGroup.types";
import React, { useState } from "react";
import { expect, fn, userEvent, within } from 'storybook/test';


export const ActionsData = {
  onChange: fn(),
};

const meta = {
  title: "Components/RadioGroup",
  component: RadioGroup,
  tags: ['autodocs'],
  excludeStories: /.*Data$/,
  args: {
    ...ActionsData,
    label: "Select an Option",
    options: [
      { value: "option1", label: "Option 1" },
      { value: "option2", label: "Option 2" },
      { value: "option3", label: "Option 3" },
    ],
    value: "option1",
    name: "radioGroup",
    isRequired: false,
    isDisabled: false,
    direction: "vertical",
    error: "",
  },
} satisfies Meta<typeof RadioGroup>;

export default meta;
type Story = StoryObj<typeof meta>;

const Template = (args: RadioProps) => <RadioGroup {...args} />;

export const Default: Story = {
  render: Template,
  args: {
    label: "Select an Option",
    name: "defaultRadioGroup",

  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    await expect(canvas.getByText('Select an Option')).toBeInTheDocument();

    const radioInputs = canvas.getAllByRole('radio');
    await expect(radioInputs).toHaveLength(3);

    const option1 = canvas.getByLabelText('Option 1');
    const option2 = canvas.getByLabelText('Option 2');
    const option3 = canvas.getByLabelText('Option 3');

    await expect(option1).toBeChecked();
    await expect(option2).not.toBeChecked();
    await expect(option3).not.toBeChecked();

    await userEvent.click(option1);

    await expect(option1).toBeChecked();
    await expect(option2).not.toBeChecked();
    await expect(option3).not.toBeChecked();
  },
};

export const Horizontal: Story = {
  render: Template,
  args: {
    label: "Horizontal Radio Group",
    direction: "horizontal",
    name: "horizontalRadioGroup",
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    await expect(canvas.getByText('Horizontal Radio Group')).toBeInTheDocument();

    // Check wrapper has data-direction="horizontal"
    const wrapper = canvas.getByTestId('radio-component__wrapper');
    await expect(wrapper).toHaveAttribute('data-direction', 'horizontal');

    const option1 = canvas.getByLabelText('Option 1');
    await userEvent.click(option1);
    await expect(option1).toBeChecked();
  },
};

export const Required: Story = {
  render: Template,
  args: {
    label: "Required Radio Group",
    isRequired: true,
    name: "requiredRadioGroup",
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    const label = canvas.getByText('Required Radio Group');
    await expect(label).toBeInTheDocument();

    try {
      const requiredIndicator = canvas.getByText('*');
      await expect(requiredIndicator).toBeInTheDocument();
    } catch {
    }

    const option1 = canvas.getByLabelText('Option 1');
    await userEvent.click(option1);
    await expect(option1).toBeChecked();
  },
};

export const Disabled: Story = {
  render: Template,
  args: {
    label: "Disabled Radio Group",
    isDisabled: true,
    name: "disabledRadioGroup",
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    await expect(canvas.getByText('Disabled Radio Group')).toBeInTheDocument();

    const radioInputs = canvas.getAllByRole('radio');

    for (const radio of radioInputs) {
      await expect(radio).toBeDisabled();
    }

    const option2 = canvas.getByLabelText('Option 2');
    await userEvent.click(option2);

    await expect(args.onChange).not.toHaveBeenCalled();

    const option1 = canvas.getByLabelText('Option 1');
    await expect(option1).toBeChecked();
    await expect(option2).not.toBeChecked();
  },
};

export const WithError: Story = {
  render: Template,
  args: {
    label: "Radio Group with Error",
    isRequired: true,
    error: "This field is required.",
    name: "errorRadioGroup",
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    await expect(canvas.getByText('Radio Group with Error')).toBeInTheDocument();

    const errorMessage = canvas.getByText('This field is required.');
    await expect(errorMessage).toBeInTheDocument();

    const radioInputs = canvas.getAllByRole('radio');
    await expect(radioInputs).toHaveLength(3);

    const option1 = canvas.getByLabelText('Option 1');
    await userEvent.click(option1);

    await expect(option1).toBeChecked();
  },
};

export const ApiFetch: Story = {
  render: Template,
  args: {
    label: "Radio Group with API Fetch",
    value: "",
    name: "apiRadioGroup",
    isRequired: true,
    labelKey: 'title',
    valueKey: 'userId',
    api: {
      url: "https://jsonplaceholder.typicode.com/posts",
      method: "get",
      params: {},
      autoFetch: true,
    }
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    await expect(canvas.getByText('Radio Group with API Fetch')).toBeInTheDocument();

    try {

      await new Promise(resolve => setTimeout(resolve, 1000));

      const radioInputs = canvas.queryAllByRole('radio');
      if (radioInputs.length > 0) {
        const firstOption = radioInputs[0];
        await userEvent.click(firstOption);
        await expect(args.onChange).toHaveBeenCalled();
      }
    } catch {
      console.log('API fetch test - radio options might still be loading');
    }

    await expect(canvas.getByText('Radio Group with API Fetch')).toBeInTheDocument();
  },
};

export const Demo: Story = {
  render: () => {
    const [selectedValue, setSelectedValue] = useState<string>("option1");
    const [apiSelectedValue, setApiSelectedValue] = useState<string>("");

    const handleChange = (value: string) => {
      setSelectedValue(value);
      console.log("Selected value:", value);
    };

    const handleApiChange = (value: string) => {
      setApiSelectedValue(value);
      console.log("API Selected value:", value);
    };

    return (
      <div style={{ display: "flex", flexDirection: "column", gap: "2rem", padding: "1rem" }}>
        <div>
          <h3>Standard Radio Group</h3>
          <RadioGroup
            label="Choose your favorite fruit"
            options={[
              { value: "apple", label: "Apple" },
              { value: "banana", label: "Banana" },
              { value: "orange", label: "Orange" },
              { value: "grape", label: "Grape" },
            ]}
            value={selectedValue}
            onChange={handleChange}
            name="fruitSelection"
          />
          <p style={{ marginTop: "0.5rem", color: "#666" }}>
            Selected: {selectedValue}
          </p>
        </div>

        <div>
          <h3>Horizontal Layout</h3>
          <RadioGroup
            label="Select payment method"
            options={[
              { value: "credit", label: "Credit Card" },
              { value: "debit", label: "Debit Card" },
              { value: "paypal", label: "PayPal" },
            ]}
            value={selectedValue}
            onChange={handleChange}
            name="paymentMethod"
            direction="horizontal"
          />
        </div>

        <div>
          <h3>With Error State</h3>
          <RadioGroup
            label="Agree to terms and conditions"
            options={[
              { value: "agree", label: "I agree" },
              { value: "disagree", label: "I disagree" },
            ]}
            value={selectedValue}
            onChange={handleChange}
            name="termsAgreement"
            isRequired={true}
            error="Please select an option"
          />
        </div>

        <div>
          <h3>Disabled Radio Group</h3>
          <RadioGroup
            label="Disabled options"
            options={[
              { value: "opt1", label: "Option 1" },
              { value: "opt2", label: "Option 2" },
              { value: "opt3", label: "Option 3" },
            ]}
            value="opt1"
            name="disabledGroup"
            isDisabled={true}
          />
        </div>

        <div>
          <h3>API Fetch Example</h3>
          <RadioGroup
            label="Select a post"
            value={apiSelectedValue}
            onChange={handleApiChange}
            name="apiPosts"
            labelKey="title"
            valueKey="id"
            api={{
              url: "https://jsonplaceholder.typicode.com/posts",
              method: "get",
              params: { _limit: 5 }, // Limit to 5 posts for demo
              autoFetch: true,
            }}
          />
          {apiSelectedValue && (
            <p style={{ marginTop: "0.5rem", color: "#666" }}>
              Selected Post ID: {apiSelectedValue}
            </p>
          )}
        </div>
      </div>
    );
  },
  parameters: {
    docs: {
      disable: true,
    },
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    const fruitLabel = canvas.getByText('Choose your favorite fruit');
    await expect(fruitLabel).toBeInTheDocument();

    const bananaRadio = canvas.getByLabelText('Banana');
    await userEvent.click(bananaRadio);
    await expect(bananaRadio).toBeChecked();

    const selectedText = await canvas.findByText(/Selected: banana/i);
    await expect(selectedText).toBeInTheDocument();

    const paymentLabel = canvas.getByText('Select payment method');
    await expect(paymentLabel).toBeInTheDocument();

    const paypalRadio = canvas.getByLabelText('PayPal');
    await userEvent.click(paypalRadio);
    await expect(paypalRadio).toBeChecked();

    const termsLabel = canvas.getByText('Agree to terms and conditions');
    await expect(termsLabel).toBeInTheDocument();

    const errorMessage = canvas.getByText('Please select an option');
    await expect(errorMessage).toBeInTheDocument();

    const agreeRadio = canvas.getByLabelText('I agree');
    await userEvent.click(agreeRadio);
    await expect(agreeRadio).toBeChecked();

    const disabledLabel = canvas.getByText('Disabled options');
    await expect(disabledLabel).toBeInTheDocument();

    const disabledOption2 = canvas.getByLabelText('Option 2');
    await expect(disabledOption2).toBeDisabled();

    const apiLabel = canvas.getByText('Select a post');
    await expect(apiLabel).toBeInTheDocument();
    const option = canvas.getByLabelText('qui est esse');
    await userEvent.click(option);
    await expect(option).toBeChecked();

  },
};