export type FilterItem = {
  field: string;
  type: string;
  value: string;
  group: string;
};
export interface FilterModalProps {
  className?: string;
  isOpen: boolean;
  onClose: () => void;
  filterTitle?: React.ReactNode;
  onApplyFilter: (filters: any) => void;
  onClearFilter: () => void;
  selectedFilters: FilterItem[];
  fieldInfo?: Array<
    Array<{
      key: string;
      label: string;
      field: string;
      type: 'text' | 'int' | 'date' | 'phone' | 'bool';
      condition?: string;
    }>
  >;
  fieldTypeInfo?: {
    text: Array<{ lookup_key: string; info: string }>;
    int: Array<{ lookup_key: string; info: string }>;
    date: Array<{ lookup_key: string; info: string }>;
    phone: Array<{ lookup_key: string; info: string }>;
    bool: Array<{ lookup_key: string; info: string }>;
  };
  booleanOptions?: Array<{ label: string; value: string }>;
  customBooleanOptions?: Record<string, Array<{ label: string; value: string }>>;
}

export interface FilterRowField {
  field: string;
  type: string;
  value: string;
  id: number;
  fieldType: string;
}
