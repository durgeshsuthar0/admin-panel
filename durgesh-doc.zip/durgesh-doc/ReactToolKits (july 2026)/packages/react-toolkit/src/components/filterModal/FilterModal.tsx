import React, { useEffect, useRef, useState } from 'react';
import { classname, cns } from '@msbc/utils';
import './FilterModal.scss';
import { Input } from '../input';
import { DatePicker } from '../datepicker';
import { RadioGroup } from '../radio';
import { Button } from '../button';
import { Dropdown } from '../dropdown';
import { plus_svg, trash_svg } from '../../assets/svg';
import './FilterModal.scss';
import { Modal } from '../modal';
import { FilterItem, FilterModalProps, FilterRowField } from './FilterModal.types';

export const FilterModal: React.FC<FilterModalProps> = ({
  className = "",
  isOpen,
  onClose,
  filterTitle,
  onApplyFilter,
  onClearFilter,
  selectedFilters = [],
  fieldInfo = [],
  fieldTypeInfo = {
    text: [],
    int: [],
    date: [],
    phone: [],
    bool: [],
  },
  customBooleanOptions = {},
}) => {
  const cn = classname('filter-modal');
  const ref = useRef(null);

  const defaultBooleanOptions = [
    { label: 'Yes', value: 'yes' },
    { label: 'No', value: 'no' },
  ];

  // Format field info into options internally
  const formatFieldOptions = (): Array<{ label: string; value: string; type: string }> => {
    const options: Array<{ label: string; value: string; type: string }> = [];
    fieldInfo.flat().forEach((field) => {
      options.push({
        label: field.label,
        value: field.field,
        type: field.type,
      });
    });
    return options;
  };
  const fieldOptions = formatFieldOptions();

  const [filterRows, setFilterRows] = useState<FilterRowField[]>([
    {
      field: fieldOptions[0]?.value || '',
      type: '',
      value: '',
      id: Date.now(),
      fieldType: fieldOptions[0]?.type || 'text',
    },
  ]);

  useEffect(() => {
    if (!isOpen || fieldOptions.length === 0) return;

    if (selectedFilters && selectedFilters.length > 0) {
      const restoredRows = selectedFilters.map((filter: FilterItem) => {
        const selectedField = fieldOptions.find((opt) => opt.value === filter.field);

        return {
          field: filter.field,
          type: filter.type,
          value: filter.value,
          id: Date.now() + Math.random(),
          fieldType: selectedField?.type || 'text',
        };
      });

      setFilterRows(restoredRows);
    } else {
      const firstField = fieldOptions[0];
      const filterTypes = getFilterTypeOptions(firstField.type);

      setFilterRows([
        {
          field: firstField.value,
          type: filterTypes[0]?.value || '',
          value: '',
          id: Date.now(),
          fieldType: firstField.type,
        },
      ]);
    }
  }, [isOpen, fieldInfo]);

  // Get filter type options for a specific field type
  const getFilterTypeOptions = (fieldType: string): Array<{ label: string; value: string }> => {
    // Default to text if fieldType not found
    const typeKey = fieldType as keyof typeof fieldTypeInfo;

    if (fieldTypeInfo && fieldTypeInfo[typeKey]) {
      return fieldTypeInfo[typeKey].map((item) => ({
        label: item.lookup_key,
        value: item.lookup_key,
      }));
    }

    // Fallback to text options or empty array
    if (fieldTypeInfo.text) {
      return fieldTypeInfo.text.map((item) => ({
        label: item.lookup_key,
        value: item.lookup_key,
      }));
    }

    return [];
  };

  // Get the selected field option object for Dropdown value
  const getSelectedFieldOption = (fieldValue: string) => {
    return fieldOptions.find((opt) => opt.value === fieldValue) || fieldOptions[0];
  };

  // Get the selected filter type option object for Dropdown value
  const getSelectedFilterTypeOption = (filterTypeValue: string, fieldType: string) => {
    const filterTypes = getFilterTypeOptions(fieldType);
    return filterTypes.find((opt) => opt.value === filterTypeValue) || filterTypes[0];
  };

  const getBooleanOptionsForField = (
    fieldName: string
  ): Array<{ label: string; value: string }> => {
    // Check if we have custom options for this specific field
    if (customBooleanOptions[fieldName]) {
      return customBooleanOptions[fieldName];
    }

    // Check if we have custom options for this field by checking partial match
    const fieldKey = Object.keys(customBooleanOptions).find(
      (key) => fieldName.includes(key) || key.includes(fieldName)
    );

    if (fieldKey && customBooleanOptions[fieldKey]) {
      return customBooleanOptions[fieldKey];
    }

    // Default options
    return defaultBooleanOptions;
  };

  const handleAddRow = () => {
    if (fieldOptions.length === 0) return;

    const firstField = fieldOptions[0];
    const filterTypes = getFilterTypeOptions(firstField.type);

    const newRow = {
      field: firstField.value,
      type: filterTypes[0]?.value || '',
      value: '',
      id: Date.now(),
      fieldType: firstField.type,
    };
    setFilterRows([...filterRows, newRow]);
  };

  const handleRemoveRow = (rowIndex: number) => {
    if (filterRows.length > 1) {
      const newRows = filterRows.filter((_, index) => index !== rowIndex);
      setFilterRows(newRows);
    }
  };

  const handleFieldChange = (rowIndex: number, selectedOption: any) => {
    const updatedRows = [...filterRows];

    const value = selectedOption.value;

    const selectedField = fieldOptions.find((opt) => opt.value === value);
    const fieldType = selectedField?.type || 'text';
    const filterTypes = getFilterTypeOptions(fieldType);

    updatedRows[rowIndex] = {
      ...updatedRows[rowIndex],
      field: value,
      fieldType: fieldType,
      type: filterTypes[0]?.value || '',
      value: '',
    };
    setFilterRows(updatedRows);
  };

  const handleFilterTypeChange = (rowIndex: number, selectedOption: any) => {
    const updatedRows = [...filterRows];
    updatedRows[rowIndex] = {
      ...updatedRows[rowIndex],
      type: selectedOption.value,
    };
    setFilterRows(updatedRows);
  };

  const handleValueChange = (rowIndex: number, value: string | Date | boolean | number) => {
    const updatedRows = [...filterRows];
    updatedRows[rowIndex] = {
      ...updatedRows[rowIndex],
      value: String(value),
    };
    setFilterRows(updatedRows);
  };

  const handleApplyFilter = () => {
    const filters = filterRows.map((field, index) => ({
      field: field.field,
      type: field.type,
      value: field.value,
      group: index,
    }));
    onApplyFilter(filters);
  };

  const handleCloseFilter = () => {
    onClose();
  };

  const handleClearFilter = () => {
    if (fieldOptions.length > 0) {
      setFilterRows([
        {
          field: '',
          type: '',
          value: '',
          id: Date.now(),
          fieldType: '',
        },
      ]);
    }
    onClearFilter();
    onClose();
  };

  const renderValueInput = (row: FilterRowField, rowIndex: number) => {
    const fieldType = row.fieldType || 'text';

    switch (fieldType) {
      case 'text':
      case 'phone':
        return (
          <Input
            className=""
            label="Value"
            type="text"
            value={row.value || ''}
            placeholder="Enter Value"
            onChange={(e) => handleValueChange(rowIndex, e.target.value)}
          />
        );

      case 'int':
        return (
          <Input
            className=""
            label="Value"
            type="number"
            value={row.value || ''}
            placeholder="Enter Number"
            onChange={(e) => handleValueChange(rowIndex, e.target.value)}
          />
        );

      case 'date':
        return (
          <DatePicker
            label="Value"
            value={row.value ? new Date(row.value) : null}
            onChange={(date) => handleValueChange(rowIndex, date || '')}
          />
        );

      case 'bool':
        const booleanOptions = getBooleanOptionsForField(row.field);
        return (
          <RadioGroup
            name=""
            label="Value"
            direction="horizontal"
            value={row.value || ''}
            onChange={(value) => handleValueChange(rowIndex, value)}
            options={booleanOptions}
          />
        );

      default:
        return (
          <Input
            className=""
            label="Value"
            type="text"
            value={row.value || ''}
            placeholder="Enter Value"
            onChange={(e) => handleValueChange(rowIndex, e.target.value)}
          />
        );
    }
  };

  return (
    <Modal
      ref={ref}
      className={cns(cn(), className)}
      show={isOpen}
      title={`${filterTitle}`}
      onClose={onClose}
      size="lg"
      footer={
        <div className={cn('footer')}>
          <Button
            text="Clear All"
            variant="secondary"
            onClick={handleClearFilter}
            disabled={fieldOptions.length === 0}
          />
          <div className={cn('footer-buttons')}>
            <Button
              text="Close"
              variant="secondary"
              onClick={handleCloseFilter}
              disabled={fieldOptions.length === 0}
            />
            <Button
              text="Apply Filter"
              variant="primary"
              onClick={handleApplyFilter}
              disabled={fieldOptions.length === 0}
            />
          </div>
        </div>
      }
    >
      {/* Filter Rows */}
      {fieldOptions.length > 0 &&
        filterRows.map((row, rowIndex) => {
          const filterTypes = getFilterTypeOptions(row.fieldType);
          const selectedFieldOption = getSelectedFieldOption(row.field);
          const selectedFilterTypeOption = getSelectedFilterTypeOption(row.type, row.fieldType);

          return (
            <div key={row.id} className={cn('row')}>
              <div className={cn('row-header')}>
                <span className={cn('row-title')}>Filter {rowIndex + 1}</span>
                <div className={cn('actions')}>

                  {filterRows.length > 1 && (
                    <button
                      className={cn('remove-row')}
                      onClick={() => handleRemoveRow(rowIndex)}
                      type="button"
                      aria-label="Remove filter row"
                    >
                      {trash_svg}
                    </button>
                  )}
                  <button
                    className={cn('add-row')}
                    onClick={handleAddRow}
                    type="button"
                    aria-label="Add"
                    title='Add'
                  >
                    +
                  </button>
                </div>
              </div>

              <div className={cn('fields')}>
                <div className={cn('field')}>
                  <Dropdown
                    label="Select Field"
                    value={selectedFieldOption}
                    onChange={(selectedOption: any) => handleFieldChange(rowIndex, selectedOption)}
                    options={fieldOptions}
                    menuPortalTarget={document.body}
                    menuPosition="absolute"
                    menuPlacement="auto"
                  />
                </div>
                <div className={cn('field')}>
                  <Dropdown
                    label="Filter Type"
                    value={selectedFilterTypeOption}
                    onChange={(selectedOption: any) =>
                      handleFilterTypeChange(rowIndex, selectedOption)
                    }
                    options={filterTypes}
                    menuPortalTarget={document.body}
                    menuPosition="absolute"
                    menuPlacement="auto"
                  />
                </div>
                <div className={cn('field')}>{renderValueInput(row, rowIndex)}</div>
              </div>
            </div>
          );
        })}
    </Modal>
  );
};
