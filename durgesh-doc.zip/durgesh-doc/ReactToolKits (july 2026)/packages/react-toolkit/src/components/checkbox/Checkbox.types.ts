export interface CheckboxProps {
  className?: string;
  label: React.ReactNode;
  value: string | number | boolean;
  name?: string;
  isSelected?: boolean;
  isDisabled?: boolean;
  onChange: (value: string | number | boolean, event: React.ChangeEvent<HTMLInputElement>) => void;
}
