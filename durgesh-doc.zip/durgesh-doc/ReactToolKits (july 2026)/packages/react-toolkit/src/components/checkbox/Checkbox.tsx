import * as React from "react";
import { CheckboxProps } from "./Checkbox.types";
import { classname, cns } from "@msbc/utils";
import "./Checkbox.scss";
import { checkmark_svg } from "../../assets/svg";

const Checkbox = ({
  className = "",
  label,
  value,
  name,
  isSelected = false,
  onChange,
  isDisabled = false,
}: CheckboxProps): React.ReactElement => {
  const cn = classname("checkbox");

  return (
    <div className={cns(cn(), className)}>
      <label className={cn("label")}>
        <input
          type="checkbox"
          name={name}
          checked={isSelected}
          onChange={(event) => onChange(value, event)}
          className={cn("input")}
          disabled={isDisabled}
        />

        <div
          className={cn("checkmark-container", {
            "is-checked": isSelected,
          })}
        >
          {isSelected && (
            <span className={cn("checkmark")}>
              {checkmark_svg}
            </span>
          )}
        </div>

        <span className={cn("text")}>{label}</span>
      </label>
    </div>
  );
};

export default Checkbox;
