import { Props as SelectProps, Options } from 'react-select';
import type { UseApiOptions } from '@msbc/data-layer';

export interface DropdownProps extends SelectProps {
  //ensures props don’t conflict with custom options prop.
  className?: string;
  label?: React.ReactNode;
  helpText?: string;
  error?: string;
  isRequired?: boolean;
  placeholder?: string;
  api?: UseApiOptions;
  isCreatable?: boolean;
  onCreateOption?: (inputValue: string) => void;
  labelKey?: string;
  valueKey?: string;
  apiEnabled?: boolean;
  // TODO: remove in favor of apiResponseMapper in future major version
  apiResponseMapper?: (data: any) => any[];
}
