import type { Meta, StoryObj } from '@storybook/react-vite';
import { Dropdown } from "./Dropdown";
import { DropdownProps } from "./Dropdown.types";
import React, { useState } from "react";
import { expect, fn, userEvent, within } from 'storybook/test';

export const ActionsData = {
  onChange: fn(),
};

const meta = {
  title: "Components/Dropdown",
  component: Dropdown,
  tags: ["autodocs"],
  excludeStories: /.*Data$/,
  args: {
    ...ActionsData,
    label: "Dropdown",
    placeholder: "Select an option",
    isRequired: false,
    error: "",
  },
} satisfies Meta<typeof Dropdown>;

export default meta;
type Story = StoryObj<typeof meta>;

const Template = (args: DropdownProps) => <Dropdown {...args} />;

export const SingleSelect: Story = {
  render: Template,
  args: {
    label: "Single Select Dropdown",
    options: [
      { label: "Option 1", value: "option1" },
      { label: "Option 2", value: "option2" },
      { label: "Option 3", value: "option3" },
    ],
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    const label = canvas.getByText('Single Select Dropdown');
    await expect(label).toBeInTheDocument();

    const combobox = canvas.getByRole('combobox');
    await expect(combobox).toBeInTheDocument();
    await expect(combobox).toHaveAttribute('aria-expanded', 'false');

    await userEvent.click(combobox);

    const option1 = await canvas.findByText('Option 1');
    const option2 = await canvas.findByText('Option 2');
    const option3 = await canvas.findByText('Option 3');

    await expect(option1).toBeInTheDocument();
    await expect(option2).toBeInTheDocument();
    await expect(option3).toBeInTheDocument();

    await userEvent.click(option1);

    await expect(args.onChange).toHaveBeenCalled();
  },
};

export const MultiSelect: Story = {
  render: Template,
  args: {
    label: "Multi Select Dropdown",
    options: [
      { label: "Option 1", value: "option1" },
      { label: "Option 2", value: "option2" },
      { label: "Option 3", value: "option3" },
    ],
    placeholder: "Select multiple options",
    isMulti: true,
    isOptionDisabled: (option) => option.value == 'option1',
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    await expect(canvas.getByText('Multi Select Dropdown')).toBeInTheDocument();

    const combobox = canvas.getByRole('combobox');

    await userEvent.click(combobox);

    const disabledOption = await canvas.findByText('Option 1');
    await expect(disabledOption).toHaveAttribute('aria-disabled', 'true');

    const option2 = await canvas.findByText('Option 2');
    await userEvent.click(option2);

    await new Promise(resolve => setTimeout(resolve, 100));
    await userEvent.click(combobox);

    const option3 = await canvas.findByText('Option 3');
    await userEvent.click(option3);

    await expect(args.onChange).toHaveBeenCalledTimes(2);
  },
};

export const Required: Story = {
  render: Template,
  args: {
    label: "Required Dropdown",
    options: [
      { label: "Option 1", value: "option1" },
      { label: "Option 2", value: "option2" },
      { label: "Option 3", value: "option3" },
    ],
    isRequired: true,
    required: true,
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    const label = canvas.getByText('Required Dropdown');
    await expect(label).toBeInTheDocument();

    const combobox = canvas.getByRole('combobox');
    await expect(combobox).toHaveAttribute('aria-required', 'true');

  },
};

export const WithError: Story = {
  render: Template,
  args: {
    label: "Dropdown with Error",
    options: [
      { label: "Option 1", value: "option1" },
      { label: "Option 2", value: "option2" },
      { label: "Option 3", value: "option3" },
    ],
    isRequired: true,
    error: "This field is required.",
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    const errorMessage = canvas.getByText('This field is required.')
    await expect(errorMessage).toBeInTheDocument();


    const combobox = canvas.getByRole('combobox');
    await expect(combobox).toBeInTheDocument();

    await userEvent.click(combobox);
    const option1 = await canvas.findByText('Option 1');
    await expect(option1).toBeInTheDocument();
  },
};

export const Disabled: Story = {
  render: Template,
  args: {
    label: "Disabled Dropdown",
    options: [
      { label: "Option 1", value: "option1" },
      { label: "Option 2", value: "option2" },
      { label: "Option 3", value: "option3" },
    ],
    isDisabled: true,
  },
  play: async ({ canvasElement, args }) => {

    const combobox = canvasElement.querySelector('input[role="combobox"]');
    await expect(combobox).toBeDisabled();

    await expect(combobox).toHaveAttribute('aria-expanded', 'false');
  },
};

export const ApiCall: Story = {
  render: Template,
  args: {
    label: "Dropdown with API Data",
    isRequired: false,
    error: "",
    placeholder: "Select an option",
    api: {
      url: "https://jsonplaceholder.typicode.com/posts",
      method: "get",
      params: {},
      autoFetch: false,
    },
    labelKey: 'title',
    valueKey: 'id',
  },
    play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);
    
    await expect(canvas.getByText('Dropdown with API Data')).toBeInTheDocument();
    
    const combobox = canvas.getByRole('combobox');
    await expect(combobox).toBeInTheDocument();
  },
};


//   const [singleValue, setSingleValue] = useState<{ label: string; value: string } | null>(null);
//   const [multiValue, setMultiValue] = useState<Array<{ label: string; value: string }>>([]);
//   const [apiValue, setApiValue] = useState<any>(null);
//   const [errorValue, setErrorValue] = useState<{ label: string; value: string } | null>(null);

//   const staticOptions = [
//     { label: "Apple", value: "apple" },
//     { label: "Banana", value: "banana" },
//     { label: "Orange", value: "orange" },
//     { label: "Grape", value: "grape" },
//     { label: "Mango", value: "mango" },
//   ];

//   const groupedOptions = [
//     {
//       label: "Fruits",
//       options: [
//         { label: "Apple", value: "apple" },
//         { label: "Banana", value: "banana" },
//         { label: "Orange", value: "orange" },
//       ]
//     },
//     {
//       label: "Vegetables",
//       options: [
//         { label: "Carrot", value: "carrot" },
//         { label: "Broccoli", value: "broccoli" },
//         { label: "Spinach", value: "spinach" },
//       ]
//     }
//   ];

//   return (
//     <div style={{
//       display: "flex",
//       flexDirection: "column",
//       gap: "2rem",
//       padding: "1rem",
//       maxWidth: "500px"
//     }}>
//       <div>
//         <h3>Single Select Dropdown</h3>
//         <Dropdown
//           label="Select your favorite fruit"
//           placeholder="Choose a fruit..."
//           options={staticOptions}
//           value={singleValue}
//           onChange={setSingleValue}
//         />
//         {singleValue && (
//           <p style={{ marginTop: "0.5rem", color: "#666" }}>
//             Selected: <strong>{singleValue.label}</strong> (Value: {singleValue.value})
//           </p>
//         )}
//       </div>

//       <div>
//         <h3>Multi Select Dropdown</h3>
//         <Dropdown
//           label="Select multiple fruits"
//           placeholder="Choose fruits..."
//           options={staticOptions}
//           value={multiValue}
//           onChange={setMultiValue}
//           isMulti={true}
//         />
//         {multiValue.length > 0 && (
//           <div style={{ marginTop: "0.5rem" }}>
//             <p style={{ color: "#666", marginBottom: "0.25rem" }}>Selected:</p>
//             <ul style={{ color: "#666", margin: 0, paddingLeft: "1rem" }}>
//               {multiValue.map(item => (
//                 <li key={item.value}>{item.label}</li>
//               ))}
//             </ul>
//           </div>
//         )}
//       </div>

//       <div>
//         <h3>Grouped Options</h3>
//         <Dropdown
//           label="Select food category"
//           placeholder="Choose from categories..."
//           options={groupedOptions}
//           value={singleValue}
//           onChange={setSingleValue}
//         />
//       </div>

//       <div>
//         <h3>Required Field with Validation</h3>
//         <Dropdown
//           label="Select a fruit (Required)"
//           placeholder="Please select a fruit"
//           options={staticOptions}
//           value={errorValue}
//           onChange={setErrorValue}
//           isRequired={true}
//           error={!errorValue ? "This field is required" : ""}
//         />
//         <button
//           onClick={() => setErrorValue(null)}
//           style={{
//             marginTop: "0.5rem",
//             padding: "0.25rem 0.5rem",
//             backgroundColor: "#f0f0f0",
//             border: "1px solid #ccc",
//             borderRadius: "4px",
//             cursor: "pointer"
//           }}
//         >
//           Clear selection to show error
//         </button>
//       </div>

//       <div>
//         <h3>Disabled Dropdown</h3>
//         <Dropdown
//           label="Disabled dropdown"
//           placeholder="Cannot select..."
//           options={staticOptions}
//           value={{ label: "Apple", value: "apple" }}
//           isDisabled={true}
//         />
//         <p style={{ marginTop: "0.5rem", color: "#666", fontSize: "0.875rem" }}>
//           This dropdown is disabled and cannot be interacted with.
//         </p>
//       </div>

//       <div>
//         <h3>Dropdown with API Data</h3>
//         <Dropdown
//           label="Select a blog post"
//           placeholder="Choose from API data..."
//           api={{
//             url: "https://jsonplaceholder.typicode.com/posts",
//             method: "get",
//             params: { _limit: 10 },
//             autoFetch: true,
//           }}
//           labelKey="title"
//           valueKey="id"
//           value={apiValue}
//           onChange={setApiValue}
//         />
//         {apiValue && (
//           <div style={{ marginTop: "0.5rem", color: "#666" }}>
//             <p><strong>Selected Post:</strong> {apiValue.title}</p>
//             <p style={{ fontSize: "0.875rem", marginTop: "0.25rem" }}>
//               ID: {apiValue.id}, User ID: {apiValue.userId}
//             </p>
//           </div>
//         )}
//       </div>

//       <div>
//         <h3>With Custom Option</h3>
//         <Dropdown
//           label="Dropdown with disabled option"
//           placeholder="Select an option..."
//           options={staticOptions}
//           isOptionDisabled={(option) => option.value === "orange"}
//         />
//         <p style={{ marginTop: "0.5rem", color: "#666", fontSize: "0.875rem" }}>
//           Note: "Orange" option is disabled and cannot be selected.
//         </p>
//       </div>
//     </div>
//   );
// };