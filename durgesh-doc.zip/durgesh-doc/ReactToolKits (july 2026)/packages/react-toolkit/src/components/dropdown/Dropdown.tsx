import React from "react";
import Select, { components, type MenuListProps, type PropsValue } from "react-select";
import { useEffect, useMemo, useRef } from "react";
import { useApiRequest } from "@msbc/data-layer";
import type { DropdownProps } from "./Dropdown.types";
import "./Dropdown.scss";
import { FormFieldWrapper } from "../formFieldWrapper/FormFieldWrapper";
import Creatable from "react-select/creatable";
import { classname, cns, isEmpty } from "@msbc/utils";

const MenuList = (props: MenuListProps<any, boolean>) => {
  const listRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    // Defer until options are rendered
    const raf = requestAnimationFrame(() => {
      const root = listRef.current;
      if (!root) return;

      // 1) Preferred: scroll to the element react-select marks as selected
      let target = root.querySelector<HTMLElement>(
        '[aria-selected="true"], .dropdown__select__option--is-selected'
      );

      // 2) Fallback: match by the currently selected label text
      if (!target) {
        const selectedValues = props.getValue?.() || [];
        const selectedLabel = selectedValues?.[0]?.label;
        if (selectedLabel) {
          const optionsEls = Array.from(
            root.querySelectorAll<HTMLElement>('[role="option"]')
          );
          target =
            optionsEls.find(
              (el) =>
                (el.textContent || "").trim() === String(selectedLabel).trim()
            ) || null;
        }
      }

      if (target) target.scrollIntoView({ block: "nearest" });
    });

    return () => cancelAnimationFrame(raf);
    // Re-run when menu contents or selection changes
  }, [props.selectProps.value]);

  return (
    <components.MenuList
      {...props}
      innerRef={(node) => {
        listRef.current = node;
        // Preserve upstream ref behavior
        if (typeof props.innerRef === "function") props.innerRef(node);
        else if (props.innerRef) props.innerRef.current = node;
      }}
    />
  );
};

export const Dropdown = ({
  className = '',
  label,
  helpText,
  onChange,
  isRequired,
  error,
  options = [],
  placeholder,
  isDisabled,
  value,
  api,
  isCreatable = false,
  onCreateOption = undefined,
  isMulti,
  labelKey = '',
  valueKey = '',
  apiResponseMapper,
  apiEnabled = true,
  ...rest
}: DropdownProps) => {
  const cn = classname("dropdown");

  const {
    url,
    method,
    params,
    body,
    config,
    autoFetch
  } = api || {};

  const { data, execute, loading } = useApiRequest({
    url: url || "",
    method: method || "get",
    params: params,
    config: config,
    autoFetch: false,
  });

  const finalOptions = useMemo(() => {
    if (api && data) {
      const rawData: any[] = apiResponseMapper?.(data) || data;
      const apiOptions = Array.isArray(rawData)
        ? rawData.map((item: any) => ({
          label: labelKey ? item[labelKey] : item.label,
          value: valueKey ? item[valueKey] : item.value,
          ...item,
        }))
        : [];
      return apiOptions;
    }
    return options;
  }, [options, data, api]);

  const paramsKey = useMemo(() => JSON.stringify(params ?? {}), [params]);
  const bodyKey = useMemo(() => JSON.stringify(body ?? {}), [body]);
  const configKey = useMemo(() => JSON.stringify(config ?? {}), [config]);
  const lastReqKeyRef = useRef<string>('');

  useEffect(() => {
    if (!apiEnabled) return;
    if (!url) return;

    const reqKey = JSON.stringify({
      url,
      method: method || 'get',
      params: params ?? {},
      body: body ?? null,
    });

    if (lastReqKeyRef.current === reqKey) return;
    lastReqKeyRef.current = reqKey;

    if (!autoFetch) {
      execute({
        url,
        params,
        body,
        config,
      });
    }
  }, [
    apiEnabled,
    url,
    method,
    autoFetch,
    paramsKey,
    bodyKey,
    configKey,
  ]);

  const resolvedValue = useMemo(() => {
    if (value == null) return value;

    const findOption = (val: any) => {
      if (isEmpty(val)) return null;
      if (typeof val === 'object' && val !== null && 'value' in val && 'label' in val) return val;

      // Extract primitive key for lookup — handles objects with value but no label
      const lookupKey = typeof val === 'object' && val !== null && 'value' in val ? val.value : val;

      const match = (finalOptions as { value: any; label: any }[])?.find((opt) => opt.value == lookupKey);
      const match2 = (finalOptions as { value: any; label: any }[])?.find((opt) => opt.label == lookupKey);

      // Before API loads, preserve enough info to show a chip (value key at minimum)
      if (!match && !match2) {
        if (typeof lookupKey === 'string' || typeof lookupKey === 'number') {
          return { value: lookupKey, label: String(lookupKey) };
        }
        return val;
      }

      return match ?? match2;
    };

    if (isMulti) {
      return Array.isArray(value) ? value.map(findOption) : [];
    }

    return Array.isArray(value) ? findOption(value[0]) : findOption(value as string);
  }, [value, finalOptions, isMulti]);

  // Choose  select component
  const SelectComponent = isCreatable ? Creatable : Select;

  // Handles creation of new option
  const handleCreateOption = (inputValue: string) => {
    const newOption = { label: inputValue, value: inputValue, __isNew__: true };

    // Optional: trigger backend POST or external handler
    if (onCreateOption) onCreateOption(inputValue);

    // Delegate control to parent form 
    if (onChange) {
      if (isMulti) {
        const current = Array.isArray(value) ? value : [];
        onChange([...current, newOption] as any, {
          action: "create-option",
          option: newOption,
        });
      } else {
        onChange(newOption as any, {
          action: "create-option",
          option: newOption,
        });
      }
    }
  };

  return (
    <FormFieldWrapper
      className={cns(cn({ 'has-error': !!error, }), className)}
      label={label}
      isRequired={isRequired}
      error={error}
      isDisabled={isDisabled}
      helpText={helpText}
    >
      <SelectComponent
        isClearable={isCreatable}
        className={cn('select-container')}
        classNamePrefix={cn('select')}
        options={finalOptions}
        placeholder={placeholder}
        value={resolvedValue as PropsValue<(typeof finalOptions)[number]>}
        isDisabled={isDisabled}
        isMulti={isMulti}
        onChange={onChange}
        onCreateOption={isCreatable ? handleCreateOption : undefined}
        isLoading={loading}
        components={{ MenuList }}
        menuShouldScrollIntoView
        {...rest}
      />
    </FormFieldWrapper>
  );
};
