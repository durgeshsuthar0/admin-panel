import React, { forwardRef, useEffect, useState } from "react";
import ReactDatePicker, { ReactDatePickerCustomHeaderProps } from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { DatePickerProps, RangeDatePickerProps, SelectOption } from "./Datepicker.types";
import { chevronLeft, chevronRight, DateIcon } from '../../assets/svg';
import { FormFieldWrapper } from '../formFieldWrapper/FormFieldWrapper';
import Select from 'react-select';
import './Datepicker.scss';

const range = (start: number, end: number, step: number): number[] => {
  const result: number[] = [];
  for (let i = start; i < end; i += step) {
    result.push(i);
  }
  return result;
};

const MONTHS = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
] as const;

const years = range(1990, new Date().getFullYear() + 1, 1);
const yearOptions: SelectOption[] = years.map((year) => ({
  label: year.toString(),
  value: year,
}));

const monthOptions: SelectOption[] = MONTHS.map((month, index) => ({
  label: month,
  value: index,
}));

interface CustomInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  icon?: React.ReactNode;
  value?: string;
  onClick?: () => void;
}

const CustomInput = forwardRef<HTMLInputElement, CustomInputProps>(
  ({ value, onClick, icon, ...rest }, ref) => (
    <div className="datepicker-input-wrapper">
      <input
        value={value || ""}
        onClick={onClick}
        ref={ref}
        {...rest}
      />
      <span className="icon">{icon ?? DateIcon}</span>
    </div>
  )
);

export const customMonthHeader = ({
  date,
  changeYear,
  changeMonth,
  decreaseMonth,
  increaseMonth,
  nextMonthButtonDisabled,
  nextYearButtonDisabled,
  prevMonthButtonDisabled,
  prevYearButtonDisabled,
  visibleYearsRange,
}: ReactDatePickerCustomHeaderProps) => {
  const currentYear = date.getFullYear();
  const currentMonth = date.getMonth();

  return (
    <div className="custom-month-container">
      <button className="nav-arrow" onClick={decreaseMonth} disabled={prevMonthButtonDisabled}>
        {chevronLeft}
      </button>
      <div className="dropdowm parent">

        <div className="dropdown custom-month-select">
          <Select
            options={monthOptions}
            value={monthOptions.find((m) => m.value === currentMonth)}
            onChange={(option) => option && changeMonth(option.value)}
            className="dropdown"
            classNamePrefix="dropdown__select"
            isSearchable={false}
          />
        </div>

        <div className="dropdown custom-year-select">
          <Select
            options={yearOptions}
            value={yearOptions.find((y) => y.value === currentYear)}
            onChange={(option) => option && changeYear(option.value)}
            className="dropdown"
            classNamePrefix="dropdown__select"
            isSearchable={false}
          />
        </div>
      </div>

      <button className="nav-arrow" onClick={increaseMonth} disabled={nextMonthButtonDisabled}>
        {chevronRight}
      </button>
    </div>
  );
};

const DEFAULT_FORMAT = "dd/MM/yyyy";

export const DatePicker: React.FC<DatePickerProps> = ({
  id,
  value,
  onChange,
  placeholder = "Select date",
  minDate,
  maxDate,
  className = "",
  disabled = false,
  dateFormat = DEFAULT_FORMAT,
  showTimeSelect = false,
  label,
  isRequired,
  error,
  isDisabled,
  helpText,
  icon,
  ...rest
}) => {
  return (
    <FormFieldWrapper
      label={label}
      isRequired={isRequired}
      error={error}
      isDisabled={isDisabled}
      helpText={helpText}
    >
      <div className="datepicker-wrapper">
        <ReactDatePicker
          id={id}
          selected={value}
          onChange={(d: Date | null) => onChange(d)}
          placeholderText={placeholder}
          minDate={minDate}
          maxDate={maxDate}
          disabled={disabled}
          dateFormat={dateFormat}
          showTimeSelect={showTimeSelect}
          calendarStartDay={1}
          formatWeekDay={(nameOfDay) => nameOfDay.slice(0, 3)}
          renderCustomHeader={customMonthHeader}
          isClearable
          customInput={<CustomInput icon={icon} />}
          {...(rest as any)}
        />
      </div>
    </FormFieldWrapper >
  );
};

export const RangeDatePicker: React.FC<RangeDatePickerProps> = ({
  id,
  startDate,
  endDate,
  onChange,
  placeholder = "Select date range",
  minDate,
  maxDate,
  className = "",
  disabled = false,
  dateFormat = DEFAULT_FORMAT,
  label,
  isRequired,
  error,
  isDisabled,
  helpText,
  icon,
  ...rest
}) => {
  const [range, setRange] = useState<[Date | null, Date | null]>([
    startDate,
    endDate,
  ]);

  useEffect(() => {
    setRange([startDate, endDate]);
  }, [startDate, endDate]);

  function handleChange(dates: [Date | null, Date | null]) {
    const [start, end] = dates;
    setRange([start, end]);
    onChange(start, end);
  }

  return (
    <FormFieldWrapper
      label={label}
      isRequired={isRequired}
      error={error}
      isDisabled={isDisabled}
      helpText={helpText}
    >
      <div className="datepicker-wrapper">
        <ReactDatePicker
          id={id}
          selectsRange
          startDate={range[0]}
          endDate={range[1]}
          selected={range[0] ?? range[1] ?? null}
          onChange={handleChange}
          placeholderText={placeholder}
          minDate={minDate}
          maxDate={maxDate}
          disabled={disabled}
          dateFormat={dateFormat}
          calendarStartDay={1}
          formatWeekDay={(nameOfDay) => nameOfDay.slice(0, 3)}
          renderCustomHeader={customMonthHeader}
          isClearable
          customInput={<CustomInput icon={icon} />}
          {...(rest as any)}
        />
      </div>
    </FormFieldWrapper >
  );
};
