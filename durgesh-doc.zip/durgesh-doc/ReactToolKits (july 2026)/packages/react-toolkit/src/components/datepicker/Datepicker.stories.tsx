import type { Meta, StoryObj } from '@storybook/react-vite';
import { DatePicker, RangeDatePicker } from './DatePicker';
import { DatePickerProps } from './Datepicker.types';
import React, { useState } from 'react';
import { expect, fn, userEvent, within } from 'storybook/test';

export const ActionsData = {
  onChange: fn(),
};

const meta = {
  title: 'Components/DatePicker',
  component: DatePicker,
  tags: ['autodocs'],
  excludeStories: /.*Data$/,
  args: {
    ...ActionsData,
    label: 'Date Picker',
    dropdownMode: 'select',
    showMonthDropdown: true,
    showYearDropdown: true,
    isRequired: false,
  },
  argTypes: {
    isRequired: {
      control: { type: 'boolean' },
    },
    error: {
      control: { type: 'text' },
    },
    placeholderText: {
      control: { type: 'text' },
    },
  },
} satisfies Meta<typeof DatePicker>;

export default meta;
type Story = StoryObj<typeof meta>;

const Template = (args: DatePickerProps) => <DatePicker {...args} />;

const startDate = new Date();
const endDate = new Date(startDate);
endDate.setDate(startDate.getDate() + 10);

export const SingleDate: Story = {
  render: Template,
  args: {
    label: 'Single Date Picker',
    selected: new Date(),
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    console.log(canvasElement);
    // find input by placeholder or label
    const input = canvas.getByPlaceholderText('Select date');

    // click input to open calendar
    await userEvent.click(input);

    // select a date (example: 15)

    const date = await within(canvasElement).findByRole('gridcell', {
      name: getDateLabel(startDate),
    });
    // const date = await canvas.findByText('15');
    await userEvent.click(date);

    // assertion
    await expect(input).not.toHaveValue('');
  },
};

function getOrdinal(n: number) {
  if (n > 3 && n < 21) return 'th';
  switch (n % 10) {
    case 1:
      return 'st';
    case 2:
      return 'nd';
    case 3:
      return 'rd';
    default:
      return 'th';
  }
}

function getDateLabel(date: Date) {
  const weekday = date.toLocaleDateString('en-US', { weekday: 'long' });
  const month = date.toLocaleDateString('en-US', { month: 'long' });
  const day = date.getDate();
  const year = date.getFullYear();

  return `Choose ${weekday}, ${month} ${day}${getOrdinal(day)}, ${year}`;
}

export const RangePicker: Story = {
  render: Template,

  args: {
    label: 'Date Range Picker',
    selectsRange: true,
    startDate: startDate,
    endDate: endDate,
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const input = await canvas.getByRole('textbox');

    await userEvent.click(input);
    const startDay = await within(canvasElement).findByRole('gridcell', {
      name: getDateLabel(startDate),
    });
    await userEvent.click(startDay);

    // END DATE (user click after re-render)
    const endDay = await within(canvasElement).findByRole('gridcell', {
      name: getDateLabel(endDate),
    });
    await userEvent.click(endDay);

    // Assert range selected
    await expect(input).not.toHaveValue('');
  },
};

export const Demo = {
  render: () => {
    const [value, setValue] = useState<Date | null>(null);
    const [multiValue, setMultiValue] = useState<[Date | null, Date | null]>([null, null]);

    const handleOnChange = (date: Date | null) => {
      setValue(date);
    };

    const handleMultiOnChange = (start: Date | null, end: Date | null) => {
      setMultiValue([start, end]);
    };

    return (
      <div
        style={{
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        <div>
          <h4>Single Date Picker</h4>
          <DatePicker placeholder="Select a single date" value={value} onChange={handleOnChange} />
        </div>

        <div>
          <h4>Range Date Picker</h4>
          <RangeDatePicker
            placeholder="Select a date range"
            startDate={multiValue[0]}
            endDate={multiValue[1]}
            onChange={handleMultiOnChange}
          />
        </div>
      </div>
    );
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    // --- Single Date ---
    const singleInput = canvas.getByPlaceholderText('Select a single date');
    await userEvent.click(singleInput);
    await userEvent.click(await canvas.findByText('13'));
    await expect(singleInput).not.toHaveValue('');

    // --- Range Date ---
    const rangeInput = canvas.getByPlaceholderText('Select a date range');
    await userEvent.click(rangeInput);
    await userEvent.click(await canvas.findByText('5'));
    await userEvent.click(await canvas.findByText('18'));
    await expect(rangeInput).not.toHaveValue('');
  },
};
