import React from 'react';
import ReactDatePicker from 'react-datepicker';

export type SelectOption = { label: string; value: number };

export type OmittedPickerKeys =
  | 'selectsMultiple'
  | 'selected'
  | 'startDate'
  | 'endDate'
  | 'value'
  | 'onChange'
  | 'onChangeRaw'
  | 'onSelect'
  | 'onInputClick'
  | 'onCalendarOpen'
  | 'onCalendarClose';

export type BasePickerProps = Omit<
  Partial<React.ComponentProps<typeof ReactDatePicker>>,
  OmittedPickerKeys
>;

export interface DatePickerProps extends BasePickerProps {
  label?: React.ReactNode;
  isRequired?: boolean;
  error?: string;
  isDisabled?: boolean;
  helpText?: string;
  id?: string;
  value: Date | null;
  onChange: (date: Date | null) => void;
  placeholder?: string;
  minDate?: Date;
  maxDate?: Date;
  className?: string;
  disabled?: boolean;
  dateFormat?: string;
  showTimeSelect?: boolean;
  icon?: React.ReactNode;
}

export interface RangeDatePickerProps extends BasePickerProps {
  label?: React.ReactNode;
  isRequired?: boolean;
  error?: string;
  isDisabled?: boolean;
  helpText?: string;
  id?: string;
  startDate: Date | null;
  endDate: Date | null;
  onChange: (start: Date | null, end: Date | null) => void;
  placeholder?: string;
  minDate?: Date;
  maxDate?: Date;
  className?: string;
  disabled?: boolean;
  dateFormat?: string;
  icon?: React.ReactNode;
}
