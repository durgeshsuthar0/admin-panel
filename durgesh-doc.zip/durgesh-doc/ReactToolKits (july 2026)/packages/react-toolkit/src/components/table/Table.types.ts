import { AgGridReactProps } from 'ag-grid-react';
import type { UseApiOptions } from '@msbc/data-layer';

export interface TableProps<T> extends Omit<
  AgGridReactProps,
  'onSelectionChanged' | 'onPaginationChanged'
> {
  tableId?: string;
  tableName?: string;
  tableWidth?: string;
  tableHeight?: string;
  className?: string;
  api?: UseApiOptions;
  currentPage?: number;
  totalRecords?: number;
  totalPage?: number;
  onPageNumberChange?: () => void;
  onSelectionChanged?: (selectedRows: T[]) => void;
  onPaginationChanged?: (page: number) => void;
  showPagination?: boolean;
  // TODO: remove in favor of apiResponseMapper in future major version
  apiResponseMapper?: (data: any) => {
    data: any[];
    currentPage?: number;
    totalRecords?: number;
    totalPage?: number;
  };
}

export interface PaginationProps {
  currentPage: number;
  totalRecords: number;
  totalPage: number;
  onPageChange: (page: number) => void;
}
