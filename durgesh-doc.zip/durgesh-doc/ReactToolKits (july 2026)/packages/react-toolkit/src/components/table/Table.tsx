import React, { useEffect, useMemo, useRef, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import { AllCommunityModule, ModuleRegistry, themeQuartz, iconSetAlpine } from 'ag-grid-community';
import { TableProps } from './Table.types';
import { useApiRequest } from '@msbc/data-layer';
import './Table.scss';
import { classname, cns } from '@msbc/utils';
import { Pagination } from './Pagination';

ModuleRegistry.registerModules([AllCommunityModule]);

const myTheme = themeQuartz.withPart(iconSetAlpine).withParams({
  accentColor: 'var(--color-primary-07)',
  backgroundColor: 'var(--gray-01,#FBFBFB)',
  browserColorScheme: 'light',
  cellEditingBorder: true,
  cellHorizontalPadding: 16,
  cellTextColor: 'var(--gray-09,#1B1B1B)',
  headerBackgroundColor: 'var(--gray-01,#FBFBFB)',
  headerFontSize: 16,
  headerFontWeight: 600,
  headerRowBorder: false,
  headerTextColor: 'var(--gray-05,#AFAFAF)',
  wrapperBorder: false,
  wrapperBorderRadius: 0,
  rowVerticalPaddingScale: 1.4,
  rowHoverColor: '#fdfdfd',
  rowBorder: { style: 'dotted', width: 3, color: '#9696C8' },
});

export const Table = <T,>({
  className = '',
  tableId,
  tableName,
  tableHeight,
  tableWidth,
  rowData = [],
  api,
  onSelectionChanged,
  apiResponseMapper,
  onPaginationChanged,
  showPagination = true,
  currentPage,
  totalRecords,
  totalPage,
  ...rest
}: TableProps<T>) => {
  const cn = classname('table-grid');

  const {
    url,
    method,
    params,
    body,
    config,
    autoFetch
  } = api || {};

  const gridRef = useRef<AgGridReact<any>>(null);
  const { data, loading, execute } = useApiRequest({
    url: url || '',
    method: method || 'get',
    params: params,
    config: config,
    autoFetch: autoFetch ?? false,
  });

  const handleSelectionChanged = () => {
    const selected = gridRef.current?.api.getSelectedRows();
    onSelectionChanged && onSelectionChanged(selected || []);
  };

  const rowDataFinal = useMemo(() => {
    if (api && data) {
      const { data: rawData, currentPage, totalRecords, totalPage } = apiResponseMapper?.(data) || data;
      return {
        rowData: rawData,
        currentPage: currentPage,
        totalRecords: totalRecords,
        totalPage: totalPage
      };
    }
    return {
      rowData,
      currentPage: currentPage,
      totalRecords: totalRecords,
      totalPage: totalPage
    };
  }, [rowData, data]);

  useEffect(() => {
    if (api && !autoFetch) {
      execute({
        params: params,
        body: body, // optional (only if needed)
        config: config, // optional
      });
    }
  }, [params, body, autoFetch]);

  const handlePageChange = (page: number) => {
    onPaginationChanged?.(page);
  };

  return (
    <div
      className={cns(cn(), className)}
      id={`${tableId}`}
    >
      <AgGridReact<T>
        rowData={rowDataFinal.rowData}
        ref={gridRef}
        loading={loading}
        theme={myTheme}
        domLayout="autoHeight"
        suppressHorizontalScroll={true}
        {...rest}
        onSelectionChanged={handleSelectionChanged}
      />
      {(!loading && showPagination) && (
        <Pagination
          onPageChange={handlePageChange}
          currentPage={rowDataFinal.currentPage}
          totalPage={rowDataFinal.totalPage}
          totalRecords={rowDataFinal.totalRecords}
        />
      )}
    </div>
  );
};
