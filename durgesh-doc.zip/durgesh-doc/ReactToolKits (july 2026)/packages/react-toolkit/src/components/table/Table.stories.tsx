import type { Meta, StoryObj } from '@storybook/react-vite';
import { Table } from "./Table";
import { TableProps } from "./Table.types";
import React from "react";
import { expect, fn, userEvent, within } from 'storybook/test';

export const ActionsData = {
  onRowSelected: fn(),
  onCellClicked: fn(),
};

const defaultColumnDefs: TableProps["columnDefs"] = [
  { field: "name", headerName: "Name", sortable: true, filter: true },
  { field: "age", headerName: "Age", sortable: true },
  { field: "city", headerName: "City", filter: true },
  { field: "status", headerName: "Status", filter: true },
]

const meta = {
  title: "Components/Table",
  component: Table,
  tags: ['autodocs'],
  excludeStories: /.*Data$/,
  args: {
    ...ActionsData,
    tableId: "demo-table",
    tableName: "Demo Table",
    tableHeight: "300px",
    tableWidth: "600px",
    columnDefs: defaultColumnDefs,
    rowData: [
      { name: "Aarav", age: 24, city: "Mumbai", status: "active", },
      { name: "Riya", age: 29, city: "Delhi", status: "inactive" },
      { name: "Kabir", age: 31, city: "Pune", status: "active" },
    ],
    showPagination: false
  },
} satisfies Meta<typeof Table>;

export default meta;
type Story = StoryObj<typeof meta>;



export const Default: Story = {
  args: {},
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    await new Promise(resolve => setTimeout(resolve, 500));

    const tableContainer = canvas.getByRole('grid') ||
      canvasElement.querySelector('.table-grid') ||
      canvasElement.querySelector('.ag-root-wrapper');

    await expect(tableContainer).toBeInTheDocument();

    await expect(canvas.getByText('Name')).toBeInTheDocument();
    await expect(canvas.getByText('Age')).toBeInTheDocument();
    await expect(canvas.getByText('City')).toBeInTheDocument();
    await expect(canvas.getByText('Status')).toBeInTheDocument();


    await expect(canvas.getByText('Aarav')).toBeInTheDocument();
    await expect(canvas.getByText('Mumbai')).toBeInTheDocument();

    const nameHeader = canvas.getByText('Name');

    let filterButton;

    const nameHeaderCell = nameHeader.closest('[role="columnheader"]');
    if (nameHeaderCell) {
      filterButton = nameHeaderCell.querySelector('[class*="filter"], [class*="ag-icon-filter"], button');
    }

    if (!filterButton) {
      const menuButton = nameHeaderCell?.querySelector('[class*="menu"], [class*="ag-icon-menu"]');
      if (menuButton) {
        filterButton = menuButton;
      }
    }

    if (!filterButton) {
      const allFilterButtons = canvasElement.querySelectorAll('[class*="filter"], [class*="ag-header-filter-icon"]');
      if (allFilterButtons.length > 0) {
        filterButton = allFilterButtons[0];
      }
    }

    if (filterButton) {

      await userEvent.click(filterButton as HTMLElement);

      await new Promise(resolve => setTimeout(resolve, 300));

      const filterOverlay = document.querySelector('.ag-filter, .ag-popup, [class*="filter-popup"]');

      if (filterOverlay) {

        const filterInput = filterOverlay.querySelector('input[type="text"], input[placeholder*="Filter"], input');

        if (filterInput) {

          await userEvent.type(filterInput as HTMLInputElement, 'Aarav');

          await new Promise(resolve => setTimeout(resolve, 500));

          await expect(canvas.getByText('Aarav')).toBeInTheDocument();
          await new Promise(resolve => setTimeout(resolve, 300));

          await userEvent.clear(filterInput as HTMLInputElement, 'Aarav');

        }
      }
    } else {
      console.log('Filter button not found - AG Grid might not have visible filter icons');
    }
  },
};


const WithApiColumnDefs: TableProps["columnDefs"] = [
  { field: "mission", headerName: "Mission", sortable: true, filter: true },
  { field: "company", headerName: "Company", sortable: true },
  { field: "location", headerName: "Location", filter: true },
  { field: "date", headerName: "Date" },
  { field: "rocket", headerName: "Rocket" },
  { field: "price", headerName: "Price" },
  { field: "successful", headerName: "Successful" },
]

export const WithApi: Story = {
  args: {
    tableId: "api-table",
    tableName: "Space Missions Table",
    tableHeight: "400px",
    tableWidth: "100%",
    columnDefs: WithApiColumnDefs,
    suppressHorizontalScroll: false,
    api: {
      url: "https://www.ag-grid.com/example-assets/space-mission-data.json",
    },
    rowData: [],
    apiResponseMapper: (data) => ({ data: data.slice(0, 50) })
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    await new Promise(resolve => setTimeout(resolve, 500));

    await expect(canvas.getByText('Mission')).toBeInTheDocument();
    await expect(canvas.getByText('Company')).toBeInTheDocument();
    await expect(canvas.getByText('Location')).toBeInTheDocument();
    await expect(canvas.getByText('Date')).toBeInTheDocument();
    await expect(canvas.getByText('Rocket')).toBeInTheDocument();
    await expect(canvas.getByText('Price')).toBeInTheDocument();
    await expect(canvas.getByText('Successful')).toBeInTheDocument();

    const tableRows = canvasElement.querySelectorAll('[role="row"][row-index]');
    await expect(tableRows.length).toBeGreaterThan(0);

    const missionHeader = canvas.getByText('Mission');

    let filterButton;

    const missionHeaderCell = missionHeader.closest('[role="columnheader"]');
    if (missionHeaderCell) {
      filterButton = missionHeaderCell.querySelector('[class*="filter"], [class*="ag-icon-filter"], button');
    }

    if (!filterButton) {
      const allFilterButtons = canvasElement.querySelectorAll('[class*="filter"], [class*="ag-header-filter-icon"]');
      if (allFilterButtons.length > 0) {
        filterButton = allFilterButtons[0];
      }
    }

    if (!filterButton) {
      const menuButton = canvasElement.querySelector('[class*="ag-menu"], [class*="ag-icon-menu"]');
      if (menuButton) {
        filterButton = menuButton;
      }
    }

    if (filterButton) {

      await userEvent.click(filterButton as HTMLElement);

      await new Promise(resolve => setTimeout(resolve, 500));

      const filterPopup = document.querySelector('.ag-filter, .ag-popup, [class*="filter-popup"]');

      if (filterPopup) {
        const filterInput = filterPopup.querySelector('input[type="text"], input[placeholder*="Filter"], input');

        if (filterInput) {

          await userEvent.type(filterInput as HTMLInputElement, 'Space');

          await new Promise(resolve => setTimeout(resolve, 1000));

          const filteredRows = canvasElement.querySelectorAll('[role="row"][row-index]');
          await expect(filteredRows.length).toBeGreaterThan(0);

          await userEvent.clear(filterInput as HTMLInputElement);
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
    } else {
      console.log('Filter button not found - skipping filter test');
    }

    await userEvent.click(missionHeader);
    await new Promise(resolve => setTimeout(resolve, 300));

    const paginationControls = canvasElement.querySelector('[class*="pagination"], [class*="ag-paging"]');
    if (paginationControls) {

      const pageButtons = paginationControls.querySelectorAll('button');
      if (pageButtons.length > 1) {

        const nextButton = Array.from(pageButtons).find(btn =>
          btn.textContent?.includes('Next') || btn.textContent?.includes('>')
        );
        if (nextButton) {
          await userEvent.click(nextButton);
          await new Promise(resolve => setTimeout(resolve, 300));
        }
      }
    }

    const firstDataCell = canvasElement.querySelector('[role="gridcell"]');
    if (firstDataCell) {
      await expect(firstDataCell).toBeInTheDocument();
    }
  },
};

