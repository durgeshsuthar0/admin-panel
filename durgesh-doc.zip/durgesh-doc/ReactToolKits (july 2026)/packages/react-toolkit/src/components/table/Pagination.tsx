import React, { useMemo } from 'react';
import { chevronRight, chevronLeft } from '../../assets/svg';
import { classname } from '@msbc/utils';
import { PaginationProps } from './Table.types';

type PageItem = number | 'ellipsis';

export const Pagination = ({
  currentPage,
  totalRecords,
  totalPage,
  onPageChange,
}: PaginationProps) => {
  const cn = classname('table-grid');

  const getPages = (): PageItem[] => {
    if (totalPage <= 7) {
      return Array.from({ length: totalPage }, (_, i) => i + 1);
    }

    const pages: PageItem[] = [];

    pages.push(1);

    if (currentPage > 4) {
      pages.push('ellipsis');
    }

    const start = Math.max(2, currentPage - 1);
    const end = Math.min(totalPage - 1, currentPage + 1);

    for (let i = start; i <= end; i++) {
      pages.push(i);
    }

    if (currentPage < totalPage - 3) {
      pages.push('ellipsis');
    }

    pages.push(totalPage);

    return pages;
  };

  const pages = useMemo(getPages, [currentPage, totalPage]);

  const handleNext = () => {
    if (currentPage < totalPage) {
      onPageChange(currentPage + 1);
    }
  };

  const handlePrevious = () => {
    if (currentPage > 1) {
      onPageChange(currentPage - 1);
    }
  };

  return (
    <div className={cn('pagination')}>
      <div className={cn('pagination-summary-container')}>
        <span className={cn('pagination-summary')}>
          Showing page {currentPage} of {totalPage} ({totalRecords} results)
        </span>
      </div>

      <div className={cn('pagination-container')}>
        <div
          className={cn('pagination-icon-container', {
            isDisabled: currentPage === 1,
          })}
          onClick={handlePrevious}
        >
          <span className={cn('pagination-icon')}>{chevronLeft}</span>
        </div>

        <div className={cn('pagination-pages')}>
          {pages.map((item, index) =>
            item === 'ellipsis' ? (
              <span key={`ellipsis-${index}`} className={cn('pagination-ellipsis')}>
                …
              </span>
            ) : (
              <div
                key={item}
                className={cn('pagination-page', {
                  ActivePage: currentPage === item,
                })}
                onClick={() => onPageChange(item)}
              >
                {item}
              </div>
            )
          )}
        </div>

        <div
          className={cn('pagination-icon-container', {
            isDisabled: currentPage === totalPage,
          })}
          onClick={handleNext}
        >
          <span className={cn('pagination-icon')}>{chevronRight}</span>
        </div>
      </div>
    </div>
  );
};
