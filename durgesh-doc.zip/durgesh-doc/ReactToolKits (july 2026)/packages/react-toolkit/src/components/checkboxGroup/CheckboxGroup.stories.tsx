import React, { useState } from "react";
import type { Meta, StoryObj } from '@storybook/react-vite';
import { CheckboxGroup } from "./CheckboxGroup";
import { CheckboxGroupProps } from "./CheckboxGroup.types";
import { expect, fn, userEvent, within } from 'storybook/test';

export const ActionsData = {
  onChange: fn(),
};

const meta = {
  component: CheckboxGroup,
  title: 'Components/CheckboxGroup',
  tags: ['autodocs'],
  //👇 Our exports that end in "Data" are not stories.
  excludeStories: /.*Data$/,
  args: {
    ...ActionsData,
    label: "Select Options",
    isRequired: false,
    isDisabled: false,
    value: ['option1'],
    options: [
      { value: "option1", label: "Option 1" },
      { value: "option2", label: "Option 2" },
      { value: "option3", label: "Option 3" },
    ],
    direction: "vertical",
  },
} satisfies Meta<typeof CheckboxGroup>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    const option2 = canvas.getByLabelText('Option 2');
    await userEvent.click(option2);

    await expect(args.onChange).toHaveBeenCalled();
    await expect(args.onChange).toHaveBeenCalledWith('option2');
  },
  args: {
  },
};

export const Horizontal: Story = {
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    await expect(
      canvas.getByText('Select Options (Horizontal)')
    ).toBeInTheDocument();
  },
  args: {
    label: "Select Options (Horizontal)",
    direction: "horizontal",
  },
};


export const Required: Story = {
  args: {
    label: 'Required Options',
    isRequired: true,
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    const group = canvas.getByRole('group');

    expect(group).toHaveAttribute('aria-required', 'true');
  },
};

export const Disabled: Story = {
  args: {
    label: 'Disabled Options',
    isDisabled: true,
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    const checkbox = canvas.getByLabelText('Option 1');
    await expect(checkbox).toBeDisabled();
  },
};


export const WithError: Story = {
  args: {
    label: 'Options with Error',
    isRequired: true,
    error: 'This field is required.',
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    await expect(
      canvas.getByText('This field is required.')
    ).toBeInTheDocument();
  },
}

export const Demo: Story = {
  parameters: {
    docs: {
      disable: true,
    },
  },
  render: () => {
    const [value, setValue] = useState<string>('');
    const [multiValue, setMultiValue] = useState<Array<string>>(['']);

    const handleOnChange = (value: string) => {
      setValue(value);
    };

    const handleMultiOnChange = (value: string[]) => {
      setMultiValue(value);
    };

    return (

      <React.Fragment>

        <CheckboxGroup
          label="Single select Demo"
          options={[
            { value: "option1", label: "Option 1" },
            { value: "option2", label: "Option 2" },
            { value: "option3", label: "Option 3" },
          ]}
          value={value}
          onChange={handleOnChange} // eslint-disable-line react/jsx-no-bind
        />

        <CheckboxGroup
          label="Multi select Demo"
          options={[
            { value: "option1", label: "Option 1" },
            { value: "option2", label: "Option 2" },
            { value: "option3", label: "Option 3" },
          ]}
          value={multiValue}
          isMultiple={true}
          onChange={handleMultiOnChange} // eslint-disable-line react/jsx-no-bind
        />

      </React.Fragment>

    );
  },

  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    const singleOption = canvas.getAllByLabelText('Option 1')[0];
    const multiOption = canvas.getAllByLabelText('Option 1')[1];

    await userEvent.click(singleOption);
    await userEvent.click(multiOption);

    await expect(singleOption).toBeChecked();
    await expect(multiOption).toBeChecked();
  },

};
