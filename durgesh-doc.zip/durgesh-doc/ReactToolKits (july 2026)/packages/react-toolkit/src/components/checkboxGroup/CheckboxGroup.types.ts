import type { UseApiOptions } from '@msbc/data-layer';

type Option = {
  label: React.ReactNode;
  value: string;
  isDisabled?: boolean;
};

type BaseProps = {
  className?: string;
  label?: React.ReactNode;
  isRequired?: boolean;
  error?: string;
  isDisabled?: boolean;
  options: Option[];
  direction?: 'horizontal' | 'vertical';
  helpText?: string;
  name?: string;
  labelKey?: string;
  valueKey?: string;
  api?: UseApiOptions;
  // TODO: remove in favor of apiResponseMapper in future major version
  apiResponseMapper?: (data: any) => any[];
  loadingComponent?: React.ReactNode;
};

export type CheckboxGroupProps =
  | (BaseProps & {
      isMultiple: true;
      value: (string | number | boolean)[];
      onChange: (value: (string | number | boolean)[]) => void;
    })
  | (BaseProps & {
      isMultiple?: false;
      value: string | number | boolean;
      onChange: (value: string | number | boolean) => void;
    });
