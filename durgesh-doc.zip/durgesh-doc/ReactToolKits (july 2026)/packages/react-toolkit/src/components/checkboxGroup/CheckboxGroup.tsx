import React, { useMemo, useEffect } from 'react';
import { classname, cns } from '@msbc/utils';
import { FormFieldWrapper } from '../formFieldWrapper/FormFieldWrapper';
import Checkbox from '../checkbox/Checkbox';
import { CheckboxGroupProps } from './CheckboxGroup.types';
import './CheckboxGroup.scss';
import { useApiRequest } from '@msbc/data-layer';

function isMultipleProps(
  props: CheckboxGroupProps
): props is Extract<CheckboxGroupProps, { isMultiple: true }> {
  return props.isMultiple === true;
}

export const CheckboxGroup = (props: CheckboxGroupProps) => {
  const cn = classname('checkbox-group');

  const {
    className = '',
    label,
    isRequired = false,
    error,
    isDisabled = false,
    options,
    direction = 'vertical',
    helpText = '',
    name,
    api,
    labelKey = '',
    valueKey = '',
    apiResponseMapper,
    loadingComponent,
  } = props;

  const {
    url,
    method,
    params,
    body,
    config,
    autoFetch
  } = api || {};

  const { data, loading, execute } = useApiRequest({
    url: url || '',
    method: method || "get",
    params: params,
    body: body,
    config: config,
    autoFetch: autoFetch || false,
  });

  const finalOptions = useMemo(() => {
    if (api && data) {
      const rawData: any[] = apiResponseMapper?.(data) || data;
      const apiOptions = Array.isArray(rawData)
        ? rawData.map((item: any,) => ({

          label: labelKey ? item[labelKey] : item.label,
          value: valueKey ? item[valueKey] : item.value,

        } as {
          label: string;
          value: string | number | boolean;
          isDisabled?: boolean;
        }))
        : [];

      return apiOptions;
    }
    return options;
  }, [options, data, api]);

  useEffect(() => {
    if (url && !autoFetch) {
      execute({
        url: url,
        params: params,
        body: body,   // optional (only if needed)
        config: config // optional
      });
    }
  }, [url, params, body, config, autoFetch]);

  const isSelected = (val: string | number | boolean) => {
    if (isMultipleProps(props)) {
      return props.value.includes(val);
    }
    return props.value === val;
  };

  const handleOnChange = (
    val: string | number | boolean,
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    if (isMultipleProps(props)) {
      const valueArray = props.value;
      props.onChange(
        valueArray.includes(val)
          ? valueArray.filter((x) => x !== val)
          : [...valueArray, val]
      );
    } else {
      props.onChange(event.target.checked ? val : "");
    }
  };

  return (
    <FormFieldWrapper
      className={cns(cn(), className)}
      label={label}
      isRequired={isRequired}
      error={error}
      isDisabled={isDisabled}
      helpText={helpText}
    >
      <div
        role="group"
        aria-required={isRequired || undefined}
        aria-disabled={isDisabled || undefined}
        className={cn("options", {
          "is-horizontal": direction === "horizontal",
          "is-vertical": direction === "vertical",
        })}
      >
        {(!loading && finalOptions) ? finalOptions.map((option) => (
          <Checkbox
            key={String(option.value)}
            className={cn("checkbox")}
            label={option.label}
            value={option.value}
            name={name}
            onChange={handleOnChange}
            isSelected={isSelected(option.value)}
            isDisabled={isDisabled || option.isDisabled}
          />
        )) : (
          loadingComponent || <p>Loading...</p>
        )}
      </div>
    </FormFieldWrapper>
  );
};
