import { useEffect, useMemo, useState } from 'react';
import { ListProps } from './List.types';
import { useApiRequest } from '@msbc/data-layer';
import { FormFieldWrapper } from '../formFieldWrapper/FormFieldWrapper';
import { isEmpty } from '@msbc/utils';

export function List({
  label,
  isRequired = false,
  isDisabled = false,
  isMultiSelect = true,
  error,
  options,
  api,
  CardComponent,
  mapItem,
  className = '',
  loadingComponent = 'Loading...',
  scroll = false,
  scrollHeight = '400px',
  minHeight = '200px',
  onChange,
  layout = {
    columns: 1,
    gap: '12px',
    cardWidth: '1fr',
    wrap: true,
    padding: '10px',
    margin: '2px',
  },
  value,
  apiResponseMapper,
  emptyComponent,
  loading = false,
}: ListProps) {
  const { url, method, params, body, config, autoFetch } = api || {};

  const {
    data: apiData,
    loading: apiLoading,
    apiError,
    execute,
  } = useApiRequest({
    url: url || '',
    method: method || 'get',
    params: params,
    config: config,
    autoFetch: autoFetch || false,
  });
  const [selectedItems, setSelectedItems] = useState<any[] | string | undefined>(isEmpty(value) ? (isMultiSelect ? [] : undefined) : value);

  useEffect(() => {
    setSelectedItems(isEmpty(value) ? (isMultiSelect ? [] : undefined) : value);
  }, [value]);

  useEffect(() => {
    if (api && !autoFetch) {
      execute({
        params: api.params,
        body: api.body,
        config: api.config,
      });
    }
  }, [params, body, autoFetch]);

  const finalList = useMemo(() => {
    let rawData: any[] = [];
    if (api && apiData) {
      rawData = apiResponseMapper?.(apiData) || apiData;
    } else if (options) {
      rawData = options;
    }

    const finalMapItem = mapItem ?? ((item: any) => item);
    return rawData.map(finalMapItem);
  }, [apiData, options, mapItem]);

  const handleOnChange = (item: any) => {
    if (isMultiSelect) {
      setSelectedItems((prev) => {
        const exists = ((prev as any[]) || []).some(
          (p) => JSON.stringify(p) === JSON.stringify(item)
        );
        const updated = exists
          ? ((prev as any[]) || []).filter((p) => JSON.stringify(p) !== JSON.stringify(item))
          : [...(prev || []), item];
        onChange?.(updated);
        return updated;
      });
    } else {
      const selected = item;
      setSelectedItems(selected);
      onChange?.(selected);
      return;
    }
  };

  if (apiError) {
    return <div>Error: {String(apiError)}</div>;
  }

  const { columns, gap, cardWidth, wrap, padding, margin } = layout;

  return (
    <FormFieldWrapper
      label={label}
      isRequired={isRequired}
      error={error}
      isDisabled={isDisabled}
      className=""
    >
      {(!apiLoading && !loading && finalList.length === 0) &&
        (emptyComponent ?? <div>No records found</div>)
      }

      {(apiLoading || loading) && (
        loadingComponent
      )}

      {!apiLoading && !loading && finalList.length > 0 && (
        <div
          className={`rtk-list-container ${className}`}
          style={{
            display: 'grid',
            gridTemplateColumns: `repeat(${columns}, ${cardWidth})`,
            gap: gap,
            flexWrap: wrap ? 'wrap' : 'nowrap',
            overflowY: scroll ? 'auto' : 'visible',
            maxHeight: scroll ? scrollHeight : undefined,
            minHeight: minHeight,
            padding: padding,
            margin: margin,
          }}
        >
          {finalList.map((item, idx) => {
            const itemsArray = Array.isArray(selectedItems)
              ? selectedItems
              : selectedItems
                ? [selectedItems]
                : [];

            const isSelected = itemsArray.some(
              (selected) => JSON.stringify(selected) === JSON.stringify(item)
            );

            return (
              <CardComponent
                key={idx}
                item={item}
                selected={isSelected}
                onChange={() => handleOnChange(item)}
              />
            );
          })}
        </div>
      )}
    </FormFieldWrapper>
  );
}
