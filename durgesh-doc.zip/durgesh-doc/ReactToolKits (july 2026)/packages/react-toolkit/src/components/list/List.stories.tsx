import { Meta, StoryObj } from "@storybook/react";
import { List } from "./List";
import { ListProps } from "./List.types";

// ---- Example Card Component ----
const DemoCard = ({ item, selected, onChange }: any) => {
  return (
    <div
      onClick={onChange}
      style={{
        padding: "12px",
        borderRadius: "8px",
        cursor: "pointer",
        background: selected ? "#d0e8ff" : "#fff",
        border: selected ? "2px solid #1a73e8" : "1px solid #ddd",
        transition: "0.2s",
      }}
    >
      <strong>{item?.label}</strong>
    </div>
  );
};

const meta = {
  title: "Components/List",
  component: List,
  tags: ["autodocs"],
  excludeStories: /.*Data$/,
   args: {
    label: "Select Items",
    isRequired: false,
    isDisabled: false,
    error: "",
    className: "",
    scroll: true,
    scrollHeight: "300px",
    minHeight: "200px",
    layout: {
      columns: 3,
      gap: "12px",
      wrap: true,
      cardWidth: "1fr",
      padding: "10px",
      margin: "4px",
    },
    CardComponent: DemoCard,
  },
} satisfies Meta<ListProps>;

export default meta;
type Story = StoryObj<ListProps>;

const Template = (args: ListProps) => <List {...args} />;


export const Default: Story = {
  render: Template,
  args: {
    options: [
      { id: 1, label: "Option 1" },
      { id: 2, label: "Option 2" },
      { id: 3, label: "Option 3" },
      { id: 4, label: "Option 4" },
      { id: 5, label: "Option 5" },
    ],
  },
};

export const WithPreselectedItems: Story = {
  render: Template,
  args: {
    options: [
      { id: 1, label: "Option 1" },
      { id: 2, label: "Option 2" },
      { id: 3, label: "Option 3" },
    ],
    value: [{ id: 2, label: "Option 2" }],
  },
};

export const TwoColumns: Story = {
  render  : Template,
  args: {
    layout: {
      columns: 2,
      gap: "16px",
      wrap: true,
      cardWidth: "1fr",
      padding: "10px",
      margin: "4px",
    },
    options: Array.from({ length: 10 }, (_, i) => ({
      id: i + 1,
      label: `Item ${i + 1}`,
    })),
  },
};

export const CustomMapping: Story = {
  render: Template,
  args: {
    options: [
      { name: "John Doe", age: 28 },
      { name: "Alice", age: 22 },
    ],
    mapItem: (item) => ({
      label: `${item.name} (${item.age})`,
      raw: item,
    }),
  },
};

export const LoadingState: Story = {
  render: Template,
  args: {
    loadingComponent: <div>Loading data...</div>,
    api: {
      url: "/mock-api/users",
      method: "get",
      autoFetch: true,
    },
  },
  parameters: {
    mockData: [
      {
        url: "/mock-api/users",
        method: "GET",
        status: 200,
        delay: 1500,
        response: [
          { label: "Mock User 1" },
          { label: "Mock User 2" },
        ],
      },
    ],
  },
};
