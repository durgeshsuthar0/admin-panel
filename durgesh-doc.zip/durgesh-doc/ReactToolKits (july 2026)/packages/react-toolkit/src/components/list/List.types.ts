import type { UseApiOptions } from '@msbc/data-layer';

export interface ListProps {
  label?: React.ReactNode;
  isRequired?: boolean;
  isDisabled?: boolean;
  isMultiSelect?: boolean;
  error?: string;
  options?: any[];
  api?: UseApiOptions;
  CardComponent: React.FC<{ item: any; onChange?: () => void; selected?: boolean }>;
  mapItem?: (item: any) => any;
  className?: string;
  loadingComponent?: React.ReactNode;
  scroll?: boolean;
  scrollHeight?: string | number;
  minHeight?: string | number;
  layout?: {
    columns?: number;
    gap?: string;
    cardWidth?: string;
    wrap?: boolean;
    padding?: string;
    margin?: string;
  };
  onChange?: (item: any) => void;
  value?: any[] | string;
  // TODO: remove in favor of apiResponseMapper in future major version
  apiResponseMapper?: (data: any) => any[];
  emptyComponent?: React.ReactNode;
  loading?: boolean;
}
