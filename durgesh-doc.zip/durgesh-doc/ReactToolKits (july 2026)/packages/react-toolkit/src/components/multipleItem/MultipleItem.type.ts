import { DropdownProps } from '../dropdown/Dropdown.types';
import { CheckboxGroupProps } from '../checkboxGroup/CheckboxGroup.types';
import { RadioProps } from '../radio/RadioGroup.types';
import { FileUploadProps } from '../fileUpload/FileUpload.types';
import { InputProps } from '../input/Input.types';

export interface DynamicRow {
  id: string;
  values: Record<string, any>;
}

/* ---------- BASE FIELD ---------- */
export interface BaseField {
  name: string;
  label?: string;
  default?: any;
  colSpan?: number;
  rowSpan?: number;

  // dependsOn?: {
  //   parentField: string;
  //   mapParamTo: string;

  //   clearOnParentChange?: boolean;
  //   disabledWhenEmptyParent?: boolean;
  // };
}

/* ---------- FIELD TYPES ---------- */
interface InputField extends BaseField, Omit<InputProps, 'value' | 'onChange' | 'name' | 'label'> {
  type: 'input';
}

export interface SelectField
  extends BaseField, Omit<DropdownProps, 'value' | 'onChange' | 'name' | 'label'> {
  type: 'select';
}

interface CheckboxField
  extends BaseField, Omit<CheckboxGroupProps, 'value' | 'onChange' | 'label' | 'name'> {
  type: 'checkbox';
}

interface RadioField extends BaseField, Omit<RadioProps, 'value' | 'onChange' | 'label'> {
  type: 'radio';
}

interface FileUploadField
  extends BaseField, Omit<FileUploadProps, 'onFileChange' | 'label' | 'name'> {
  type: 'fileUpload';
}

export type MultiFieldSchema =
  | InputField
  | SelectField
  | CheckboxField
  | RadioField
  | FileUploadField;

/* ---------- MULTI INPUT ---------- */
export interface MultiInputProps {
  schema: MultiFieldSchema[];
  data: DynamicRow;
  errors?: Record<string, string>;
  onFieldChange: (rowId: string, name: string, value: any) => void;
  onRemove: (rowId: string) => void;
  count: number;
}

export interface MultipleItemProps {
  className?: string;
  label: string;
  fields: MultiFieldSchema[];
  initialRows?: Array<Record<string, any> | DynamicRow>;
  onChange: (rows: Array<Record<string, any>>) => void;
  error?: string;
}
