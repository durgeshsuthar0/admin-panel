import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { classname, cns } from '@msbc/utils';
import './MultipleItem.scss';
import { Button } from '../button';
import MultiInput from './MultiInput';
import { DynamicRow, MultipleItemProps } from './MultipleItem.type';
import { FormFieldWrapper } from '../formFieldWrapper';

const makeId = () =>
  typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(16).slice(2)}`;

export const MultipleItem: React.FC<MultipleItemProps> = ({
  className = '',
  fields,
  initialRows = [],
  onChange,
  label,
  error,
}) => {
  const cn = classname('multiple-item');

  const emptyValues = useMemo(() => {
    return fields.reduce(
      (acc, field) => {
        acc[field.name] = field.default ?? '';
        return acc;
      },
      {} as Record<string, any>
    );
  }, [fields]);

  const createEmptyRow = useCallback((): DynamicRow => {
    return {
      id: makeId(),
      values: { ...emptyValues },
    };
  }, [emptyValues]);

  const normalizeInitial = useMemo<DynamicRow[]>(() => {
    if (!initialRows?.length) return [createEmptyRow()];

    return initialRows.map((values) => ({
      id: makeId(),
      values: { ...emptyValues, ...values },
    }));
  }, [initialRows, emptyValues, createEmptyRow]);

  const [rows, setRows] = useState<DynamicRow[]>(normalizeInitial);

  const addRow = useCallback(() => {
    setRows((prev) => [...prev, createEmptyRow()]);
  }, [createEmptyRow]);

  const removeRow = useCallback((id: string) => {
    setRows((prev) => (prev.length > 1 ? prev.filter((r) => r.id !== id) : prev));
  }, []);

  const updateField = useCallback(
    (rowId: string, name: string, value: any) => {
      setRows((prev) =>
        prev.map((row) => {
          if (row.id !== rowId) return row;

          const nextValues = { ...row.values, [name]: value };

          // fields.forEach((f) => {
          //   if (f.dependsOn && f.dependsOn.parentField === name) {
          //     const shouldClear = f.dependsOn.clearOnParentChange ?? true;
          //     if (shouldClear) nextValues[f.name] = f.default ?? '';
          //   }
          // });

          return { ...row, values: nextValues };
        })
      );
    },
    [fields]
  );

  useEffect(() => {
    onChange(rows);
  }, [rows])

  useEffect(() => {
    if (!initialRows.length) {
      setRows(normalizeInitial);
    }
  }, [initialRows])

  const setAllRows = useCallback(
    (nextRows: Array<Record<string, any>>) => {
      setRows(
        nextRows?.length
          ? nextRows.map((values) => ({ id: makeId(), values: { ...emptyValues, ...values } }))
          : [createEmptyRow()]
      );
    },
    [createEmptyRow, emptyValues]
  );

  useEffect(() => {
    if (initialRows) {
      setAllRows(initialRows);
    }

  }, []);

  return (
    <FormFieldWrapper
      className={cns(className, cn())}
      label={label}
      error={error}
    >
      <div className={cn('multiple-item-container')}>
        <div className={cn('main-content')}>
          <table className={cn('table')}>
            <thead>
              <tr className={cn('row')}>
                {fields.map((field) => (
                  <th className={cn('td')}>{field.label}</th>
                ))}
                <th className={cn('action')}></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((item, idx) => (
                <MultiInput
                  key={item.id}
                  schema={fields}
                  count={rows.length}
                  data={item}
                  onFieldChange={updateField}
                  onRemove={removeRow}
                />
              ))}
            </tbody>
          </table>
          <div
            className={cn('add-button')}
          ><Button text="Add Item" type='button' onClick={addRow} /></div>
        </div>
      </div>
    </FormFieldWrapper>
  );
};
