import React, { useState, memo, useCallback, useMemo } from 'react';
import './MultipleItem.scss';
import { classname } from '@msbc/utils';
import { DeleteIcon } from '../../assets/svg';
import { Dropdown } from '../dropdown';
import { CheckboxGroup } from '../checkboxGroup/CheckboxGroup';
import { RadioGroup } from '../radio/RadioGroup';
import { Input } from '../input';
import { FileUpload } from '../fileUpload/FileUpload';
import { MultiInputProps, MultiFieldSchema, SelectField } from './MultipleItem.type';


const getComparableValue = (v: any) =>
  v && typeof v === "object" && "value" in v ? v.value : v;

const hasParentSelection = (v: any) => {
  const cv = getComparableValue(v);
  return cv !== undefined && cv !== null && !(typeof cv === "string" && cv.trim() === "");
};

const DependentSelectCell = memo(function DependentSelectCell({
  field,
  rowId,
  values,
  error,
  onFieldChange,
}: {
  field: SelectField;
  rowId: string;
  values: Record<string, any>;
  error?: any;
  onFieldChange: (id: string, name: string, value: any) => void;
}) {
  const dep = field.dependsOn;
  const isApiDependent = Boolean(field.api && field.dependsOn?.parentField);
  const parentField = dep?.parentField;
  const watchedParent = parentField ? values[parentField] : undefined;
  const parentComparable = getComparableValue(watchedParent);
  const parentSelected = hasParentSelection(watchedParent);

  const baseApiRef = React.useRef(field.api);
  const baseUrlRef = React.useRef(field.api?.url);

  const [apiConfig, setApiConfig] = useState(() => (isApiDependent ? undefined : field.api));


  const prevParentComparable = React.useRef<any>(undefined);
  const didInit = React.useRef(false);

  React.useEffect(() => {
    if (!dep) {
      setApiConfig(field.api);
      return;
    }

    if (!parentSelected) {
      setApiConfig(undefined);

      if (didInit.current) {
        onFieldChange(rowId, field.name, null);
      }
    } else {
      if (!didInit.current || prevParentComparable.current !== parentComparable) {
        const updated = { ...(baseApiRef.current || {}) };

        // mapParamTo is your query param key
        if (dep.mapParamTo) {
          updated.params = {
            ...(updated.params || {}),
            [dep.mapParamTo]: parentComparable,
          };
        }

        // if (dep.appendToUrl) updated.url = `${baseUrlRef.current}/${parentComparable}`;

        setApiConfig(updated);

        if (didInit.current) {
          onFieldChange(rowId, field.name, null);
        }
      }
    }

    didInit.current = true;
    prevParentComparable.current = parentComparable;
  }, [dep, parentSelected, parentComparable, field.api, field.name, onFieldChange, rowId]);

  const disabled =
    field.isDisabled ||
    ((dep?.disabledWhenEmptyParent ?? true) && !!dep && !parentSelected);

  const handleChange = useCallback(
    (val: any) => onFieldChange(rowId, field.name, val),
    [rowId, field.name, onFieldChange]
  );

  return (
    <Dropdown
      {...field}
      api={apiConfig}
      value={values[field.name]}
      error={error}
      onChange={handleChange}
    />
  );
});

const MultiInput: React.FC<MultiInputProps> = ({
  schema,
  data,
  errors,
  count,
  onFieldChange,
  onRemove,
}) => {
  const cn = classname('multiple-item');
  const { id, values } = data;

  const renderField = (field: MultiFieldSchema) => {
    const value = values[field.name];
    const error = errors?.[field.name];

    switch (field.type) {
      case 'select': {
        return (
          <DependentSelectCell
            field={field}
            rowId={id}
            values={values}
            error={error}
            onFieldChange={onFieldChange}
          />
        );
      }

      case 'checkbox': {
        return (
          <CheckboxGroup
            {...field}
            label=''
            isMultiple={false}
            value={value}
            error={error}
            onChange={(val) => onFieldChange(id, field.name, val)}
          />
        );
      }

      case 'radio': {
        return (
          <RadioGroup
            {...field}
            label=''
            value={value}
            error={error}
            onChange={(val) => onFieldChange(id, field.name, val)}
          />
        );
      }

      case 'fileUpload': {
        return (
          <FileUpload
            label=''
            error={error}
            onupdatefiles={(fileItems) => {

              const value = fileItems.map((item) => {
                // New upload
                if (item.file instanceof File) {
                  return item.file;
                }

                if (typeof item.source === 'string') {
                  return {
                    source: item.source,
                    options: {
                      type: 'local',
                      file: item.file ?? {
                        name: item.filename || 'existing-file',
                        size: item.fileSize || 0,
                        type: item.fileType || 'image/*'
                      }
                    }
                  };
                }

                return null;
              }).filter(Boolean);

              onFieldChange(id, field.name, value);
            }}
          />
        );
      }

      default: {
        return (
          <Input
            {...field}
            label=''
            value={value ?? ''}
            error={error}
            onChange={(e) => onFieldChange(id, field.name, e.target.value)}
          />
        );
      }
    }
  };

  return (
    <tr className={cn('row')}>

      {schema.map((field) => (
        <td className={cn('td')} key={field.name}>
          {renderField(field)}
        </td>
      ))}

      <td
        className={cn('td')}
      >
        <button type="button" disabled={count === 1} className={cn("delete-icon")} onClick={() => onRemove(id)}>{DeleteIcon}</button>
      </td>
    </tr>
  );
};

export default MultiInput;
