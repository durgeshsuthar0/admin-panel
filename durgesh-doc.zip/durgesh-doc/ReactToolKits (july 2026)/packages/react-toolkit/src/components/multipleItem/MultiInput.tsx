import React, { useState, memo } from 'react';
import './MultipleItem.scss';
import { classname } from '@msbc/utils';
import { DeleteIcon } from '../../assets/svg';
import { Dropdown } from '../dropdown';
import { CheckboxGroup } from '../checkboxGroup/CheckboxGroup';
import { RadioGroup } from '../radio/RadioGroup';
import { Input } from '../input';
import { FileUpload } from '../fileUpload/FileUpload';
import { MultiInputProps, MultiFieldSchema } from './MultipleItem.type';

const MultiInput: React.FC<MultiInputProps> = ({
  schema,
  data,
  errors,
  count,
  onFieldChange,
  onRemove,
}) => {
  const cn = classname('multiple-item');
  const { id, values } = data;

  const renderField = (field: MultiFieldSchema) => {
    const value = values[field.name];
    const error = errors?.[field.name];

    switch (field.type) {
      case 'select': {
        return (
          <Dropdown
            {...field}
            value={value}
            error={error}
            onChange={(val) => onFieldChange(id, field.name, val)}
          />
        );
      }

      case 'checkbox': {
        return (
          <CheckboxGroup
            {...field}
            label=''
            isMultiple={false}
            value={value}
            error={error}
            onChange={(val) => onFieldChange(id, field.name, val)}
          />
        );
      }

      case 'radio': {
        return (
          <RadioGroup
            {...field}
            label=''
            value={value}
            error={error}
            onChange={(val) => onFieldChange(id, field.name, val)}
          />
        );
      }

      case 'fileUpload': {
        return (
          <FileUpload
            label=''
            error={error}
            onupdatefiles={(fileItems) => {

              const value = fileItems.map((item) => {
                // New upload
                if (item.file instanceof File) {
                  return item.file;
                }

                if (typeof item.source === 'string') {
                  return {
                    source: item.source,
                    options: {
                      type: 'local',
                      file: item.file ?? {
                        name: item.filename || 'existing-file',
                        size: item.fileSize || 0,
                        type: item.fileType || 'image/*'
                      }
                    }
                  };
                }

                return null;
              }).filter(Boolean);

              onFieldChange(id, field.name, value);
            }}
          />
        );
      }

      default: {
        return (
          <Input
            {...field}
            label=''
            value={value ?? ''}
            error={error}
            onChange={(e) => onFieldChange(id, field.name, e.target.value)}
          />
        );
      }
    }
  };

  return (
    <tr className={cn('row')}>

      {schema.map((field) => (
        <td className={cn('td')} key={field.name}>
          {renderField(field)}
        </td>
      ))}

      <td
        className={cn('td')}
      >
        <button type="button" disabled={count === 1} className={cn("delete-icon")} onClick={() => onRemove(id)}>{DeleteIcon}</button>
      </td>
    </tr>
  );
};

export default memo(MultiInput);
