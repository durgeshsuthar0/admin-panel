import type { Meta, StoryObj } from '@storybook/react-vite';
import { FileUpload } from './FileUpload';
import { FileUploadProps } from './FileUpload.types';
import { fileUpload_svg } from '../../assets/svg';
import { expect, fn, userEvent, within } from 'storybook/test';

export const ActionsData = {
  onFileSelect: fn(),
  onChange: fn(),
};

const meta = {
  title: 'Components/FileUpload',
  component: FileUpload,
  tags: ['autodocs'],
  excludeStories: /.*Data$/,
  args: {
    ...ActionsData,
    label: 'Upload File',
    placeholder: 'Drag & drop files here or click to browse',
    icon: fileUpload_svg,
    disabled: false,
    allowMultiple: false,
  },
  argTypes: {
    disabled: {
      control: { type: 'boolean' },
    },
    allowMultiple: {
      control: { type: 'boolean' },
    },
    acceptedFileTypes: {
      control: { type: 'text' },
    },
  },
} satisfies Meta<typeof FileUpload>;

export default meta;
type Story = StoryObj<typeof meta>;

const Template = (args: FileUploadProps) => <FileUpload {...args} />;

export const Default: Story = {
  render: Template,
  args: {
    label: 'Upload File',
    placeholder: 'Drag & drop files here or click to browse',
    icon: fileUpload_svg,
  },
  play: async ({ canvasElement }) => {
    const fileInput = canvasElement.querySelector('input.filepond--browser');
    if (!fileInput) throw new Error('File input not found');

    const file = new File(['hello'], 'test-file.txt', {
      type: 'text/plain',
    });
    await userEvent.upload(fileInput, file);
    await expect(fileInput.files?.length).toBe(1);
  },
};

export const Multiple: Story = {
  render: Template,
  args: {
    label: 'Upload Multiple Files',
    placeholder: 'Drag & drop multiple files here',
    allowMultiple: true,
    icon: fileUpload_svg,
  },
  play: async ({ canvasElement }) => {
    const fileInput = canvasElement.querySelector('input.filepond--browser');

    const files = [
      new File(['file1'], 'file1.txt', { type: 'text/plain' }),
      new File(['file2'], 'file2.txt', { type: 'text/plain' }),
    ];

    await userEvent.upload(fileInput, files);

    // await expect(args.onFileSelect).toHaveBeenCalled();
    await expect(fileInput.files?.length).toBe(2);
  },
};

export const Disabled: Story = {
  render: Template,
  args: {
    label: 'Upload Disabled',
    placeholder: 'Upload is currently disabled',
    icon: fileUpload_svg,
    disabled: true,
  },
  play: async ({ canvasElement }) => {
    const fileInput = canvasElement.querySelector('.filepond--root');
    if (!fileInput) throw new Error('FilePond root not found');

    expect(fileInput.getAttribute('data-disabled')).toBe('disabled');
  },
};
