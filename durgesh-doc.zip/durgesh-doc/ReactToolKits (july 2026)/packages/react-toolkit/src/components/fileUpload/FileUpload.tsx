import * as React from 'react';
import ReactDOMServer from 'react-dom/server';
import { FileUploadProps } from './FileUpload.types';
import { classname, cns } from '@msbc/utils';

import { FilePond, registerPlugin } from 'react-filepond';
import FilePondPluginImageExifOrientation from 'filepond-plugin-image-exif-orientation';
import FilePondPluginImagePreview from 'filepond-plugin-image-preview';
import FilePondPluginImageValidateSize from 'filepond-plugin-image-validate-size';
import FilePondPluginFileValidateType from 'filepond-plugin-file-validate-type';
import FilePondPluginFileValidateSize from 'filepond-plugin-file-validate-size';
import FilePondPluginFileMetadata from 'filepond-plugin-file-metadata';

import './FileUpload.scss';
import 'filepond/dist/filepond.min.css';
import 'filepond-plugin-image-preview/dist/filepond-plugin-image-preview.css';
import { FormFieldWrapper } from '../formFieldWrapper';
import { fileUpload_svg } from '../../assets/svg';

import {
  PdfIcon,
  DocIcon,
  ExcelIcon,
  ImageIcon,
  PptIcon,
  TxtIcon,
  ZipIcon,
  DefaultFileIcon,
  CsvIcon,
  TrashIcon
} from './FileIcons';

// Register plugins once
registerPlugin(FilePondPluginImageExifOrientation, FilePondPluginImagePreview, FilePondPluginImageValidateSize, FilePondPluginFileValidateType, FilePondPluginFileValidateSize, FilePondPluginFileMetadata);

// Helper function to get file extension
const getFileExtension = (filename: string): string => {
  const parts = filename.split('.');
  return parts.length > 1 ? parts.pop()?.toLowerCase() || '' : '';
};

// Get appropriate icon component based on file extension
const getFileIconComponent = (filename: string): React.ReactElement => {
  const extension = getFileExtension(filename);

  const imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'svg', 'webp', 'ico', 'tiff'];
  const docExtensions = ['doc', 'docx', 'odt'];
  const xlsExtensions = ['xls', 'xlsx', 'csv', 'ods'];
  const pptExtensions = ['ppt', 'pptx', 'odp'];
  const pdfExtensions = ['pdf'];
  const zipExtensions = ['zip', 'rar', '7z', 'tar', 'gz', 'bz2'];
  const txtExtensions = ['txt', 'rtf', 'md', 'log'];
  const codeExtensions = ['js', 'jsx', 'ts', 'tsx', 'html', 'css', 'scss', 'json', 'xml'];

  if (imageExtensions.includes(extension)) {
    return <ImageIcon />;
  } else if (docExtensions.includes(extension)) {
    return <DocIcon />;
  } else if (xlsExtensions.includes(extension)) {
    if (extension === 'csv') return <CsvIcon />;
    return <ExcelIcon />;
  } else if (pptExtensions.includes(extension)) {
    return <PptIcon />;
  } else if (pdfExtensions.includes(extension)) {
    return <PdfIcon />;
  } else if (zipExtensions.includes(extension)) {
    return <ZipIcon />;
  } else if (txtExtensions.includes(extension) || codeExtensions.includes(extension)) {
    return <TxtIcon />;
  } else {
    return <DefaultFileIcon />;
  }
};

export const FileUpload = ({
  className = "",
  placeholder = "",
  icon = fileUpload_svg,
  labelIdle = 'Drag & Drop your files here or Browse',
  label,
  helpText,
  isRequired,
  error,
  disabled,
  ...FilePondProps
}: FileUploadProps): React.ReactElement => {
  const cn = classname('file-upload');
  const hasIcon = Boolean(icon);
  const iconHtml = icon ? ReactDOMServer.renderToString(icon) : '';
  const labelHtml = labelIdle ? ReactDOMServer.renderToString(labelIdle) : '';
  const placeholderHtml = placeholder ?? '';

  const labelIconContainerClass = cn('label-icon-container');
  const iconContainerClass = cn('icon-container', hasIcon ? '' : 'no-icon');
  const iconClass = cn('icon');
  const labelContainerClass = cn('label-container');
  const labelClass = cn('label');
  const placeHolderContainerClass = cn('placeholder-container');
  const placeHolderClass = cn('placeholder');
  // Function to create custom file display with icons
  const createCustomFileDisplay = React.useCallback(() => {
    const fileItems = document.querySelectorAll('.filepond--item:not([data-custom-display])');

    fileItems.forEach((item) => {
      item.setAttribute('data-custom-display', 'true');

      // Get file info elements
      const fileNameElement = item.querySelector('.filepond--file-info-main');
      const fileSizeElement = item.querySelector('.filepond--file-info-sub');
      const fileInfo = item.querySelector('.filepond--file-info');

      if (fileNameElement && fileSizeElement && fileInfo) {
        const fileName = fileNameElement.textContent || '';
        const fileIcon = getFileIconComponent(fileName);
        const iconHtml = ReactDOMServer.renderToString(fileIcon);

        // Simply add icon before existing content
        fileInfo.innerHTML = `
        <div class="${cn('icon-name-container')}">
          <span class="${cn('file-icon')}">${iconHtml}</span>
          <div class="${cn('file-details')}">
            <span class="${cn('file-name')}">${fileName}</span>
            <span class="${cn('file-size')}">${fileSizeElement.textContent || ''}</span>
          </div>
        </div>
      `;
      }
    });
  }, []);

  const labelIdleHtml = `
    <div class="${labelIconContainerClass}">
      <div class="${iconContainerClass}">
        <span class="${iconClass}">${iconHtml}</span>
      </div>
      <div class="${labelContainerClass}">
        <span class="${labelClass}">${labelHtml}</span>
      </div>
      <div class="${placeHolderContainerClass}">
        <span class="${placeHolderClass}">${placeholderHtml}</span>
      </div>
    </div>
  `;

  const { onaddfile, onupdatefiles } = FilePondProps;
  return (
    <FormFieldWrapper
      className={cns(cn({ 'has-error': !!error, }), className)}
      label={label}
      isRequired={isRequired}
      error={error}
      isDisabled={disabled}
      helpText={helpText}
    >
      <div className={cn('filepond-wrapper')}>
        <FilePond
          styleButtonRemoveItemPosition="right"
          disabled={disabled}
          iconRemove={ReactDOMServer.renderToString(<TrashIcon />)}
          onupdatefiles={(files) => {
            createCustomFileDisplay();
            if (onupdatefiles) {
              onupdatefiles(files);
            }
          }}
          onaddfile={(error, file) => {
            createCustomFileDisplay();
            if (onaddfile) {
              onaddfile(error, file);
            }
          }}
          {...FilePondProps}
          labelIdle={labelIdleHtml}
          server={{
            load: (source, load, error) => {
              fetch(source)
                .then(res => res.blob())
                .then(load)
                .catch(() => error('Failed to load file'));
            }
          }}
        />
      </div>
    </FormFieldWrapper>
  );
};