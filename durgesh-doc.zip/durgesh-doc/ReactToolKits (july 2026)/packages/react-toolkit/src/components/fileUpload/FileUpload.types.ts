import * as React from 'react';
import type { FilePondProps } from 'react-filepond';
export interface FileUploadProps extends Omit<FilePondProps, 'labelIdle'> {
  className?: string;
  label?: React.ReactNode;
  helpText?: string;
  error?: string;
  isRequired?: boolean;
  disabled?: boolean;
  icon?: React.ReactNode;
  labelIdle?: React.ReactNode;
  placeholder?: string;
}
