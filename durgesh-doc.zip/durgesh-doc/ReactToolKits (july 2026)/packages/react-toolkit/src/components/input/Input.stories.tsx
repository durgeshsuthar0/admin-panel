import type { Meta, StoryObj } from '@storybook/react-vite';
import { Input } from './Input';
import { InputProps } from './Input.types';
import { user_svg } from '../../assets/svg';
import { expect, fn, userEvent, within } from 'storybook/test';
const meta = {
  title: 'Components/Input',
  component: Input,
  tags: ['autodocs'],
  excludeStories: /.*Data$/,
  args: {},
  argTypes: {
    variant: {
      control: { type: 'select' },
      options: ['text', 'textarea', 'password'],
    },
    isRequired: {
      control: { type: 'boolean' },
    },
    isDisabled: {
      control: { type: 'boolean' },
    },
    error: {
      control: { type: 'text' },
    },
    placeHolder: {
      control: { type: 'text' },
    },
  },
} satisfies Meta<typeof Input>;

export default meta;
type Story = StoryObj<typeof meta>;

const Template = (args: InputProps) => <Input {...args} />;

export const TextInput: Story = {
  render: Template,
  args: {
    label: 'Text Input',
    variant: 'text',
    value: 'This is samle text',
    isRequired: false,
    placeHolder: 'Enter text',
    onChange: (e) => console.log(e.target.value),
    leftIcon: user_svg,
    rightIcon: user_svg,
    isDisabled: false,
    error: '',
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    const input = canvas.getByPlaceholderText('Enter text');

    await userEvent.clear(input);
    await userEvent.type(input, 'Hello Storybook');

    await expect(input).toHaveValue('This is samle text');
  },
};

export const TextArea: Story = {
  render: Template,
  args: {
    label: 'Text Area',
    variant: 'textarea',
    value: 'Line 1\nLine 2',
    isRequired: false,
    placeHolder: 'Enter text',
    onChange: (e) => console.log(e.target.value),
    isDisabled: false,
    error: '',
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    const textarea = canvas.getByPlaceholderText('Enter text');

    await userEvent.type(textarea, 'Line 1{enter}Line 2');

    await expect(textarea).toHaveValue('Line 1\nLine 2');
  },
};

export const PasswordInput: Story = {
  render: Template,
  args: {
    label: 'Password Input',
    variant: 'password',
    value: 'Password123',
    isRequired: false,
    placeHolder: 'Enter password',
    onChange: (e) => console.log(e.target.value),
    isDisabled: false,
    error: '',
    helpText: 'This is help text',
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    const passwordInput = canvas.getByPlaceholderText('Enter password');

    await expect(passwordInput).toHaveAttribute('type', 'password');

    await expect(canvas.getByText('This is help text')).toBeInTheDocument();

    // Find eye icon button
    const toggleButton = canvas.getByRole('button', {
      name: /toggle password visibility/i,
    });

    // Click → show password
    await userEvent.click(toggleButton);
    // Click again → hide password
    await userEvent.click(toggleButton);
  },
};
export const RequiredInput: Story = {
  render: Template,
  args: {
    label: 'Required Input',
    variant: 'text',
    value: '',
    isRequired: true,
    placeHolder: 'Enter text',
    onChange: (e) => console.log(e.target.value),
    isDisabled: false,
    // error: 'This field is required',
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    await expect(canvas.getByText(/Required Input/i)).toBeInTheDocument();
    const input = canvas.getByPlaceholderText('Enter text *');

    await expect(input).toHaveAttribute('required');
    // await expect(canvas.getByText('This field is required')).toBeInTheDocument();
  },
};

export const DisabledInput: Story = {
  render: Template,
  args: {
    label: 'Disabled Input',
    variant: 'text',
    value: '',
    isRequired: false,
    placeHolder: 'Enter text',
    onChange: (e) => console.log(e.target.value),
    isDisabled: true,
    error: '',
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);

    const input = canvas.getByPlaceholderText('Enter text');

    await expect(input).toBeDisabled();
  },
};

export const InputWithError: Story = {
  render: Template,
  args: {
    label: 'Input with Error',
    variant: 'text',
    value: '',
    isRequired: true,
    placeHolder: 'Enter text',
    onChange: (e) => console.log(e.target.value),
    isDisabled: false,
    error: 'This field is required.',
    helpText: 'This is help text',
  },
  play: async ({ canvasElement }) => {
    const canvas = within(canvasElement);
    const input = canvas.getByPlaceholderText('Enter text *');
    await expect(canvas.getByText('This field is required.')).toBeInTheDocument();

    await expect(canvas.getByText('This is help text')).toBeInTheDocument();

    await expect(input).toHaveAttribute('required');
  },
};
