import React from "react";
import { InputProps } from "./Input.types";
import "./Input.scss";
import { FormFieldWrapper } from "../formFieldWrapper/FormFieldWrapper";
import { hide_Password_svg, show_Password_svg } from "../../assets/svg";
import { classname, cns } from "@msbc/utils";

export const Input = (props: InputProps) => {
  const {
    className = "",
    label,
    variant = "text",
    value,
    isRequired = false,
    onChange,
    placeHolder,
    isDisabled = false,
    error,
    helpText,
    leftIcon,
    rightIcon,
  } = props;

  const cn = classname("input-component");
  const [showPassword, setShowPassword] = React.useState(false);

  const isPassword = variant === "password";
  const isTextarea = variant === "textarea";

  const inputType = isPassword
    ? showPassword
      ? "text"
      : "password"
    : variant;

  return (
    <FormFieldWrapper
      label={label}
      isRequired={isRequired}
      error={error}
      isDisabled={isDisabled}
      helpText={helpText}
      className={cns(cn(), className)}
    >
      <div
        className={cn("wrapper", {
          "is-disabled": isDisabled,
          "has-error": !!error,
          "has-left-icon": !!leftIcon,
          "has-right-icon": !!rightIcon,
        })}
      >
        {leftIcon && <div className={cn("left-icon")}>{leftIcon}</div>}

        {isTextarea ? (
          <textarea
            {...(props as React.TextareaHTMLAttributes<HTMLTextAreaElement>)}
            placeholder={placeHolder}
            disabled={isDisabled}
            className={cn("textarea-field", {
              "is-disabled": isDisabled,
            })}
          />
        ) : (
          <input
            {...(props as React.InputHTMLAttributes<HTMLInputElement>)}
            type={inputType}
            pattern={variant === "tel" ? "^\\+?[0-9]{7,15}$" : undefined}
            placeholder={placeHolder}
            disabled={isDisabled}
            className={cn("input-field", {
              "is-disabled": isDisabled,
            })}
            title={
              variant === "tel" ? "Enter a valid phone number" : undefined
            }
          />
        )}

        {isPassword && (
          <button
            aria-label="Toggle password visibility"
            type="button"
            className={cn("toggle-password", {
              "is-disabled": isDisabled,
            })}
            onClick={() => !isDisabled && setShowPassword(!showPassword)}
            disabled={isDisabled}
          >
            {showPassword ? hide_Password_svg : show_Password_svg}
          </button>
        )}

        {rightIcon && <div className={cn("right-icon")}>{rightIcon}</div>}
      </div>
    </FormFieldWrapper>
  );
};