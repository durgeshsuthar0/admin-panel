import React from 'react';

interface BaseProps {
  className?: string;
  label?: React.ReactNode;
  helpText?: string;
  value?: string;
  isRequired?: boolean;
  placeHolder?: string;
  isDisabled?: boolean;
  error?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}

// Input-specific props
type InputFieldProps = BaseProps &
  React.InputHTMLAttributes<HTMLInputElement> & {
    variant?: 'text' | 'password' | 'number' | 'email' | 'tel';
    onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  };

// Textarea-specific props
type TextAreaFieldProps = BaseProps &
  React.TextareaHTMLAttributes<HTMLTextAreaElement> & {
    variant: 'textarea';
    onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
  };

// Final union type
export type InputProps = InputFieldProps | TextAreaFieldProps;
