import * as React from "react";
import { ToggleButtonProps } from "./ToggleButton.types";
import { classname, cns } from "@msbc/utils";
import "./ToggleButton.scss";

export const ToggleButton: React.FC<ToggleButtonProps> = ({
  isActive = false,
  label,
  onChange,
  onIcon,
  offIcon,
  activeColor,
  inactiveColor,
  className = "",
  size = 'medium',
}) => {
  const cn = classname("switch");

  return (
    <label
      className={cns(cn(), className, `switch--size-${size}`)}
      style={{
        '--active-color': activeColor,
        '--inactive-color': inactiveColor,
      } as React.CSSProperties}
    >
      <span
        className={cn("container", { "is-dark": isActive })}
      >
        <input
          type="checkbox"
          role="toggle"
          checked={isActive}
          onChange={onChange}
          className={cn('input')}
        />
        <div
          className={cn("toggle-bg",
            {
              'is-right': isActive,
              'is-left': !isActive
            }
          )}
        />

        <div
          className={
            cn("icon", {
              'is-active': !isActive
            })
          }
        >
          {offIcon}
        </div>

        <div
          className={
            cn("icon", {
              'is-active': isActive
            })
          }
        >
          {onIcon}
        </div>
      </span>

      {label && <span className={cn("label")}>{label}</span>}
    </label>
  );
};
