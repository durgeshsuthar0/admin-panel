import React, { useState } from "react";
import type { Meta, StoryObj } from "@storybook/react";
import { ToggleButton } from "./ToggleButton";
import { moon_svg, sun_svg } from "../../assets/svg";
import { expect, fn, userEvent, within } from 'storybook/test';

export const ActionsData = {
  onChange: fn(),
};



const meta = {
  title: "Components/ToggleButton",
  component: ToggleButton,
  tags: ["autodocs"],
  excludeStories: /.*Data$/,
  args: {
    ...ActionsData,
  },
};
export default meta;

type Story = StoryObj<typeof meta>;

export const Default: Story = {
  render: (args) => {
    const [isDarkMode, setIsDarkMode] = useState(args.isActive);

    return (
      <ToggleButton
        {...args}
        isActive={isDarkMode}
        onChange={() => setIsDarkMode(!isDarkMode)}
      />
    );
  },
  args: {
    isActive: false,
    onChange: () => { },
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    // Find the toggle input (checkbox)
    const toggleInput = canvas.getByRole('toggle');

    await expect(toggleInput).not.toBeChecked();

    const toggleLabel = canvasElement.querySelector('label.switch');

    if (toggleLabel) {
      await userEvent.click(toggleLabel);
    } else {
      await userEvent.click(toggleInput);
    }
    await expect(toggleInput).toBeChecked();
  },
};

export const WithLabel: Story = {
  render: (args) => {
    const [isDarkMode, setIsDarkMode] = useState(args.isActive);

    return (
      <ToggleButton
        {...args}
        isActive={isDarkMode}
        onChange={() => setIsDarkMode(!isDarkMode)}
        label="Label"
      />
    );
  },
  args: {
    isActive: false,
    onChange: () => { },
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    await expect(canvas.getByText('Label')).toBeInTheDocument();

    const toggleInput = canvas.getByRole('toggle');

    await expect(toggleInput).not.toBeChecked();

    const toggleLabel = canvasElement.querySelector('label.switch');
    if (toggleLabel) {
      await userEvent.click(toggleLabel);
    } else {
      await userEvent.click(toggleInput);
    }

    await expect(toggleInput).toBeChecked();
  },
};

export const WithIcon: Story = {
  render: (args) => {
    const [isDarkMode, setIsDarkMode] = useState(args.isActive);

    return (
      <ToggleButton
        {...args}
        isActive={isDarkMode}
        onChange={() => setIsDarkMode(!isDarkMode)}
      />
    );
  },
  args: {
    isActive: false,
    onChange: () => { },
    offIcon: sun_svg,
    onIcon: moon_svg,
  },
  play: async ({ canvasElement, args }) => {
    const canvas = within(canvasElement);

    const toggleBg = canvasElement.querySelector('.switch__toggle-bg');
    await expect(toggleBg).toHaveClass('switch__toggle-bg--is-left');

    const icons = canvasElement.querySelectorAll('.switch__icon');
    await expect(icons[0]).toHaveClass('switch__icon--is-active');

    const toggleInput = canvas.getByRole('toggle');

    const toggleLabel = canvasElement.querySelector('label.switch');
    if (toggleLabel) {
      await userEvent.click(toggleLabel);
    } else {
      await userEvent.click(toggleInput);
    }

    await expect(toggleBg).toHaveClass('switch__toggle-bg--is-right');
    
    await expect(icons[1]).toHaveClass('switch__icon--is-active');
  },
};
