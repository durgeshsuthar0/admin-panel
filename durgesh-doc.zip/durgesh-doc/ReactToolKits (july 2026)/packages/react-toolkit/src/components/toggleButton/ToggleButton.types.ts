export interface ToggleButtonProps {
  label?: React.ReactNode;
  isActive?: boolean;
  onChange?: () => void;
  onIcon?: React.ReactNode;
  offIcon?: React.ReactNode;
  className?: string;
  size?: 'small' | 'medium' | 'large';
  activeColor?: string;
  inactiveColor?: string;
}
