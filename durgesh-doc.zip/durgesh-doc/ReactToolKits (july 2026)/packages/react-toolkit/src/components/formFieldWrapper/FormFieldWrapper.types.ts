export interface FormFieldWrapperProps {
  /** Label text for the form field */
  label?: React.ReactNode;

  /** Help or description text for the form field */
  helpText?: string;

  /** Whether the field is required */
  isRequired?: boolean;

  /** Error message to display */
  error?: string;

  /** Whether the field is disabled */
  isDisabled?: boolean;

  /** Custom CSS class name */
  className?: string;

  /** Children components (input, dropdown,...) */
  children: React.ReactNode;
}
