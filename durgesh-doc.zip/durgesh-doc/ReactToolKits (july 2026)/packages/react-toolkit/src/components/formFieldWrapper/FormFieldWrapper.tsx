import { FormFieldWrapperProps } from "./FormFieldWrapper.types";
import "./FormFieldWrapper.scss";
import { classname, cns } from "@msbc/utils";

/**
 * Generic wrapper used around all form fields (Input, Select, Textarea, etc.)
 * 
 * Responsibilities:
 * - Renders a label with optional required asterisk
 * - Wraps the input inside a styled container
 * - Shows optional help/description text
 * - Displays an error message and error icon when provided
 * - Handles disabled state styling
 */
export const FormFieldWrapper = ({
  className = "",
  label,
  helpText,
  isRequired = false,
  isDisabled = false,
  error,
  children
}: FormFieldWrapperProps) => {

  const cn = classname("form-field-wrapper");

  return (
    <div className={cns(cn(), className)}>
      {label && (
        <label className={cn('label')}>
          {label} {isRequired && <span className={cn('require-span')}>*</span>}
        </label>
      )}
      <div className={cn('input-container')}>
        {children}
        {helpText && (
          <div className={cn('help-text')}>
            {helpText}
          </div>
        )}
        {error && !isDisabled && (
          <div className={cn('error-message-container')}>
            <svg
              className={cn('error-icon')}
              viewBox="0 0 18 18"
              fill="none"
            >
              <path
                d="M8.85346 6.381V9.33215M8.85346 15.6401C5.18623 15.6401 2.21336 12.6672 2.21336 9C2.21336 5.33278 5.18623 2.35991 8.85346 2.35991C12.5207 2.35991 15.4935 5.33278 15.4935 9C15.4935 12.6672 12.5207 15.6401 8.85346 15.6401ZM8.8902 11.5455V11.619L8.81671 11.619V11.5455H8.8902Z"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
            <span className={cn('error-message')}>{error}</span>
          </div>
        )}
      </div>
    </div>
  );
};
