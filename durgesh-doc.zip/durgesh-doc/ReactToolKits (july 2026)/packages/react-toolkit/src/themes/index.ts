export const themes: Record<string, Record<string, string>> = {
  Journies: {
    url: 'journies-tokens.css',
  }
};
