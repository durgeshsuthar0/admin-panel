import 'react-filepond';

declare module 'react-filepond' {
  export interface FilePondProps {
    /* ------------------------------------------------------------------
     * filepond-plugin-file-validate-size
     * ------------------------------------------------------------------ */
    allowFileSizeValidation?: boolean;
    maxFileSize?: string;
    maxTotalFileSize?: string;
    labelMaxFileSizeExceeded?: string;
    labelMaxTotalFileSizeExceeded?: string;

    /* ------------------------------------------------------------------
     * filepond-plugin-file-validate-type
     * ------------------------------------------------------------------ */
    allowFileTypeValidation?: boolean;
    acceptedFileTypes?: string[];
    labelFileTypeNotAllowed?: string;
    fileValidateTypeLabelExpectedTypes?: string;

    /* ------------------------------------------------------------------
     * filepond-plugin-image-preview
     * ------------------------------------------------------------------ */
    allowImagePreview?: boolean;
    imagePreviewHeight?: number;
    imagePreviewMinHeight?: number;
    imagePreviewMaxHeight?: number;
    imagePreviewMaxFileSize?: string;
    imagePreviewTransparencyIndicator?: 'grid' | 'color';
    imagePreviewTransparencyIndicatorColor?: string;

    /* ------------------------------------------------------------------
     * filepond-plugin-image-exif-orientation
     * ------------------------------------------------------------------ */
    allowImageExifOrientation?: boolean;

    /* ------------------------------------------------------------------
     * filepond-plugin-image-validate-size
     * ------------------------------------------------------------------ */
    allowImageValidateSize?: boolean;
    imageValidateSizeMinWidth?: number;
    imageValidateSizeMaxWidth?: number;
    imageValidateSizeMinHeight?: number;
    imageValidateSizeMaxHeight?: number;
    imageValidateSizeLabelFormatError?: string;
    imageValidateSizeLabelImageSizeTooSmall?: string;
    imageValidateSizeLabelImageSizeTooBig?: string;

    /* ------------------------------------------------------------------
     * filepond-plugin-file-metadata
     * ------------------------------------------------------------------ */
    allowFileMetadata?: boolean;
    fileMetadataObject?: Record<string, any>;
  }
}
