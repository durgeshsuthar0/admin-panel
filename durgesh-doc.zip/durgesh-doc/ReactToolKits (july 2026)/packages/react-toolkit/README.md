# `@msbc/react-toolkit` Developer Documentation

`@msbc/react-toolkit` is a reusable, low-level component library designed for the monorepo. It serves as the foundational building block for higher-order configuration-driven abstractions like `ConfigurableForm` and `ConfigurableDashboard` located in `@msbc/config-ui`.

## Table of Contents

- [Overview](#overview)
- [Available Components & Props](#available-components--props)
  - [Layout & Navigation](#layout--navigation)
  - [Form Inputs & Controls](#form-inputs--controls)
  - [Form Structure](#form-structure)
- [Usage Example](#usage-example)

---

## Overview

Unlike `config-ui`, which expects JSON schemas to build complex layouts, `react-toolkit` provides individual, tightly-scoped UI elements. These inputs, lists, and layout primitives are meant to be highly configurable via standard React props, ensuring maximum reusability across the application suite.

All base components reside under `packages/react-toolkit/src/components`.

---

## Available Components & Props

The toolkit includes the following foundational elements, backed by strict TypeScript typings.

### Layout & Navigation

#### `TabNav`
Organizes content into selectable tabpanes.
- **Props**: `tabs` (array of `TabItem`), `activeId`, `onChange`, `defaultActiveId`, `lazy`, `keepAlive`, `className`, and various sub-element class name overrides.

#### `modal`
Standardized, configurable dialog windows.
- **Props**: `show` (boolean), `title`, `onClose`, `size` ('sm' | 'md' | 'lg' | 'full'), `children`, `footer`, `hasCloseButton`, `className`.

#### `list`
Renderers for standard list-based content, supporting dynamic data fetching.
- **Props**: `options`, `CardComponent`, `layout` (columns, gap, cardWidth, wrap, padding), `api` (for remote fetching), `isMultiSelect`, `onChange`, `value`, `scroll`, `loadingComponent`, `emptyComponent`.

#### `table`
Base data grid wrapping `ag-grid-react` elements used heavily by dashboards.
- **Props (extends AgGridReactProps)**: `tableId`, `tableName`, `api` (UseApiOptions for fetching), `currentPage`, `totalRecords`, `totalPage`, `showPagination`, `onPageNumberChange`, `onSelectionChanged`.

### Form Inputs & Controls

#### `button`
Standard interactive buttons.
- **Props**: `text`, `variant` ('ghost' | 'primary' | 'secondary' | 'text'), `size` ('small' | 'medium' | 'large'), `Disabled`, `onClick`, `icon`, `iconPosition` ('left' | 'right').

#### `toggleButton`
Specialized switch/toggle actions.
- **Props**: `label`, `isActive`, `onChange`, `onIcon`, `offIcon`, `size`, `activeColor`, `inactiveColor`.

#### `input`
Standard text/number input fields.
- **Props**: `label`, `variant` ('text' | 'textarea' | 'password' | 'number' | 'email' | 'tel'), `value`, `onChange`, `placeHolder`, `isRequired`, `isDisabled`, `error`, `helpText`, `leftIcon`, `rightIcon`.

#### `datePicker`
Date and time selection widget. Supports both single and range selection.
- **Props**: `value` (or `startDate`/`endDate`), `onChange`, `minDate`, `maxDate`, `dateFormat`, `showTimeSelect`, `placeholder`, `disabled`, `label`, `isRequired`, `error`.

#### `dropdown`
Select menus and auto-complete dropdowns wrapping `react-select`. Supports creating new options and API-based loading.
- **Props**: `options`, `value`, `onChange`, `api` (UseApiOptions), `isCreatable`, `onCreateOption`, `isMulti`, `labelKey`, `valueKey`, `placeholder`, `isDisabled`, `label`, `error`.

#### `checkbox`
Standalone selectable check element.
- **Props**: `label`, `value`, `isSelected`, `onChange`, `isDisabled`, `name`.

#### `checkboxGroup`
Multiple checkboxes acting as a cohesive form field. Supports remote fetching API.
- **Props**: `options`, `value`, `onChange`, `isMultiple`, `direction` ('horizontal' | 'vertical'), `api` (UseApiOptions), `labelKey`, `valueKey`, `isRequired`, `error`.

#### `radio`
Radio button controls for mutually exclusive selections.
- **Props**: `options`, `value`, `onChange`, `checked`, `direction` ('horizontal' | 'vertical'), `api` (UseApiOptions), `labelKey`, `valueKey`.

#### `fileUpload`
Base component managing drag-and-drop file inputs extending `react-filepond`.
- **Props (extends FilePondProps)**: `label`, `helpText`, `error`, `isRequired`, `disabled`, `icon`, `placeholder`.

#### `map`
Base Google Map component integration with address autocomplete.
- **Props**: `apiKey`, `value`, `onChange`, `height`, `zoom`, `enableMarkerMove`, `keyMap` (address component mappings).

### Form Structure

#### `formFieldWrapper`
A standardized container element used to enforce uniform labels, help text, error rendering, and layouts across all input components.
- **Props**: `label`, `isRequired`, `error`, `isDisabled`, `helpText`, `children`, `className`.

---

## Usage Example

Instead of dictating an entire layout via configuration, you can import structural elements directly when building custom/bespoke UI views:

```tsx
import { Modal, Button, Input } from "@msbc/react-toolkit";
import { useState } from "react";

const CustomUserFlow = () => {
  const [show, setShow] = useState(false);
  const [value, setValue] = useState("");

  return (
    <div>
      <Button onClick={() => setShow(true)} text="Launch Flow" />

      <Modal
        show={show}
        onClose={() => setShow(false)}
        title="Custom Flow Document"
        size="md"
      >
        <div className="p-4">
          <Input 
            label="Document Name" 
            value={value} 
            onChange={(e) => setValue(e.target.value)} 
            placeHolder="Type here..."
          />
        </div>
      </Modal>
    </div>
  );
};
```
