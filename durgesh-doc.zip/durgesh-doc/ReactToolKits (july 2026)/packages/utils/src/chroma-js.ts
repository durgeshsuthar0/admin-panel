import chroma from 'chroma-js';

/**
 * @see https://www.w3.org/TR/UNDERSTANDING-WCAG20/visual-audio-contrast-contrast.html
 */
export const MIN_CONTRAST_RATIO = 4.5;

/**
 * Takes colorArg (a string of a color) and tests its contrast ratio
 * with it as a background color with white text.
 *
 * The white text is then darkened until it meets minContrast, if it doesn't
 * by default. This returns a color that can be used for text with the colorArg
 * as a background color.
 *
 * @param {string} colorArg
 * @param {number} minContrast
 *
 * @returns {string}
 */
const getMinContrastForeground = (colorArg: any, minContrast = MIN_CONTRAST_RATIO) => {
  const color1 = chroma(colorArg);

  let color2 = chroma('#fff');
  let contrastRatio = chroma.contrast(color1, color2);

  // darken it until we hit our contrast ratio.
  while (contrastRatio <= minContrast) {
    color2 = chroma(color2.darken(0.1));
    contrastRatio = chroma.contrast(color1, color2);
  }

  return color2.css();
};

const RED = 0.2126;
const GREEN = 0.7152;
const BLUE = 0.0722;

const GAMMA = 2.4;

const luminance = (color: any) => {
  // Remove '#' symbol if it's present
  color = color.replace('#', '');

  const red = parseInt(color.slice(0, 2), 16);
  const green = parseInt(color.slice(2, 4), 16);
  const blue = parseInt(color.slice(4, 6), 16);

  const result = [red, green, blue].map((value) => {
    value /= 255;
    return value <= 0.03928 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, GAMMA);
  });

  return result[0] * RED + result[1] * GREEN + result[2] * BLUE;
};

const getContrastRatio = (textColor: any, bgColor: any) => {
  const lum1 = luminance(textColor);
  const lum2 = luminance(bgColor);
  const brightest = Math.max(lum1, lum2);
  const darkest = Math.min(lum1, lum2);
  return (brightest + 0.05) / (darkest + 0.05);
};

export { getMinContrastForeground, getContrastRatio };
