import { UseApiOptions } from '@msbc/data-layer';
import {
  DropdownProps,
  InputProps,
  ListProps,
  TableProps,
  ButtonProps,
  DatePickerProps,
  RangeDatePickerProps,
  ToggleButtonProps,
} from '@msbc/react-toolkit';

export interface DashboardAction extends Omit<ButtonProps, 'onClick'> {
  api?: UseApiOptions;
  onClick?: (Value: Array<any>) => void;
  confirmation?: boolean;
  confirmationText?: string;
}

interface BaseFilter<TFilter> {
  name: string;

  /** Additional custom properties */
  [key: string]: any;
}

interface InputFieldProps<TFilter>
  extends BaseFilter<TFilter>, Omit<InputProps, 'variant' | 'value' | 'onChange' | 'name'> {
  type: InputProps['variant'];
}

interface SelectField<TFilter> extends BaseFilter<TFilter>, Omit<DropdownProps, 'name'> {
  type: 'select';
}

export type DateField<TFilter> = BaseFilter<TFilter> &
  Partial<DatePickerProps> & {
    type: 'date';
    dateFormat?: string;
  };

export type RangeDateField<TFilter> = BaseFilter<TFilter> &
  Partial<RangeDatePickerProps> & {
    type: 'date-range';
    startDateKey?: keyof TFilter;
    endDateKey?: keyof TFilter;
    dateFormat?: string;
  };

type FiltersType<TFilter> =
  | InputFieldProps<TFilter>
  | SelectField<TFilter>
  | DateField<TFilter>
  | RangeDateField<TFilter>;

type FieldInfo = Array<
  Array<{
    key: string;
    label: string;
    field: string;
    type: 'text' | 'int' | 'date' | 'phone' | 'bool';
    condition?: string;
  }>
>;

type FieldTypeInfo = {
  text: Array<{ lookup_key: string; info: string }>;
  int: Array<{ lookup_key: string; info: string }>;
  date: Array<{ lookup_key: string; info: string }>;
  phone: Array<{ lookup_key: string; info: string }>;
  bool: Array<{ lookup_key: string; info: string }>;
};

type AdvancedFilterEnabled = {
  hasAdvancedFilter: true;
  fieldInfo: FieldInfo;
  fieldTypeInfo: FieldTypeInfo;
  isModalOpen: boolean;
  onClose: () => void;
};

type AdvancedFilterDisabled = {
  hasAdvancedFilter?: false;
};

type AdvanceFilterProps = {
  filterTitle?: React.ReactNode;
  onApplyFilter?: (filters: any) => void;
  onClearFilter?: () => void;
  handleModalOpen?: () => void;
  hasFilterButton?: boolean;
} & (AdvancedFilterEnabled | AdvancedFilterDisabled);

export interface DashboardConfig<
  TRow = any,
  TFilter extends Record<string, any> = Record<string, any>,
> {
  title: React.ReactNode;
  hiddenCreateButton?: boolean;
  enableModeSwitch?: boolean;
  modeSwitchProps?: ToggleButtonProps;
  createButtonProps?: ButtonProps;
  customCreateButton?: React.ReactNode;
  /* Array of action buttons */
  actions?: DashboardAction[];
  /* Flag to enable or disable search functionality */
  hasSearch?: boolean;
  searchBarProps?: Omit<InputProps, 'value' | 'onChange'>;
  /* Array of filter configurations */
  filters?: FiltersType<TFilter>[];
  /* Default view mode for the dashboard */
  viewMode?: 'table' | 'list';
  /* Optional props for table view */
  tableProps?: Omit<TableProps<TRow>, 'api' | 'rowData'>;
  /* Optional props for list view */
  listProps?: Omit<ListProps, 'api'>;
  /* Optional API config for data fetching */
  api?: UseApiOptions;
  apiResponseMapper?: (data: any) => {
    data: any[];
    currentPage?: number;
    totalRecords?: number;
    totalPage?: number;
  };

  autoAdjustColumns?: boolean;
  paginationParams?: {
    pageIndex?: string;
    pageLimit?: string;
  };

  // filter implement
  advanceFilterProps?: AdvanceFilterProps;
}

export interface ConfigurableDashboardProps<
  TRow = any,
  TFilter extends Record<string, any> = Record<string, any>,
> {
  className?: string;
  config: DashboardConfig<TRow, TFilter>;
  onSearch?: (value: string) => void;
  onFilterChange?: <K extends keyof TFilter>(filterKey: K, value: TFilter[K]) => void;
}
