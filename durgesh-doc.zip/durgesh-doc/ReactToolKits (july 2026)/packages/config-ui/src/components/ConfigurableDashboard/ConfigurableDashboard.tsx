import React, {
  useCallback,
  useEffect,
  useRef,
  useState,
  useImperativeHandle,
  forwardRef,
  useMemo,
} from 'react';
import {
  Button,
  Input,
  Dropdown,
  Table,
  List,
  RangeDatePicker,
  DatePicker,
  ToggleButton,
  Pagination,
} from '@msbc/react-toolkit';
import { ConfigurableDashboardProps } from './ConfigurableDashboard.types';
import './index.css';
import { useDebounce, classname, cns } from '@msbc/utils';
import { UseApiOptions, useApiRequest } from '@msbc/data-layer';
import { format } from 'date-fns';
import { FilterModal } from '@msbc/react-toolkit';
type ApiListResponse<T> = {
  data: T[];
  errorMessage?: string; // fixed typo from 'errorMessge'
  success: boolean;
  search?: string;
  pagination: {
    pageIndex: number;
    limit: number;
    total: number;
  };
  sort?: {
    field: string;
    direction: 'asc' | 'desc';
  };
};

type DashboardParams<TFilter> = TFilter & {
  search?: string;
  sort_field?: string;
  sort_direction?: string;
};

export interface ConfigurableDashboardHandle {
  handleRefresh: (hardRefresh?: boolean) => void;
}

const isValidNumber = (val?: number) => (val != null && val !== 0);

export const ConfigurableDashboard = forwardRef(
  <
    TRow extends Record<string, any> = Record<string, any>,
    TFilter extends Record<string, any> = Record<string, any>,
  >(
    { className = '', config, onSearch, onFilterChange }: ConfigurableDashboardProps<TRow, TFilter>,
    ref: React.Ref<ConfigurableDashboardHandle>
  ) => {
    const cn = classname('configurable-dashboard');

    const {
      title,
      actions = [],
      filters = [],
      hasSearch = false,
      searchBarProps,
      viewMode = 'table',
      tableProps = {},
      listProps,
      api,
      apiResponseMapper,
      hiddenCreateButton = false,
      createButtonProps,
      autoAdjustColumns = true,
      enableModeSwitch,
      modeSwitchProps,
      customCreateButton,
      paginationParams,

      // Filter Implement
      advanceFilterProps
    } = config;

    const { onSelectionChanged, ...restTableProps } = tableProps;

    // To get grid data
    const { data, loading, execute } = useApiRequest<
      Partial<ApiListResponse<TRow>>,
      DashboardParams<TFilter>
    >({
      url: api?.url || '',
      method: api?.method || 'get',
      params: api?.params,
      config: api?.config,
      autoFetch: false,
    });

    // To Execute actions api
    const { execute: executeActionApi, loading: actionLoading } = useApiRequest({
      url: '',
      method: 'post',
      autoFetch: false,
    });

    const [searchText, setSearchText] = useState<string>('');
    const [filtersState, setFiltersState] = useState<TFilter>({} as TFilter);
    const [sortState, setSortState] = useState<{
      sort_field: string;
      sort_direction: 'asc' | 'desc' | '';
    }>({
      sort_field: '',
      sort_direction: '',
    });

    const [isFilterModalOpen, setIsFilterModalOpen] = useState(false);
    const [selectedAdvancedFilters, setSelectedAdvancedFilters] = useState<any[]>([]);
    const [selectData, setSelectData] = useState<Record<string, any>>();
    const [mode, setMode] = useState(viewMode);
    const [pagination, setPagination] = useState<{ pageIndex: number; limit?: number }>({
      pageIndex: 1,
    });

    const selectedRowsRef = useRef<TRow[]>([]);
    const gridRef = useRef<any>(null);

    const debouncedSearch = useDebounce(searchText, 300);

    // Fetch data when search, filters, sort, or pagination changes
    useEffect(() => {
      if (!api) return;

      const finalPagination: Record<string, any> = {};

      if (pagination.pageIndex != null) {
        finalPagination[paginationParams?.pageIndex ?? 'pageIndex'] = pagination.pageIndex;
      }

      if (pagination.limit != null) {
        finalPagination[paginationParams?.pageLimit ?? 'limit'] = pagination.limit;
      }

      execute({
        params: {
          ...(api.params || {}),
          search: debouncedSearch || undefined,
          ...filtersState,
          ...(sortState.sort_field ? sortState : {}),
          ...finalPagination,
        },
        config: api.config,
      });
    }, [debouncedSearch, filtersState, sortState, pagination]);

    const handleFilterChange = useCallback(<K extends keyof TFilter>(key: K, value: TFilter[K]) => {
      const parsedValue =
        value && typeof value === 'object' && 'value' in value ? (value as any).value : value;

      setFiltersState((prev) => ({
        ...prev,
        [key]: parsedValue,
      }));

      onFilterChange?.(key, parsedValue);
    }, []);

    const handleSelectionChange = useCallback((rows: TRow[]) => {
      selectedRowsRef.current = rows;
      onSelectionChanged?.(rows);
    }, []);

    const handleBulkActionClick = async (apiConfig: UseApiOptions) => {
      executeActionApi({
        url: apiConfig.url,
        method: apiConfig.method ?? 'post',
        body: { selected: selectedRowsRef, ...(apiConfig.body || {}) },
        params: apiConfig.params,
      })
        .then((res) => {
          gridRef.current.api.deselectAll();
        })
        .catch((error) => { });
    };

    const handleGridReady = (event: any) => {
      gridRef.current = event;
      if (autoAdjustColumns) {
        event.api.sizeColumnsToFit();
      }
    };

    const handleSortChanged = useCallback((params: any) => {
      const columnState = params.api.getColumnState();
      const sorted = columnState
        .filter((col: any) => col.sort) // only sorted columns
        .sort((a: any, b: any) => a.sortIndex - b.sortIndex); // sorted order

      if (sorted.length === 0) {
        setSortState({ sort_field: '', sort_direction: '' });
        return;
      }

      const { colId, sort } = sorted[0];

      setSortState({
        sort_field: colId,
        sort_direction: sort,
      });
    }, []);

    const handleRefresh = (hardRefresh: boolean = false) => {
      if (!api) {
        return;
      }
      if (hardRefresh) {
        setSortState({ sort_field: '', sort_direction: '' });
        setFiltersState({} as TFilter);
        setSelectData({});
        return;
      }
      execute({
        params: {
          ...(api.params || {}),
          search: debouncedSearch || undefined,
          ...filtersState,
          ...(sortState.sort_field ? sortState : {}),
          ...pagination,
        },
        config: api.config,
      });
    };

    useImperativeHandle(
      ref,
      () => ({
        handleRefresh,
      }),
      [handleRefresh]
    );

    const handleSelectChange = (key: string, value: any) => {
      setSelectData((prev) => ({
        ...prev,
        [key]: value,
      }));
    };
    const handlePaginationChanged = useCallback((page: number) => {
      setPagination((prev) => ({
        ...prev,
        pageIndex: page,
      }));
    }, []);
    const handleModeChange = () => {
      const viewMode = mode == 'list' ? 'table' : 'list';
      setMode(viewMode);
    };

    const rowDataFinal = useMemo(() => {
      if (apiResponseMapper) {
        const {
          data: rawData,
          currentPage,
          totalRecords,
          totalPage,
        } = apiResponseMapper?.(data);
        return {
          data: rawData,
          currentPage,
          totalRecords,
          totalPage,
        };
      }

      return {
        data: data?.data,
      };
    }, [data]);

    const formatFilterForApi = (filters: any[]) => {
      if (!filters?.length) return null;

      const grouped: Record<string, any[]> = {};

      filters.forEach((f) => {
        const field = f.param || f.field;
        const lookup = f.type || "exact";

        const key = `${field}_${lookup}`;

        if (!grouped[key]) {
          grouped[key] = [];
        }

        grouped[key].push({
          param: field,
          field: field,
          type: lookup,
          value: f.value,
        });
      });

      const result: any = {};

      Object.keys(grouped).forEach((key) => {
        const items = grouped[key];

        const lookup = items[0].type;
        const field = items[0].field;

        if (items.length > 1) {
          if (!result.in) result.in = { fields: [] };

          result.in.fields.push({
            param: field,
            field: field,
            type: "in",
            value: items.map((i: any) => i.value),
          });
        } else {
          if (!result[lookup]) result[lookup] = { fields: [] };

          result[lookup].fields.push(items[0]);
        }
      });

      return result;
    };

    const handleApplyAdvancedFilter = (filters: any[]) => {
      const formattedFilter = formatFilterForApi(filters);
      setSelectedAdvancedFilters(filters);
      if (advanceFilterProps?.onApplyFilter) {
        advanceFilterProps.onApplyFilter(formattedFilter);
        return;
      }
      setFiltersState((prev: any) => ({
        ...prev,
        filter: JSON.stringify(formattedFilter),
      }));
      setIsFilterModalOpen(false);
      if (advanceFilterProps?.hasAdvancedFilter) {
        advanceFilterProps?.onClose();
      }
    };
    const handleClearAdvancedFilter = () => {
      setSelectedAdvancedFilters([]);
      setIsFilterModalOpen(false);
      advanceFilterProps?.onClearFilter?.();

      setFiltersState((prev: any) => {
        const updated = { ...prev };
        delete updated.filter;
        return updated;
      });
    };

    const handleFilterModalClose = () => {
      setIsFilterModalOpen(false);
      if (advanceFilterProps?.hasAdvancedFilter) {
        advanceFilterProps?.onClose();
      }
    }

    return (
      <div className={cns(cn(), className)}>
        {/* Header */}
        <div className={cn('top-container')}>
          <div className={cn('title-container')}>
            <h4 className={cn('title')}>{title}</h4>
          </div>

          {/* Bulk Actions */}
          <div className={cn('actions-container')}>
            {actions.length > 0 &&
              actions.map((action, index) => {
                const {
                  api,
                  confirmation,
                  confirmationText,
                  onClick: actionClick,
                  ...buttonProps // ← only Button props here
                } = action;
                return (
                  <Button
                    key={buttonProps.text}
                    {...buttonProps}
                    onClick={() => {
                      const selected = selectedRowsRef.current || [];
                      // if (!selected.length) {
                      //   alert("Please select at least one row.");
                      //   return;
                      // }

                      if (actionClick) {
                        actionClick(selected);
                        return;
                      }

                      if (!api) return;

                      if (!confirmation) {
                        handleBulkActionClick(api);
                      }
                      const confirmed = window.confirm(
                        confirmationText ?? `Are you sure you want to ${action.text}?`
                      );

                      if (!confirmed) return;
                      handleBulkActionClick(api);
                    }}
                  />
                );
              })}

            {enableModeSwitch && (
              <ToggleButton
                isActive={mode === 'list'}
                onChange={handleModeChange}
                {...modeSwitchProps}
              />
            )}

            {!hiddenCreateButton && !customCreateButton && (
              <Button key="button_create" text="Create" {...createButtonProps} />
            )}

            {customCreateButton}
          </div>
        </div>

        {/* Search + Filters */}
        <div className={cn('filter-container')}>
          {/* Search */}
          {hasSearch && (
            <div className={cn('input-filter')}>
              <Input
                placeholder="Search..."
                value={searchText}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  onSearch?.(e.target.value);
                  setSearchText(e.target.value);
                }}
                variant='text'
                className={cn('search-input')}
                {...(searchBarProps as any)}
              />
            </div>
          )}
          {(advanceFilterProps && advanceFilterProps.hasAdvancedFilter) ? (
            <>
              {advanceFilterProps.hasFilterButton && (
                <Button
                  text={`Filter ${selectedAdvancedFilters.length ? `(${selectedAdvancedFilters.length})` : ''}`}
                  onClick={() => setIsFilterModalOpen(true)}
                />
              )}

              <FilterModal
                isOpen={advanceFilterProps.isModalOpen || isFilterModalOpen}
                onClose={handleFilterModalClose}
                filterTitle={advanceFilterProps.filterTitle || 'Advance Filters'}
                onApplyFilter={handleApplyAdvancedFilter}
                onClearFilter={handleClearAdvancedFilter}
                fieldInfo={advanceFilterProps.fieldInfo}
                fieldTypeInfo={advanceFilterProps.fieldTypeInfo}
                selectedFilters={selectedAdvancedFilters}
              />
            </>
          ) : (
            <div className={cn('filters')}>
              {filters.map((filter, index) => {
                const filterKey = filter.name || filter.key || `filter_${index}`;
                switch (filter.type) {
                  case 'select':
                    return (
                      <div className={cn('filter')} key={filterKey}>
                        <Dropdown
                          {...filter}
                          value={selectData?.[filterKey]}
                          options={filter.options || []}
                          onChange={(val: any) => {
                            handleSelectChange(filterKey, val);
                            handleFilterChange(filterKey, val);
                          }}
                        />
                      </div>
                    );
                  case 'date':
                    const selectDate = filtersState[filterKey]
                      ? new Date(filtersState[filterKey])
                      : null;
                    return (
                      <div className={cn('filter')} key={filterKey}>
                        <DatePicker
                          className={filter.className}
                          value={selectDate}
                          onChange={(val: Date | null) => {
                            if (val) {
                              handleFilterChange(filterKey, format(val, filter.dateFormat ?? 'y-M-d') as any);
                              return
                            }
                            handleFilterChange(filterKey, null as any);
                          }}
                          {...filter}
                        />
                      </div>
                    );
                  case 'date-range':
                    const start = filtersState[filter.startDateKey ?? 'fromDate']
                      ? new Date(filtersState[filter.startDateKey ?? 'fromDate'])
                      : null;
                    const end = filtersState[filter.endDateKey ?? 'toDate']
                      ? new Date(filtersState[filter.endDateKey ?? 'toDate'])
                      : null;
                    return (
                      <div className={cn('filter')} key={filterKey}>
                        <RangeDatePicker
                          className={filter.className}
                          startDate={start}
                          endDate={end}
                          onChange={(start: Date | null, end: Date | null) => {
                            if (start && end) {
                              const startDate = format(start, filter.dateFormat ?? 'y-M-d');
                              const endDate = format(end, filter.dateFormat ?? 'y-M-d');
                              handleFilterChange(
                                filter.startDateKey ?? 'fromDate',
                                startDate as any
                              );
                              handleFilterChange(filter.endDateKey ?? 'toDate', endDate as any);
                            }

                            if (!start && !end) {
                              handleFilterChange(filter.startDateKey ?? 'fromDate', null as any);
                              handleFilterChange(filter.endDateKey ?? 'toDate', null as any);
                              return;
                            }
                          }}
                          {...filter}
                        />
                      </div>
                    );
                  default:
                    return (
                      <div className={cn('filter')} key={filterKey}>
                        <Input
                          onChange={(e: any) =>
                            handleFilterChange(
                              filterKey,
                              e.target.value as TFilter[typeof filterKey]
                            )
                          }
                        />
                      </div>
                    );
                }
              })}
            </div>
          )}
        </div>

        {/* Main Content */}
        <div className={cn('content')}>
          {mode === 'table' && (
            <Table<TRow>
              onSelectionChanged={handleSelectionChange}
              rowData={rowDataFinal.data}
              loading={loading}
              onGridReady={handleGridReady}
              onSortChanged={handleSortChanged}
              domLayout='normal'
              {...restTableProps}
              showPagination={false}
            />
          )}

          {mode === 'list' && listProps?.CardComponent && (
            <List options={rowDataFinal.data} loading={loading} {...listProps} />
          )}

          {isValidNumber(rowDataFinal.currentPage) && isValidNumber(rowDataFinal.totalPage) && isValidNumber(rowDataFinal.totalRecords) && (
            <Pagination
              onPageChange={handlePaginationChanged}
              currentPage={rowDataFinal.currentPage ?? 0}
              totalPage={rowDataFinal.totalPage ?? 0}
              totalRecords={rowDataFinal.totalRecords ?? 0}
            />
          )}
        </div>
      </div>
    );
  }
);
