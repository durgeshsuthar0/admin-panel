import type {
  ButtonProps,
  CheckboxGroupProps,
  DatePickerProps,
  DropdownProps,
  FileUploadProps,
  ListProps,
  MapProps,
  RadioProps,
  RangeDatePickerProps,
} from '@msbc/react-toolkit';
import React from 'react';
import {
  Control,
  UseFormClearErrors,
  UseFormSetValue,
  UseFormUnregister,
  UseFormGetValues,
  UseFormTrigger,
  UseFormSetError,
  UseFormReset,
  Path,
  FieldValues,
  ArrayPath,
  UseFieldArrayAppend,
  FieldArrayWithId,
} from 'react-hook-form';

export type CustomValidatorFnType = Record<
  string,
  (
    value: unknown,
    fieldValues: FieldValues
  ) => boolean | Promise<boolean> | string | Promise<string>
>;
export interface RepeatableRenderProps<
  TFormValues extends Record<string, any> = Record<string, any>,
  K extends ArrayPath<TFormValues> = ArrayPath<TFormValues>,
> {
  section: RepeatableFormSection<TFormValues, K>;

  fields: FieldArrayWithId<TFormValues, ArrayPath<TFormValues>, 'id'>[];

  append: UseFieldArrayAppend<TFormValues, K>;

  remove: (index: number) => void;

  control: Control<TFormValues>;

  customValidators?: ConfigurableFormProps<TFormValues>['customValidators'];

  setValue: UseFormSetValue<TFormValues>;

  defaultRender: () => React.ReactNode;

  clearErrors: UseFormClearErrors<TFormValues>;

  unregister: UseFormUnregister<TFormValues>;
}

export interface SectionRenderProps<TFormValues extends Record<string, any> = Record<string, any>> {
  section: FormSection<TFormValues>;
  control: Control<any>;
  customValidators?: ConfigurableFormProps<TFormValues>['customValidators'];
  setValue: UseFormSetValue<TFormValues>;
  defaultRender: () => React.ReactNode;
  clearErrors: UseFormClearErrors<TFormValues>;
  unregister: UseFormUnregister<TFormValues>;
}

export interface GroupRenderProps<TFormValues extends Record<string, any> = Record<string, any>> {
  group: FormSectionGroup<TFormValues>;
  control: Control<any>;
  customValidators?: ConfigurableFormProps<TFormValues>['customValidators'];
  setValue: UseFormSetValue<TFormValues>;
  defaultRender: (index: number) => React.ReactNode;
  index: number;
  clearErrors: UseFormClearErrors<TFormValues>;
  unregister: UseFormUnregister<TFormValues>;
}

export type VisibilityPredicate = (value: unknown, allValues: Record<string, unknown>) => boolean;

/** Supported visibility operators */
export type VisibilityOperator = 'equals' | 'notEquals' | 'exists' | 'in' | 'notIn' | 'custom';

/** Operator → allowed value mapping */
type OperatorValueMap = {
  equals: string | number | boolean;
  notEquals: string | number | boolean;
  exists: never;
  in: readonly (string | number | boolean)[];
  notIn: readonly (string | number | boolean)[];
  custom: {
    fn: string;
    args?: unknown;
  };
};

/** Atomic visibility condition */
export type VisibilityCondition<K extends VisibilityOperator = VisibilityOperator> = {
  field: string;
  operator: K;
} & (OperatorValueMap[K] extends never ? {} : { value: OperatorValueMap[K] });

/** Imperative (function-based) condition */
export interface VisibilityFunctionRule {
  field: string;
  when: VisibilityPredicate;
}

/** Group of rules (AND / OR) */
export interface VisibilityGroup {
  operator: 'AND' | 'OR';
  rules: VisibilityRule[];
}

/** Recursive visibility rule */
export type VisibilityRule = VisibilityCondition | VisibilityFunctionRule | VisibilityGroup;

/** Public alias used by fields */
export type VisibleIf = VisibilityRule;

/* =====================================================
   VALIDATION
===================================================== */
export interface ValidationRule<TFormValues extends Record<string, any>> {
  required?: boolean | { message: string };

  requiredIf?: {
    field: Path<TFormValues>;
    operator?: 'equals' | 'notEquals' | 'exists' | 'notEmpty';
    value?: any;
    message?: string;
  };

  requiredIfAny?: {
    fields: Path<TFormValues>[];
    message?: string;
  };

  minLength?: number | { value: number; message: string };
  maxLength?: number | { value: number; message: string };

  min?: number | { value: number; message: string };
  max?: number | { value: number; message: string };

  pattern?: string | { value: string; message: string };

  custom?: { fn: string; message: string };
}

/* =====================================================
   FORM LAYOUT
===================================================== */

export interface FormLayout {
  columns?: number;
}

/* =====================================================
   DEPENDENCY CONFIG
===================================================== */

export interface DependsConfig<TFormValues extends Record<string, any>> {
  fieldName: Path<TFormValues>;

  api?: {
    mapParamTo?: Path<TFormValues>;
    appendToUrl?: boolean;
    transform?: (val: unknown) => unknown;
  };

  confirm?: {
    message: string;
  };

  when?: (value: unknown, allValues: FieldValues) => boolean;
  populate?:
    | {
        from: Path<TFormValues>;
        to: Path<TFormValues>;
        transform?: (val: unknown) => unknown;
        onlyIfEmpty?: boolean;
      }
    | Array<{
        from: Path<TFormValues>;
        to: Path<TFormValues>;
        transform?: (val: unknown) => unknown;
        onlyIfEmpty?: boolean;
      }>;
}

/* =====================================================
   BASE FIELD
===================================================== */

export interface BaseField<TFormValues extends Record<string, any> = Record<string, any>> {
  name: Path<TFormValues>;
  default?: unknown;

  colSpan?: number;
  rowSpan?: number;

  /** ✅ NEW type-safe visibility */
  visibleIf?: VisibleIf;

  validation?: ValidationRule<TFormValues>;
  depends?: DependsConfig<TFormValues>;

  /** Additional custom properties */
  label?: React.ReactNode;
}

/* =====================================================
   FIELD TYPES
===================================================== */
type InputVariants = 'text' | 'email' | 'number' | 'password' | 'tel';

export interface BaseInputField<TFormValues extends Record<string, any>>
  extends
    BaseField<TFormValues>,
    Omit<React.InputHTMLAttributes<HTMLInputElement>, 'value' | 'onChange' | 'name'> {
  type: InputVariants;
}

export interface TextareaField<TFormValues extends Record<string, any>>
  extends
    BaseField<TFormValues>,
    Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'value' | 'onChange' | 'name'> {
  type: 'textarea';
}

export type InputFieldProps<TFormValues extends Record<string, any>> =
  | BaseInputField<TFormValues>
  | TextareaField<TFormValues>;

export interface SelectField<TFormValues extends Record<string, any>>
  extends BaseField<TFormValues>, Omit<DropdownProps, 'name' | 'label'> {
  type: 'select';
  optionMap?: (options: DropdownProps['options'], fieldValues: FieldValues) => any[];
}

export interface CheckboxField<TFormValues extends Record<string, any>>
  extends
    BaseField<TFormValues>,
    Omit<CheckboxGroupProps, 'name' | 'value' | 'onChange' | 'label'> {
  type: 'checkbox';
}

export interface RadioField<TFormValues extends Record<string, any>>
  extends BaseField<TFormValues>, Omit<RadioProps, 'name' | 'value' | 'label'> {
  type: 'radio';
}

export interface ListField<TFormValues extends Record<string, any>>
  extends BaseField<TFormValues>, Omit<ListProps, 'label'> {
  type: 'list';
}

export interface FileUploadField<TFormValues extends Record<string, any>>
  extends BaseField<TFormValues>, Omit<FileUploadProps, 'onaddfile' | 'name' | 'label'> {
  type: 'fileUpload';
}

export interface MapField<TFormValues extends Record<string, any>>
  extends BaseField<TFormValues>, Omit<MapProps, 'onChange'> {
  type: 'map';
}

export interface DatePickerField<TFormValues extends Record<string, any>>
  extends BaseField<TFormValues>, Omit<DatePickerProps, 'onChange' | 'name' | 'label'> {
  type: 'date';
}

export interface DateRangePickerField<TFormValues extends Record<string, any>>
  extends
    BaseField<TFormValues>,
    Omit<RangeDatePickerProps, 'onChange' | 'startDate' | 'endDate' | 'name' | 'label'> {
  type: 'date-range';
  startDateFieldKey: Path<TFormValues>;
  endDateFieldKey: Path<TFormValues>;
}
export interface CustomField<
  TFormValues extends Record<string, any>,
> extends BaseField<TFormValues> {
  type: 'custom';

  /**
   * Direct component injection
   */
  component?: React.ComponentType<any>;

  /**
   * Render function (recommended for max flexibility)
   */
  render?: (props: {
    value: unknown;
    onChange: (value: unknown) => void;
    error?: string;
    control: Control<TFormValues>;
    field: CustomField<TFormValues>;
    setValue: UseFormSetValue<TFormValues>;
  }) => React.ReactNode;

  /**
   * Extra props passed to component
   */
  props?: Record<string, any>;
}

export type FormFieldSchema<TFormValues extends Record<string, any>> =
  | InputFieldProps<TFormValues>
  | SelectField<TFormValues>
  | CheckboxField<TFormValues>
  | RadioField<TFormValues>
  | ListField<TFormValues>
  | FileUploadField<TFormValues>
  | MapField<TFormValues>
  | DatePickerField<TFormValues>
  | DateRangePickerField<TFormValues>
  | CustomField<TFormValues>;

/* =====================================================
   FORM SECTION
===================================================== */
export interface FormSection<TFormValues extends Record<string, any> = Record<string, any>> {
  type?: 'section';
  className?: string;
  title?: React.ReactNode;
  description?: React.ReactNode;

  layout?: FormLayout;

  fields: FormFieldSchema<TFormValues>[];

  colSpan?: number;
  rowSpan?: number;

  repeatable?: false;
}

type ArrayItemObject<T> = T extends (infer U)[]
  ? U extends Record<string, any>
    ? U
    : never
  : never;

/* =====================================================
   REPEATABLE SECTION 
===================================================== */
export interface RepeatableFormSection<
  TFormValues extends Record<string, any> = Record<string, any>,
  K extends ArrayPath<TFormValues> = ArrayPath<TFormValues>,
> {
  type?: 'repeatable';
  className?: string;
  title?: React.ReactNode;
  description?: React.ReactNode;

  repeatable: true;
  name: K;

  fields: FormFieldSchema<ArrayItemObject<TFormValues[K]>>[];

  minItems?: number;
  maxItems?: number;

  addLabel?: React.ReactNode;
  removeLabel?: React.ReactNode;

  colSpan?: number;
  rowSpan?: number;
}

/* =====================================================
   SECTION GROUP
===================================================== */
export interface FormSectionGroup<TFormValues extends Record<string, any> = Record<string, any>> {
  type: 'group';

  className?: string;
  name?: keyof TFormValues;

  title?: React.ReactNode;
  description?: React.ReactNode;

  layout?: FormLayout;

  variant?: 'card' | 'accordion' | 'tabs' | 'plain';

  visibleIf?: VisibleIf;

  sections: FormSection<TFormValues>[];

  colSpan?: number;
  rowSpan?: number;
}

export type FormContent<TFormValues extends Record<string, any> = Record<string, any>> =
  | FormSection<TFormValues>
  | FormSectionGroup<TFormValues>
  | RepeatableFormSection<TFormValues, ArrayPath<TFormValues>>;

/* =====================================================
   FORM SCHEMA
===================================================== */
export interface JSONFormSchema<TFormValues extends Record<string, any> = Record<string, any>> {
  title?: React.ReactNode;
  description?: React.ReactNode;

  layout?: FormLayout;

  sections?: FormContent<TFormValues>[];
  fields?: FormFieldSchema<TFormValues>[];
}

/* =====================================================
   FORM PROPS
===================================================== */
export interface ConfigurableFormProps<
  TFormValues extends Record<string, any> = Record<string, any>,
> {
  config: JSONFormSchema<TFormValues>;

  defaultValues?: Partial<TFormValues>;

  onSubmit: (data: TFormValues) => void | Promise<void>;

  className?: string;
  formClassName?: string;
  error?: string;

  primaryButtonProps?: ButtonProps;
  secondaryButtonProps?: ButtonProps;

  hasSecondaryButton?: boolean;
  hasFooterButtons?: boolean;

  footer?: () => React.ReactNode;

  onDirtyChange?: (isDirty: boolean) => void;

  customValidators?: CustomValidatorFnType;

  actionButtonPosition?: 'top' | 'bottom' | 'both';

  renderSection?: (props: SectionRenderProps<TFormValues>) => React.ReactNode;

  renderGroup?: (props: GroupRenderProps<TFormValues>) => React.ReactNode;

  renderRepeatableSection?: (props: RepeatableRenderProps<TFormValues>) => React.ReactNode;
}

/* =====================================================
   FORM REF
===================================================== */
export type ConfigurableFormRef<TFormValues extends Record<string, any> = Record<string, any>> = {
  reset: UseFormReset<TFormValues>;
  setValue: UseFormSetValue<TFormValues>;
  getValues: UseFormGetValues<TFormValues>;
  trigger: UseFormTrigger<TFormValues>;
  setError: UseFormSetError<TFormValues>;
  clearErrors: UseFormClearErrors<TFormValues>;
  submit: () => void;
};
