import { Input, Dropdown, RadioGroup, CheckboxGroup, List, FileUpload, Map, DatePicker, RangeDatePicker } from '@msbc/react-toolkit';

export interface FieldComponentMap {
  text: typeof Input;
  email: typeof Input;
  number: typeof Input;
  password: typeof Input;
  textarea: typeof Input;
  tel: typeof Input;
  select: typeof Dropdown;
  radio: typeof RadioGroup;
  checkbox: typeof CheckboxGroup;
  list: typeof List;
  fileUpload: typeof FileUpload;
  map: typeof Map;
  date: typeof DatePicker;
  "date-range": typeof RangeDatePicker
}

export const defaultComponents: FieldComponentMap = {
  text: Input,
  email: Input,
  number: Input,
  password: Input,
  textarea: Input,
  tel: Input,
  select: Dropdown,
  radio: RadioGroup,
  checkbox: CheckboxGroup,
  list: List,
  fileUpload: FileUpload,
  map: Map,
  date: DatePicker,
  "date-range": RangeDatePicker,
};

export class FormComponentRegistry {
  private components: FieldComponentMap = { ...defaultComponents };

  // Register a component with correct prop type binding
  register<T extends keyof FieldComponentMap>(
    type: T,
    component: FieldComponentMap[T]
  ) {
    this.components[type] = component;
  }

  // Get component with proper type inference
  get<T extends keyof FieldComponentMap>(
    type: T
  ): FieldComponentMap[T] {
    return this.components[type];
  }

  getAll(): FieldComponentMap {
    return { ...this.components };
  }
}

export type FieldType = keyof FieldComponentMap;

export const formComponentRegistry = new FormComponentRegistry();