import { FieldValues, RegisterOptions, Path } from 'react-hook-form';
import { BaseField, CustomValidatorFnType } from './ConfigurableForm.types';

export function getRowPrefix(fieldName: string) {
  const parts = fieldName.split('.');
  if (parts.length >= 3) {
    return parts.slice(0, parts.length - 1).join('.');
  }
  return null;
}

export function getValueByPath(obj: any, path: string) {
  return path.split('.').reduce((acc, key) => acc?.[key], obj);
}

type RHFRules<T extends FieldValues> = Omit<
  RegisterOptions<T, Path<T>>,
  'disabled' | 'setValueAs' | 'valueAsNumber' | 'valueAsDate'
>;

/**
 * Convert JSON validation DSL into react-hook-form RegisterOptions
 * customFns: map of custom validator names -> functions
 */
export function mapValidationToRHF<TFormValues extends FieldValues>(
  field: BaseField<TFormValues>,
  customFns?: CustomValidatorFnType
): RHFRules<TFormValues> {
  const rules: RHFRules<TFormValues> = {};
  const v = field.validation;
  // if (!v) return rules;

  if ((v && v.required !== undefined) || field.isRequired) {
    rules.required = v
      ? typeof v.required === 'object'
        ? v.required.message
        : 'This field is required'
      : 'This field is required';
  }

  if (v && v.requiredIf) {
    const condition = v.requiredIf;

    rules.validate = {
      ...(typeof rules.validate === 'object' ? rules.validate : {}),

      requiredIf: (val: any, fieldValues: Record<string, any>) => {
        const rowPrefix = getRowPrefix(field.name);

        const path = rowPrefix ? `${rowPrefix}.${condition.field}` : condition.field;

        const otherValue = getValueByPath(fieldValues, path);

        let shouldRequire = false;

        switch (condition.operator) {
          case 'equals':
            shouldRequire = otherValue === condition.value;
            break;

          case 'notEquals':
            shouldRequire = otherValue !== condition.value;
            break;

          case 'exists':
            shouldRequire = otherValue !== undefined;
            break;

          case 'notEmpty':
          default:
            shouldRequire = otherValue !== undefined && otherValue !== null && otherValue !== '';
        }

        if (shouldRequire && (val === undefined || val === null || val === '')) {
          return condition.message || 'This field is required';
        }

        return true;
      },
    };
  }

  if (v && v.requiredIfAny) {
    const condition = v.requiredIfAny;

    rules.validate = {
      ...(rules.validate || {}),

      requiredIfAny: (val: any, fieldValues: Record<string, any>) => {
        const rowPrefix = getRowPrefix(field.name);

        const shouldRequire = condition.fields.some((f) => {
          const path = rowPrefix ? `${rowPrefix}.${f}` : f;
          const value = getValueByPath(fieldValues, path);

          return value !== undefined && value !== null && value !== '';
        });

        if (shouldRequire && (val === undefined || val === null || val === '')) {
          return condition.message || 'This field is required';
        }

        return true;
      },
    };
  }

  if (v && v.minLength !== undefined) {
    const payload =
      typeof v.minLength === 'object'
        ? v.minLength
        : { value: v.minLength, message: `Minimum ${v.minLength} characters` };
    rules.minLength = { value: payload.value, message: payload.message };
  }

  if (v && v.maxLength !== undefined) {
    const payload =
      typeof v.maxLength === 'object'
        ? v.maxLength
        : { value: v.maxLength, message: `Maximum ${v.maxLength} characters` };
    rules.maxLength = { value: payload.value, message: payload.message };
  }

  if (v && v.min !== undefined) {
    const payload =
      typeof v.min === 'object' ? v.min : { value: v.min, message: `Can't be less than ${v.min}` };
    rules.min = { value: payload.value, message: payload.message };
  }

  if (v && v.max !== undefined) {
    const payload =
      typeof v.max === 'object'
        ? v.max
        : { value: v.max, message: `Can't be greater than ${v.max}` };
    rules.max = { value: payload.value, message: payload.message };
  }

  if (v && v.pattern !== undefined) {
    const payload =
      typeof v.pattern === 'object' ? v.pattern : { value: v.pattern, message: `Invalid format` };
    rules.pattern = { value: new RegExp(payload.value), message: payload.message };
  }

  if (v && v.custom !== undefined && customFns) {
    const fn = customFns[v.custom.fn];
    if (fn) {
      rules.validate = async (val: any, fieldValues: FieldValues) => {
        const res = await Promise.resolve(fn(val, fieldValues));
        // allow boolean true or truthy; string -> message; boolean false -> message
        if (typeof res === 'string') return res;
        if (res === true) return true;
        return v.custom!.message || 'Invalid value';
      };
    }
  }

  return rules;
}
