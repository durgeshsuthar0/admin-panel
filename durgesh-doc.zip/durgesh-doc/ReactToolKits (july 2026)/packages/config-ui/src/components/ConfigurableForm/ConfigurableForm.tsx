import React from "react";
import { useForm, useFieldArray, ArrayPath, Path } from "react-hook-form";
import { Button } from "@msbc/react-toolkit";
import {
  ConfigurableFormProps,
  ConfigurableFormRef,
  DependsConfig,
  FormContent,
  FormFieldSchema,
  FormSection,
  FormSectionGroup,
  RepeatableFormSection,
} from "./ConfigurableForm.types";
import "./ConfigurableForm.css";
import { FormElement } from "./FormElement";
import { classname, cns } from "@msbc/utils";

type ArrayItemObject<T> =
  T extends (infer U)[]
  ? U extends Record<string, any>
  ? U
  : never
  : never;

export const buildArrayPath = <
  TFormValues extends Record<string, any>,
  K extends ArrayPath<TFormValues>,
  F extends Path<ArrayItemObject<TFormValues[K]>>
>(
  key: K,
  index: number,
  field: F
): Path<TFormValues> => {
  return `${key}.${index}.${field}` as Path<TFormValues>;
}

export const mapDependsToFormPath = <
  TFormValues extends Record<string, any>,
  K extends ArrayPath<TFormValues>
>(
  depends: DependsConfig<ArrayItemObject<TFormValues[K]>>,
  section: K,
  index: number
): DependsConfig<TFormValues> => {
  return {
    ...depends,
    fieldName: buildArrayPath(section, index, depends.fieldName),
    api: depends.api
      ? {
        ...depends.api,
        mapParamTo: depends.api.mapParamTo
          ? buildArrayPath(section, index, depends.api.mapParamTo) as Path<TFormValues>
          : undefined,
      }
      : undefined,
  } as DependsConfig<TFormValues>;
}

const ConfigurableFormInner = <
  TFormValues extends Record<string, any>
>(
  {
    config,
    defaultValues = {} as Partial<TFormValues>,
    onSubmit,
    className = "",
    formClassName = "",
    error = "",
    primaryButtonProps,
    secondaryButtonProps,
    hasSecondaryButton = false,
    customValidators,
    hasFooterButtons = true,
    footer: renderFooter = undefined,
    onDirtyChange,
    actionButtonPosition = "bottom",
    renderRepeatableSection,
    renderSection,
    renderGroup,
  }: ConfigurableFormProps<TFormValues>,
  ref: React.ForwardedRef<ConfigurableFormRef<TFormValues>>
) => {
  const cn = classname("configurable-form");
  const computedDefaults = React.useMemo(() => {
    const buildFieldDefaults = (fields: any[]) =>
      fields.reduce((acc, f) => {
        const value =
          defaultValues[f.name] ??
          f.default ??
          (f.type === "fileUpload" ? [] : "");

        acc[f.name] = value;
        return acc;
      }, {} as Record<string, any>);

    const buildSectionDefaults = (sections: any[]) =>
      sections.reduce((acc, item) => {
        //SECTION GROUP
        if (item.type === "group" && Array.isArray(item.sections)) {
          Object.assign(acc, buildSectionDefaults(item.sections));
          return acc;
        }

        //NORMAL SECTION
        const section = item;

        if (section.repeatable && section.name) {
          acc[section.name] = defaultValues[section.name] ?? [{}];
        } else {
          Object.assign(acc, buildFieldDefaults(section.fields));
        }

        return acc;
      }, {} as Record<string, any>);

    // SECTION MODE (with or without groups)
    if (config.sections) {
      return buildSectionDefaults(config.sections);
    }

    // FLAT FIELD MODE
    return buildFieldDefaults(config.fields ?? []);
  }, [config]);


  const {
    control,
    handleSubmit,
    formState: { isSubmitting, isDirty },
    reset,
    setValue,
    getValues,
    trigger,
    setError,
    clearErrors,
    unregister,
  } = useForm<TFormValues>({
    defaultValues: computedDefaults,
    shouldUnregister: false,
    mode: 'onChange',
  });

  React.useImperativeHandle(ref, () => ({
    reset,
    setValue,
    getValues,
    trigger,
    setError,
    clearErrors,
    submit: () => handleSubmit(onSubmit)(),
  }));

  React.useEffect(() => {
    reset(computedDefaults);
  }, [computedDefaults, reset]);

  // notify parent when dirty state changes
  React.useEffect(() => {
    if (typeof onDirtyChange === 'function') onDirtyChange(Boolean(isDirty));
  }, [isDirty, onDirtyChange]);

  const renderSectionInternal = (section: FormSection<TFormValues>, index: number) => {
    const defaultRender = () => (
      <div key={index} className={cn('section', section.className)}
        style={{
          gridColumn: `span ${section.colSpan || 1}`,
          gridRow: `span ${section.rowSpan || 1}`,
        }}
      >
        {section.title && <h3 className={cn('section-title')}>{section.title}</h3>}
        {section.description && (
          <p className={cn('section-description')}>{section.description}</p>
        )}

        <div
          className={cn('grid')}
          style={{
            gridTemplateColumns: `repeat(${section.layout?.columns || 2}, 1fr)`,
          }}
        >
          {section.fields.map((field) => (
            <FormElement<TFormValues>
              key={field.name}
              field={field}
              control={control}
              customValidators={customValidators}
              setValue={setValue}
              clearErrors={clearErrors}
              unregister={unregister}
            />
          ))}
        </div>
      </div>
    );
    if (renderSection) {
      return renderSection({
        section,
        control,
        customValidators,
        setValue,
        defaultRender,
        clearErrors,
        unregister
      });
    }

    return defaultRender();
  };

  const renderRepeatableSectionInternal = (section: RepeatableFormSection<TFormValues>) => {
    const { fields, append, remove } = useFieldArray({
      control,
      name: section.name,
    });

    const defaultRender = () => (
      <div
        className={cn("section-repeatable", section.className)}
        style={{
          gridColumn: `span ${section.colSpan || 1}`,
          gridRow: `span ${section.rowSpan || 1}`,
        }}
      >
        <div className={cn("section-header")}>
          <h3>{section.title}</h3>
          <div>
            <span
              className={cn("add-btn")}
              onClick={() => append({} as TFormValues[typeof section.name][number])}
            >
              {section.addLabel || "Add"}
            </span>
          </div>
        </div>

        <table className={cn("table")}>
          <thead>
            <tr className={cn("row")}>
              {section.fields.map((field) => (
                <th key={field.name} className={cn("td")}>
                  {field.label}
                </th>
              ))}
              <th className={cn("action")}></th>
            </tr>
          </thead>

          <tbody>
            {fields.map((item, index) => (
              <tr key={item.id} className={cn("row")}>
                {section.fields.map((field) => (
                  <td key={field.name} className={cn("td")}>
                    <FormElement<TFormValues>
                      field={{
                        ...field,
                        name: buildArrayPath(section.name, index, field.name),
                        depends: field.depends
                          ? mapDependsToFormPath(field.depends, section.name, index)
                          : undefined,
                        label: "",
                      } as FormFieldSchema<TFormValues>}
                      control={control}
                      customValidators={customValidators}
                      setValue={setValue}
                      clearErrors={clearErrors}
                      unregister={unregister}
                      wrappedInField={false}
                    />
                  </td>
                ))}

                <td className={cn("td")}>
                  <button
                    type="button"
                    disabled={fields.length === 1}
                    className={cn("delete-btn")}
                    onClick={() => remove(index)}
                  >
                    {section.removeLabel ?? "Remove"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
    if (renderRepeatableSection) {
      return renderRepeatableSection({
        section,
        fields,
        append,
        remove,
        control,
        customValidators,
        setValue,
        defaultRender,
        clearErrors,
        unregister
      });
    }

    return defaultRender();
  };


  const renderGroupInternal = (group: FormSectionGroup<TFormValues>, index: number) => {
    const defaultRender = (index: number) => (
      <div
        key={`group-${index}`}
        className={cn('section-group', group.className)}
        style={{
          gridColumn: `span ${group.colSpan || 1}`,
          gridRow: `span ${group.rowSpan || 1}`,
        }}
      >
        {group.title && <h2 className={cn('group-title')}>{group.title}</h2>}
        {group.description && (
          <p className={cn('group-description')}>{group.description}</p>
        )}

        <div
          className={cn('group-grid')}
          style={{
            gridTemplateColumns: `repeat(${group.layout?.columns || 1}, 1fr)`,
          }}
        >
          {group.sections.map((section, i) =>
          (
            renderSectionInternal(section, i)
          )
          )}
        </div>
      </div>
    );
    if (renderGroup) {
      return renderGroup({
        group,
        control,
        customValidators,
        setValue,
        defaultRender,
        index,
        clearErrors,
        unregister
      });
    }

    return defaultRender(index);
  };

  function isGroup<T extends Record<string, any>>(
    item: FormContent<T>
  ): item is FormSectionGroup<T> {
    return item.type === "group";
  }

  function isRepeatable<T extends Record<string, any>>(
    item: FormContent<T>
  ): item is RepeatableFormSection<T> {
    return (item as RepeatableFormSection<T>).repeatable === true;
  }

  const {
    text: secondaryButtonText,
    ...destructedSecondaryButtonProps
  } = secondaryButtonProps ?? {};

  const {
    text: primaryButtonText,
    ...destructedPrimaryButtonProps
  } = primaryButtonProps ?? {};

  return (
    <div className={cns(cn(), className)}>
      <form
        className={cns(cn('form'), formClassName)}
        onSubmit={handleSubmit(onSubmit)}
      >
        <div className={cn('top-container')}>
          <div className={cn('heading-section')}>
            {config.title && <h2 className={cn('title')}>{config.title}</h2>}
            {config.description && (
              <p className={cn('description')}>{config.description}</p>
            )}
          </div>
          {(hasFooterButtons && (actionButtonPosition == 'top' || actionButtonPosition == 'both')) &&
            (
              <div className={cn('actions', {
                'top': true
              })}>
                {hasSecondaryButton && (
                  <Button
                    type="button"
                    variant="secondary"
                    text={secondaryButtonText || "Reset"}
                    onClick={() => reset()}
                    {...destructedSecondaryButtonProps}
                  />
                )}

                <Button
                  text={primaryButtonText || "Submit"}
                  {...destructedPrimaryButtonProps}
                  disabled={isSubmitting || destructedPrimaryButtonProps.disabled}
                  type="submit"
                />
              </div>
            )
          }
        </div>
        {error && <div className={cn('error')}>{error}</div>}
        <div className={cn('container')}
          style={{
            gridTemplateColumns: `repeat(${config.sections ? config.layout?.columns || 2 : 1}, 1fr)`,
          }}>
          {/* SECTION MODE */}
          {config.sections
            ? config.sections?.map((item, index) => {
              if (isGroup<TFormValues>(item)) {
                return renderGroupInternal(item, index);
              }

              if (isRepeatable<TFormValues>(item)) {
                return renderRepeatableSectionInternal(item);
              }

              return renderSectionInternal(item, index);
            })
            : // FLAT FIELDS MODE
            (
              <div
                className={cn('grid')}
                style={{
                  gridTemplateColumns: `repeat(${config.layout?.columns || 2}, 1fr)`,
                }}
              >
                {config.fields?.map((field) => (

                  <FormElement<TFormValues>
                    key={field.name}
                    field={field}
                    control={control}
                    customValidators={customValidators}
                    setValue={setValue}
                    clearErrors={clearErrors}
                    unregister={unregister}
                  />
                ))}
              </div>
            )}

        </div>
        {/* ACTION BUTTONS */}


        {(hasFooterButtons && (actionButtonPosition == 'bottom' || actionButtonPosition == 'both')) ?
          (
            <div className={cn('actions')}>
              {hasSecondaryButton && (
                <Button
                  type="button"
                  variant="secondary"
                  text={secondaryButtonText || "Reset"}
                  onClick={() => reset()}
                  {...destructedSecondaryButtonProps}
                />
              )}

              <Button
                text={primaryButtonText || "Submit"}
                {...destructedPrimaryButtonProps}
                disabled={isSubmitting || destructedPrimaryButtonProps.disabled}
                type="submit"
              />
            </div>
          )
          : renderFooter?.()}


      </form>
    </div>
  );
};

export const ConfigurableForm = React.forwardRef(ConfigurableFormInner) as <
  TFormValues extends Record<string, any>
>(
  props: ConfigurableFormProps<TFormValues> & {
    ref?: React.Ref<ConfigurableFormRef<TFormValues>>;
  }
) => React.ReactElement;
