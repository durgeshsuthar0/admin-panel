import React, { useEffect, useRef } from "react";
import { Control, Path, PathValue, useController, UseFormClearErrors, UseFormSetValue, UseFormUnregister, useWatch } from "react-hook-form";
import { CustomField, CustomValidatorFnType, FormFieldSchema, VisibleIf } from "./ConfigurableForm.types";
import { getValueByPath, mapValidationToRHF } from "./validationMapper";
import { FieldComponentMap, FieldType, formComponentRegistry } from "./FormComponentRegistry";
import { CheckboxGroup, DatePicker, Dropdown, FileUpload, Input, List, Map, RadioGroup, RangeDatePicker } from "@msbc/react-toolkit";
import { isEmpty } from "@msbc/utils";

function assertNever(x: never): never {
  throw new Error(`Unexpected object: ${JSON.stringify(x)}`);
}

export interface FormElementProps<TFormValues extends Record<string, any>> {
  field: FormFieldSchema<TFormValues>;
  control: Control<TFormValues>;
  customValidators?: CustomValidatorFnType;
  setValue: UseFormSetValue<TFormValues>;
  clearErrors: UseFormClearErrors<TFormValues>;
  unregister: UseFormUnregister<TFormValues>;
  wrappedInField?: boolean;
}

export type InputVariant =
  | "text"
  | "email"
  | "number"
  | "password"
  | "textarea"
  | "tel";

const FieldVariantMap: Record<FieldType, InputVariant | undefined> = {
  text: "text",
  email: "email",
  number: "number",
  password: "password",
  textarea: "textarea",
  tel: "tel",

  select: undefined,
  radio: undefined,
  checkbox: undefined,
  list: undefined,
  fileUpload: undefined,
  map: undefined,
  date: undefined,
  "date-range": undefined
};
function getComparableValue(v: any) {
  return v && typeof v === "object" && "value" in v ? v.value : v;
}

export const FormElement = <
  TFormValues extends Record<string, any>
>({
  field,
  control,
  customValidators,
  setValue,
  clearErrors,
  unregister,
  wrappedInField = true,
}: FormElementProps<TFormValues>) => {

  const uploadErrorRef = useRef<string | null>(null);

  const watchedValues = useWatch<TFormValues>({ control });
  // derive values used by hooks
  const sourceFieldName = field.depends?.fieldName;

  const isVisible = evaluateVisible(field.visibleIf);

  // --- CALL HOOKS UNCONDITIONALLY ---
  const { field: controllerField, fieldState } = useController<TFormValues>({
    name: field.name,
    control,
    shouldUnregister: false,
    rules: isVisible ? {
      validate: () => {
        if (uploadErrorRef.current) {
          return uploadErrorRef.current;
        }
        return true;
      },
      ...mapValidationToRHF(field, customValidators),
    } : {},
  });

  const watchedSource = useWatch<TFormValues>({
    control,
    name: sourceFieldName as any,
    exact: true,
    defaultValue: sourceFieldName && watchedValues ? getValueByPath(watchedValues, sourceFieldName) : undefined
  });

  const hasParentSelection = (v: any) => {
    const cv = getComparableValue(v);
    return (
      cv !== undefined &&
      cv !== null &&
      !(typeof cv === "string" && cv.trim() === "")
    );
  };

  const prevParentComparable = useRef<any>(undefined);
  const didInitDepends = useRef(false);

  useEffect(() => {
    if (!field.depends) return;

    const { populate } = field.depends;

    const selected = watchedSource;
    const parentSelected = hasParentSelection(selected);
    const currentComparable = getComparableValue(selected);

    // ----------------------------------
    // 2) VALUE POPULATION (do NOT block this because of API logic)
    // ----------------------------------
    if (populate) {
      const rules = Array.isArray(populate) ? populate : [populate];

      const triggerValue = selected;
      const triggerComparable = getComparableValue(triggerValue);

      const shouldRun =
        typeof field.depends?.when === "function"
          ? field.depends.when(triggerComparable, watchedValues)
          : parentSelected;

      if (!shouldRun) return;

      const runPopulation = () => {
        rules.forEach(({ from, to, transform, onlyIfEmpty }) => {
          const sourceVal = watchedValues?.[from];
          if (isEmpty(sourceVal)) return;

          const currentTargetVal = watchedValues?.[to];
          if (onlyIfEmpty && !isEmpty(currentTargetVal)) return;

          const finalValue = transform ? transform(sourceVal) : sourceVal;

          setValue(to, finalValue as any, { shouldDirty: true });
        });
      };

      if (field.depends?.confirm?.message) {
        const confirmed = window.confirm(field.depends.confirm.message);
        if (!confirmed) return;
      }

      runPopulation();
    }

    didInitDepends.current = true;
    prevParentComparable.current = currentComparable;
  }, [watchedSource]);

  useEffect(() => {
    if (!isVisible) {
      clearErrors(field.name);
      // setValue(field.name, undefined as any);
      unregister(field.name);
    }
  }, [isVisible, field.name, clearErrors, setValue, unregister]);

  const apiCurrentComparable = React.useMemo(() => {
    if (!field.depends?.api || !watchedSource) return undefined;
    const { transform } = field.depends.api;
    let currentComparable: any;
    if (transform) {
      currentComparable = transform(watchedSource);
    } else if (typeof watchedSource === "object" && watchedSource !== null) {
      if ("value" in watchedSource) currentComparable = watchedSource.value;
      else if ("id" in watchedSource) currentComparable = watchedSource.id;
      else if ("key" in watchedSource) currentComparable = watchedSource.key;
      else currentComparable = watchedSource; // fallback
    } else {
      currentComparable = watchedSource;
    }
    return currentComparable;
  }, [field.depends?.api, watchedSource]);

  const prevApiComparable = useRef<any>(undefined);
  const didInitApi = useRef(false);
  useEffect(() => {
    if (didInitApi.current && prevApiComparable.current !== apiCurrentComparable) {
      setValue(field.name, null as any);
    }
    didInitApi.current = true;
    prevApiComparable.current = apiCurrentComparable;
  }, [apiCurrentComparable, field.name, setValue]);

  const apiConfig = React.useMemo(() => {
    // no api defined
    if (field.type !== 'select' && field.type !== 'radio' && field.type !== 'list') return undefined;
    if (!field.api) return undefined;

    // not dependent api
    if (!field.depends?.api) return field.api;

    // no parent selected
    if (!watchedSource || !hasParentSelection(apiCurrentComparable)) return undefined;

    const updatedApi = { ...field.api };

    if (field.depends.api.appendToUrl) {
      updatedApi.url = `${field.api.url}/${apiCurrentComparable}`;
    }

    if (field.depends.api.mapParamTo) {
      updatedApi.params = {
        ...(field.api.params || {}),
        [field.depends.api.mapParamTo]: apiCurrentComparable,
      };
    }

    return updatedApi;
  }, [field, watchedSource, apiCurrentComparable]);

  // --- NOW PERFORM EARLY RETURNS THAT DO NOT AFFECT HOOK ORDER ---
  function evaluateVisible(visibleIf?: VisibleIf): boolean {
    if (!visibleIf) return true;

    const evaluateRule = (rule: VisibleIf): boolean => {
      // ---- GROUP ----
      if ('rules' in rule) {
        return rule.operator === 'AND'
          ? rule.rules.every(evaluateRule)
          : rule.rules.some(evaluateRule);
      }

      const val = getComparableValue(watchedValues[rule.field]);

      // ---- FUNCTION RULE (custom) ----
      if ('when' in rule) {
        return rule.when(val, watchedValues);
      }

      // ---- DECLARATIVE CONDITION ----
      switch (rule.operator) {
        case 'exists':
          return !isEmpty(val);

        case 'equals':
          return val === rule.value;

        case 'notEquals':
          return val !== rule.value;

        case 'in':
          return Array.isArray(rule.value)
            ? rule.value.some(v => v === val)
            : false;

        case 'notIn':
          return Array.isArray(rule.value)
            ? !rule.value.some(v => v === val)
            : true;

        default:
          // ✅ This is the ONLY correct exhaustive assertion here
          return assertNever(rule as never);
      }
    };

    return evaluateRule(visibleIf);
  };

  if (!isVisible) return null;

  if (!field.type) {
    console.warn(`field type not specified for field '${(field as FormFieldSchema<TFormValues>).name}'`);
    console.warn(`field type not specified for field '${(field as FormFieldSchema<TFormValues>).name}'`);
    return null;
  }

  if (field.type === "custom") {
    const customField = field as CustomField<TFormValues>;

    const sharedProps = {
      value: controllerField.value,
      onChange: (val: any) =>
        val?.target
          ? controllerField.onChange(val.target.value)
          : controllerField.onChange(val),
      error: fieldState.error?.message,
      control,
      values: watchedValues,
      setValue,
      field: customField,
    };

    if (customField.render) {
      return <>{customField.render(sharedProps)}</>;
    }

    if (customField.component) {
      const Component = customField.component;
      return <Component {...customField.props} {...sharedProps} />;
    }

    console.warn(`Custom field '${field.name}' missing render/component`);
    return null;
  }

  const Component = formComponentRegistry.get(
    field.type as keyof FieldComponentMap
  );

  if (!Component) {
    console.warn(`Unknown form field type '${field.type}'`);
    return null;
  }

  const commonProps = {
    value: controllerField.value,
    onChange: (val: any) =>
      val?.target
        ? controllerField.onChange(val.target.value)
        : controllerField.onChange(val),
    error: fieldState.error?.message,
  };

  const { validation, visibleIf, ...restFieldProps } = field as any;

  const fieldRender = () => {
    switch (field.type) {
      // -----------------------------
      // INPUT TYPE COMPONENTS
      // -----------------------------
      case "text":
      case "email":
      case "number":
      case "password":
      case "tel": {
        return (
          <Input
            {...restFieldProps}
            variant={FieldVariantMap[field.type] as Exclude<InputVariant, "textarea">}
            {...commonProps}
          />
        );
      }

      case "textarea": {
        return (
          <Input
            {...restFieldProps}
            variant="textarea"
            {...commonProps}
          />
        );
      }

      case "select":
        {
          const { optionMap, options, ...restSelectFieldProps } = restFieldProps;
          let finalOptions = options;
          if (optionMap) {
            finalOptions = optionMap(options, watchedValues);
          }
          return (
            <Dropdown
              {...restSelectFieldProps}
              options={finalOptions}
              {...commonProps}
              api={apiConfig}
            />
          );
        }

      case "radio":
        return (
          <RadioGroup
            {...restFieldProps}
            {...commonProps}
            api={apiConfig}
          />
        );

      case "checkbox":
        return (
          <CheckboxGroup
            {...field}
            {...commonProps}
          />
        );

      // -----------------------------
      // LIST COMPONENT
      // -----------------------------
      case "list":
        return (
          <List
            {...field}
            {...commonProps}
            api={apiConfig}
          />
        );

      case "fileUpload":
        return (
          <FileUpload
            files={controllerField.value}
            onerror={(error) => {
              // @ts-expect-error -- fix types later
              const message = error?.sub ? `${error.main} — ${error.sub}` : error?.main || "File upload failed";
              uploadErrorRef.current = message;
            }}
            onupdatefiles={(fileItems) => {
              uploadErrorRef.current = null;

              const value = fileItems.map((item) => {
                // New upload
                if (item.file instanceof File) {
                  return item.file;
                }

                if (typeof item.source === 'string') {
                  return {
                    source: item.source,
                    options: {
                      type: 'local',
                      file: item.file ?? {
                        name: item.filename || 'existing-file',
                        size: item.fileSize || 0,
                        type: item.fileType || 'image/*'
                      }
                    }
                  };
                }

                return null;
              }).filter(Boolean);

              controllerField.onChange(value);
            }}
            error={fieldState.error?.message || uploadErrorRef.current}
            {...restFieldProps}
          />
        );

      case "map":
        return (
          <Map
            {...restFieldProps}
            onChange={(values: Record<string, any>) => {
              Object.keys(values).forEach((key) => {
                setValue(key as Path<TFormValues>, values[key]);
              });
              controllerField.onChange(values)
            }}
            api={apiConfig}
          />
        );

      case "date":
        return (
          <DatePicker
            {...field}
            {...commonProps}
          />
        );

      case "date-range":
        {
          const { startDateFieldKey, endDateFieldKey, ...restField } = field;
          const startDateValue = getValueByPath(watchedValues, startDateFieldKey);
          const endDateValue = getValueByPath(watchedValues, endDateFieldKey);
          return (
            <RangeDatePicker
              {...restField}
              startDate={startDateValue}
              endDate={endDateValue}
              onChange={(start: Date | null, end: Date | null) => {
                setValue(startDateFieldKey, start as PathValue<TFormValues, typeof startDateFieldKey>, { shouldDirty: true });
                setValue(endDateFieldKey, end as PathValue<TFormValues, typeof startDateFieldKey>, { shouldDirty: true });
              }}
              error={fieldState.error?.message}
            />
          )
        }

      default:
        return <></>;
    }
  }
  if (!wrappedInField) return fieldRender();
  return (
    <div
      key={field.name}
      className="configurable-form__field"
      style={{
        gridColumn: `span ${field.colSpan || 1}`,
        gridRow: `span ${field.rowSpan || 1}`,
      }}
    >
      {fieldRender()}
    </div>
  );
};
