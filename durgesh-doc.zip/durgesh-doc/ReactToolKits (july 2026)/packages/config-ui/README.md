# `@msbc/config-ui` Developer Documentation

`@msbc/config-ui` is a React toolkit package that provides highly customizable and JSON-configurable UI components designed to accelerate development of forms and data dashboards within the monorepo.

## Table of Contents

- [Overview](#overview)
- [Installation](#installation)
- [Components](#components)
  - [ConfigurableForm](#configurableform)
  - [ConfigurableDashboard](#configurabledashboard)
- [Types & Interfaces](#types--interfaces)

---

## Overview

The `config-ui` package follows a configuration-driven UI approach. Instead of building complex forms and data grids imperatively, developers pass structured JSON configurations (`DashboardConfig` and `ConfigurableFormProps["config"]`) that dictate the layout, behavior, API integration, and validation rules of the rendered components.

---

## Components

### `ConfigurableForm`

A dynamic form renderer that uses a JSON schema to instantiate fields, manage form state, validate input, and handle API requests for droplists. 

**Basic Usage:**

```tsx
import { ConfigurableForm, type ConfigurableFormProps } from "@msbc/config-ui";

const MyForm = () => {
  const formConfig: ConfigurableFormProps["config"] = {
    layout: { columns: 1 },
    fields: [
      {
        name: "description",
        type: "textarea",
        placeholder: "Enter description",
        isRequired: true,
        validation: {
          required: { message: "Description is required" },
          maxLength: { value: 500, message: "Max 500 characters" }
        }
      }
    ]
  };

  const handleSubmit = async (data: Record<string, any>) => {
    // data contains the form values
    console.log(data);
  };

  return (
    <ConfigurableForm 
      config={formConfig} 
      onSubmit={handleSubmit} 
      primaryButtonProps={{ text: "Save" }} 
    />
  );
};
```

#### JSONFormSchema Properties

The `JSONFormSchema` dictates the entire layout, logic, and rendering of the form. 

**Root Layout & Sections**
- `layout`: Dictates the global CSS grid columns (e.g. `{ columns: 1 }`).
- `sections`: An array used to break forms down into distinctly titled blocks. Sections can be nested and support customized layouts. 
  - `title` (string): Header text for the section.
  - `type` ("group" | undefined): Allows visually grouping sub-sections.
  - `layout` (object): Overrides the root layout for this specific section (e.g., `{ columns: 4 }`).
  - `colSpan` (number): How many columns the section spans in its parent's grid.
  - `fields` (array): The inputs belonging to this section.

**Field Definitions**
Every object in the `fields` array renders a singular input component. Shared properties include:
- `name` (string): The form-state key this field binds to.
- `type` (string): The component type (`"text"`, `"textarea"`, `"select"`, `"date"`, `"checkbox"`, `"radio"`, etc.).
- `label` (string): The text label displayed above the field.
- `placeholder` (string): Input placeholder text. 
- `isRequired` / `required` (boolean): Enforces strict input validation before submission.
- `isDisabled` (boolean): Freezes input interaction.
- `colSpan` (number): How many columns the field takes up in the current `layout` grid.
- `style` (object): Inline CSS styling injection (e.g. `{ color: "black" }`).
- `depends`: Logical linkage setting field behavior based on other fields.

**Advanced Validations (`validation`)**
The `validation` object supports native react-hook-form bindings:
- `minLength`, `maxLength`, `pattern` (Regex evaluations).
- `custom`: Client-side function definitions for deep validation (e.g., `{ fn: "uniqueContactMobile", message: "Mobile number must be unique" }`).

**API Integrated Fields (e.g. `select`)**
Select fields can dynamically load options using the `api` configuration block.
- `api`: Target URL definition (e.g., `{ url: apiUrls.getUserList }`). Requires `apiEnabled: true`.
- `apiResponseMapper`: Callback to parse complex network responses into flat arrays (e.g., `(data) => data.data.results`).
- `labelKey` / `valueKey`: Defines which keys on the parsed objects map to the label rendering and value binding respectively.
- `options`: Hardcoded fallback options (or initial state before API resolves).
- `isMulti`: Allows multiple selections.

**Field Dependencies (`depends`)**
Advanced configuration unlocking chained data populating (e.g. "Same as Billing Address" checkbox triggering a copy of values).
- `fieldName`: The target field to monitor for changes.
- `when`: Logical evaluation function (e.g., `(v) => v === "true"`).
- `populate`: An array mapping fields to sync values into (e.g., `[{ from: "b_country", to: "s_country" }]`).
- `api.mapParamTo`: Triggers sequential API calls dynamically (e.g. fetching `state` dependent on the `country` selected).

**Repeatable Blocks**
Fields or sections can be made repeatable for array structures (e.g. "Contact Persons").
- `repeatable` (boolean): Flag enabling array mode.
- `addLabel` (string): Custom text for the "Add New" action button.
- `minItems` (number): Enforces a minimum quantity of items to exist.

---

### `ConfigurableDashboard`

A powerful layout block tailored to render complex data views, toggling seamlessly between card layouts ("list") and tabular grids ("table"). 

**Basic Usage:**

```tsx
import { ConfigurableDashboard, type DashboardConfig, type ConfigurableDashboardHandle } from "@msbc/config-ui";
import { useRef } from "react";

const MyDashboard = () => {
  const dashboardRef = useRef<ConfigurableDashboardHandle | null>(null);

  const config: DashboardConfig = {
    title: "My Documents",
    enableModeSwitch: true,
    viewMode: "list",
    api: {
      url: "/api/documents/list",
      method: "get",
      params: { limit: 50 }
    },
    listProps: {
        CardComponent: ({ item }) => <MyCustomCard item={item} />,
        layout: { columns: 4, gap: "16px", cardWidth: "1fr", wrap: true }
    },
    tableProps: {
        rowHeight: 58,
        columnDefs: [
            { field: "name", headerName: "Category" },
            { field: "document_count", headerName: "Count" }
        ]
    }
  };

  return (
    <ConfigurableDashboard ref={dashboardRef} config={config} />
  );
};
```

#### DashboardConfig Properties

The `DashboardConfig` schema is extensive, allowing you to control headers, search bars, filters, table renderings, list renderings, bulk actions, and data-fetching. Below are the key properties you can configure:

**Header & General Layout**
- `title` (string | ReactNode): The title displayed at the top of the dashboard. Can be a simple string or a custom React component (e.g., a header with back button and record counts).
- `viewMode` ("list" | "table"): Sets the default view visualization.
- `enableModeSwitch` (boolean): Whether to render a view toggle.
- `modeSwitchProps`: Configuration for the toggle switch if enabled. 
  - `onIcon`, `offIcon` (ReactNode), `inactiveColor` (string), `className`.
- `createButtonProps`: Configuration for the primary action button to the right of the header.
  - `text` (string), `icon` (ReactNode), `onClick` (function).
- `actions`: Array of secondary action buttons (e.g., for bulk table row operations like "Delete Users").
  - Each action takes `text`, `variant`, `onClick`, and `disabled`.

**Search & Filters**
- `hasSearch` (boolean): Enables the global search bar.
- `searchBarProps`: Controls search bar appearance (e.g. `placeholder`, `leftIcon`).
- `filters`: An array defining dynamic filters to apply to the API requests. Available types:
  - `date-range`: Renders a date picker range (Props: `name`, `placeholder`, `dateFormat`, `timeZone`).
  - `select`: Renders a dropdown (Props: `name`, `placeholder`, `options` (hardcoded), or `api` (to fetch options dynamically), `labelKey`, `valueKey`, `apiResponseMapper`).
  - `filterOption`: Custom function to exclude certain fetched options (e.g. `(option) => option.value != "1"`).

**Data Fetching (`api`)**
- `api`: The configuration payload passed internally to `useApiRequest`.
  - `url` (string): The API endpoint.
  - `method` (string): Usually `"get"` for dashboards.
  - `params` (object): Default query parameters (e.g., `{ limit: 50 }`).
  - `config` (object): Axios configs, like `{ authRequired: true }`.
  - `autoFetch` (boolean): Whether to fetch data immediately on mount.
- `apiResponseMapper`: A custom callback allowing you to format the API response from the server into the standardized `{ data, currentPage, totalRecords, totalPage }` format expected by the dashboard and pagination components.

**Table View Configurations (`tableProps`)**
Extends the data grid props (e.g., AG-Grid).
- `tableId`, `tableName`: Unique identifiers for the grid.
- `columnDefs`: Array of column definitions dictating how rows are rendered. Supports standard fields, fixed widths (`width`, `flex`), and custom `cellRenderer` components for complex UI (e.g., rendering tags, action buttons, dates).
- `rowHeight`: Fixed row height in pixels.
- `noRowsOverlayComponent`: Custom component injected when the data list is empty.
- `rowSelection` ("single" | "multiple"): Allows selecting rows, enabling bulk `actions`.
- `suppressRowClickSelection`: Prevents row clicking from accidentally selecting the row if clicking action buttons instead.
- `suppressDragLeaveHidesColumns`: Prevents columns from disappearing if dragged out of bounds.
- `enableBrowserTooltips`: Integrates native tooltips for truncated texts.
- `autoAdjustColumns`: (Boolean on root config) Automatically scales grid columns to viewport widths.

**List View Configurations (`listProps`)**
For rendering cards instead of tabular data.
- `CardComponent`: The React component injected for every item in the response data array.
- `layout`: Defines the CSS Grid structure for the cards (e.g., `columns: 4`, `gap: "16px"`, `cardWidth: "1fr"`, `wrap: true`).
- `scroll`, `scrollHeight`, `minHeight`: Controls the scroll behavior constraints of the list view container.
- `className`: Custom wrapper class.

#### Triggering Refreshes

Because data fetching happens internally via the provided `api` definition, external updates (like successfully submitting an upload form or deleting a row via custom `cellRenderer`) require a dataset refresh. Utilize the `ConfigurableDashboardHandle` ref to expose the refresh APIs.

```ts
const ref = useRef<ConfigurableDashboardHandle | null>(null);

// Trigger a component refresh programmatically:
ref.current?.handleRefresh(true);
```

---

## Types & Interfaces

Key types exported to aid in strict mode implementations:

```tsx
import { 
  ConfigurableFormProps, 
  DashboardConfig, 
  ConfigurableDashboardHandle 
} from "@msbc/config-ui";
```

- `ConfigurableDashboardHandle`: Exposes inner functions like `handleRefresh(force: boolean)` for parent components.
- `DashboardConfig`: Defines the extensive JSON configuration schema for dashboard setups.
- `ConfigurableFormProps`: Wrapper enclosing the configurations, validation callbacks, and UI behaviors pertinent to dynamic forms.
