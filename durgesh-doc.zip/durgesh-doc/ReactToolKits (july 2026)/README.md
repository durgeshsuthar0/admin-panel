# React Toolkit Monorepo

Welcome to the `@msbc` React Toolkit monorepo! This monorepo provides a suite of reusable, scalable frontend utilities and components to accelerate web application development. 


## Folder Structure

app\dev-app is the development app

packages\react-tookit is the library where all components are there.

To add new component, please add folder in components. For example components\Anchor

Then import component in App and start development.

## 🚀 Getting Started

Install dependencies

We use pnpm as package manager.
If you don’t have pnpm installed, install it globally:

npm install -g pnpm

Then install project dependencies:

pnpm install

Run the application

pnpm dev

## 🔒 Branching Strategy

main → Protected, production-ready branch

develop → Protected, integration branch (features merged via PRs)

feature/* → Feature branches created from develop

## 🤝 Contributing

1) Create a new branch from develop:

    git checkout develop

    git pull origin develop

    
    git checkout -b feature/my-new-component


2) Implement your component.

3) Run pnpm build and ensure there are no errors.

4) Commit & push your branch:


    git add .
    
    git commit -m "Add MyNewComponent"
    
    git push origin feature/my-new-component


5) Open a Pull Request → develop.

## 📖 Storybook Playground

We use Storybook as a playground for all components inside react-toolkit. It allows you to explore, test, and play with component props interactively.

cd packages/react-toolkit
pnpm run storybook

📝 Writing a Story

Every component should have a corresponding *.stories.tsx file.

📂 Story Location

Place stories next to your components.

File name convention: ComponentName.stories.tsx

## Core Packages Architecture

The ecosystem consists of three primary packages designed to work synchronously:

1. **`@msbc/react-toolkit`**: The atomic foundation. Provides low-level, unstyled, and configurable primitive components (e.g., `Modal`, `Button`, `Input`).
2. **`@msbc/data-layer`**: The networking backbone. Simplifies API queries, handles token management, and exposes the `useApiRequest` hook.
3. **`@msbc/config-ui`**: The business-logic orchestration layer. Consumes `react-toolkit` and `data-layer` to produce powerful JSON-driven layouts (e.g., `ConfigurableDashboard`, `ConfigurableForm`).

---

## Putting It All Together: User Management Example

To illustrate how these packages interact, let's implement a complete **User Management Dashboard**. 
This feature will consist of:
- An API constants file (`constants.ts`)
- A data access hook (`services/useUserManagement.ts`)
- A configurable popup form to Add/Edit users (`components/UserModal.tsx`)
- A configurable dashboard to display the user list (`UserManagement.tsx`)

### 1. Define API Endpoints (`utils/constants.ts`)

First, map out the REST endpoints your hooks and configurable components will hit.

```typescript
// utils/constants.ts
export const ApiUrls = {
  users: {
    list: "/api/v1/users/",
    create: "/api/v1/users/create/",
    update: (id: string | number) => `/api/v1/users/${id}/`,
  }
};
```

### 2. Create Data Layer Hooks (`services/useUserManagement.ts`)

Leverage `@msbc/data-layer` to handle the transactional logic (Create / Update). For the GET (List) logic, our `ConfigurableDashboard` will handle that internally, so we only need methods for mutating data here.

```typescript
// services/useUserManagement.ts
import { useApiRequest } from "@msbc/data-layer";
import { ApiUrls } from "../utils/constants";

export const useUserManagement = () => {
  // Hook for creating a new user
  const { execute: executeCreate, loading: creating, apiError: createError } = useApiRequest({
    url: ApiUrls.users.create,
    method: "post",
    autoFetch: false,
    config: { authRequired: true },
  });

  // Hook for editing an existing user (URL is dynamic, so we leave it empty intially)
  const { execute: executeUpdate, loading: updating, apiError: updateError } = useApiRequest({
    url: "",
    method: "put",
    autoFetch: false,
    config: { authRequired: true },
  });

  const createUser = async (payload: Record<string, any>) => {
    return executeCreate({ body: payload });
  };

  const updateUser = async (id: string | number, payload: Record<string, any>) => {
    return executeUpdate({
      url: ApiUrls.users.update(id),
      body: payload
    });
  };

  return { 
    createUser, 
    updateUser, 
    loading: creating || updating, 
    error: createError || updateError 
  };
};
```

### 3. Create the Add/Edit Form (`components/UserModal.tsx`)

Next, we define the `ConfigurableForm` schema that dictates the visual layout of our inputs, and wrap it inside the `Modal` component from `react-toolkit`.

```tsx
// components/UserModal.tsx
import { useMemo } from "react";
import { ConfigurableForm, type ConfigurableFormProps } from "@msbc/config-ui";
import { Modal } from "@msbc/react-toolkit";
import { useUserManagement } from "../services/useUserManagement";

interface UserModalProps {
  show: boolean;
  onClose: () => void;
  onSuccess: () => void;
  userToEdit?: Record<string, any> | null;
}

export const UserModal = ({ show, onClose, onSuccess, userToEdit }: UserModalProps) => {
  const isEditing = Boolean(userToEdit);
  const { createUser, updateUser, loading } = useUserManagement();

  // Define the JSON schema for ConfigurableForm
  const formConfig = useMemo<ConfigurableFormProps["config"]>(() => ({
    layout: { columns: 2, gap: "16px" },
    fields: [
      {
        name: "firstName",
        type: "input",
        variant: "text",
        label: "First Name",
        placeholder: "John",
        isRequired: true,
        defaultValue: userToEdit?.firstName || "",
      },
      {
        name: "lastName",
        type: "input",
        variant: "text",
        label: "Last Name",
        placeholder: "Doe",
        isRequired: true,
        defaultValue: userToEdit?.lastName || "",
      },
      {
        name: "email",
        type: "input",
        variant: "email",
        label: "Email Address",
        placeholder: "john.doe@example.com",
        isRequired: true,
        defaultValue: userToEdit?.email || "",
      },
      {
        name: "phone",
        type: "input",
        variant: "tel",
        label: "Phone Number",
        placeholder: "+1 555-0100",
        defaultValue: userToEdit?.phone || "",
      },
      {
        name: "role",
        type: "select",
        label: "User Role",
        isRequired: true,
        defaultValue: userToEdit?.role || "user",
        options: [
          { label: "Admin", value: "admin" },
          { label: "Standard User", value: "user" },
          { label: "Guest", value: "guest" },
        ],
      }
    ]
  }), [userToEdit]);

  const handleSubmit = async (formData: Record<string, any>) => {
    try {
      if (isEditing && userToEdit?.id) {
        await updateUser(userToEdit.id, formData);
      } else {
        await createUser(formData);
      }
      onSuccess(); // Triggers a table refresh upstream
      onClose();
    } catch (err) {
      console.error("Failed to save user", err);
    }
  };

  return (
    <Modal
      show={show}
      onClose={onClose}
      title={isEditing ? "Edit User" : "Create New User"}
      size="md"
    >
      <div className="p-4">
        <ConfigurableForm
          config={formConfig}
          onSubmit={handleSubmit}
          primaryButtonProps={{
            text: isEditing ? "Save Changes" : "Create User",
            disabled: loading
          }}
        />
      </div>
    </Modal>
  );
};
```

### 4. Build the Dashboard (`UserManagement.tsx`)

Finally, we orchestrate the `ConfigurableDashboard` to render the user dataset tabularly. It handles the `api` configuration internally to fetch the list and maps out the table layout, injecting `Modal` interactions where needed.

```tsx
// pages/UserManagement.tsx
import { useMemo, useRef, useState } from "react";
import { ConfigurableDashboard, type DashboardConfig, type ConfigurableDashboardHandle } from "@msbc/config-ui";
import { UserModal } from "./components/UserModal";
import { ApiUrls } from "./utils/constants";

const UserManagement = () => {
  const dashboardRef = useRef<ConfigurableDashboardHandle | null>(null);
  
  // Modal states
  const [showModal, setShowModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<Record<string, any> | null>(null);

  const handleCreate = () => {
    setSelectedUser(null);
    setShowModal(true);
  };

  const handleEdit = (user: Record<string, any>) => {
    setSelectedUser(user);
    setShowModal(true);
  };

  // Define the JSON schema for ConfigurableDashboard
  const config = useMemo<DashboardConfig>(() => ({
    title: "User Management",
    viewMode: "table",
    enableModeSwitch: false, // Force Table view for this page
    createButtonProps: {
      text: "Add New User",
      onClick: handleCreate,
    },
    // The Dashboard uses data-layer internally to fetch and paginate records automatically
    api: {
      url: ApiUrls.users.list,
      method: "get",
      config: { authRequired: true }
    },
    tableProps: {
      tableName: "users-table",
      rowHeight: 48,
      columnDefs: [
        { field: "firstName", headerName: "First Name" },
        { field: "lastName", headerName: "Last Name" },
        { field: "email", headerName: "Email" },
        { field: "role", headerName: "Role" },
        {
          field: "actions",
          headerName: "Actions",
          width: 100,
          sortable: false,
          cellRenderer: (params: any) => (
             <button
               className="text-blue-500 hover:text-blue-700 font-medium"
               onClick={() => handleEdit(params.data)}
             >
               Edit
             </button>
          )
        }
      ]
    }
  }), []);

  return (
    <div className="user-management-page p-6">
      <ConfigurableDashboard 
        ref={dashboardRef} 
        config={config} 
      />

      {/* Render the configured Add/Edit modal */}
      {showModal && (
        <UserModal
          show={showModal}
          userToEdit={selectedUser}
          onClose={() => setShowModal(false)}
          onSuccess={() => {
            // Force the dashboard to refetch the users list to reflect the new data
            dashboardRef.current?.handleRefresh(true);
          }}
        />
      )}
    </div>
  );
};

export default UserManagement;
```

---

## The Workflow Recap

1. The developer passes a JSON configuration object to **`ConfigurableDashboard`** (`@msbc/config-ui`) to render the table.
2. `ConfigurableDashboard` uses **`Ag-Grid`** & **`react-toolkit` defaults** under the hood, fetching data directly by leveraging `useApiRequest` configurations from **`data-layer`**.
3. Upon clicking "Add" or "Edit", a **`Modal`** (`@msbc/react-toolkit`) pops up housing a **`ConfigurableForm`** (`@msbc/config-ui`).
4. Upon form submission, the custom hook created with **`useApiRequest`** (`@msbc/data-layer`) handles the payload transmission synchronously.
5. On success, `handleRefresh(true)` is utilized to seamlessly sync table state seamlessly.
