# MSBC React Starter

Create an MSBC React starter app with one command.

## Usage

```bash
npx @msbc/react-starter my-app
```

With automatic dependency installation:

```bash
npx @msbc/react-starter my-app --install
```

Using pnpm:

```bash
npx @msbc/react-starter my-app --install --pnpm
```

## Generated Stack

- React
- Vite
- TypeScript
- Tailwind CSS
- React Router
- MSBC UI/config/data packages

## Local Test Before Publishing

```bash
npm link
react-starter my-test-app
cd my-test-app
npm install
npm run dev
```

## Publish

```bash
npm login
npm publish --access public
```
