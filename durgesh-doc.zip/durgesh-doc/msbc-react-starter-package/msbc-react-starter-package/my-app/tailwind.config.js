/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['DM Sans', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
      colors: {
        brand: {
          50: '#f1e4e0',  // --color-primary-01
          100: '#ffe2d6',
          200: '#ffc293', // --color-primary-02
          300: '#ffa96b', // --color-primary-03
          400: '#ff8657', // --color-primary-04
          500: '#f17243', // --color-primary-05
          600: '#dd5e2f', // --color-primary-06
          700: '#c94a1b', // --color-primary-07
          800: '#a53b14',
          900: '#7a2a0f',
        },
      },
      transitionDuration: {
        250: '250ms',
      },
    },
  },
  plugins: [],
}