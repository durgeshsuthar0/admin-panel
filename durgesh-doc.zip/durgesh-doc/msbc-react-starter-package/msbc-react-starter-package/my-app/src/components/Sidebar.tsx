import { useState, useRef, useEffect, RefObject } from 'react'
import ReactDOM from 'react-dom'
import { NavLink, useLocation } from 'react-router-dom'
import {
  LayoutDashboard,
  Users,
  Bell,
  Settings,
  ChevronDown,
  ChevronRight,
  X,
  LogOut,
  type LucideIcon,
} from 'lucide-react'

interface NavChild {
  label: string
  id: string
  path: string
}

interface NavItemData {
  icon: LucideIcon
  label: string
  id: string
  path?: string
  children?: NavChild[]
}

interface NavSection {
  section: string
  items: NavItemData[]
}

const navItems: NavSection[] = [
  {
    section: 'MAIN',
    items: [
      { icon: LayoutDashboard, label: 'Dashboard', id: 'dashboard', path: '/' },
      { icon: LayoutDashboard, label: 'Students', id: 'students', path: '/students' },
      {
        icon: Users,
        label: 'Dropdown',
        id: 'audience',
        children: [
          { label: 'Sub Item 1', id: 'followers', path: '/followers' },
          { label: 'Sub Item 2', id: 'subscribers', path: '/subscribers' },
        ],
      },
    ],
  },
  {
    section: 'SETTINGS',
    items: [
      { icon: Bell, label: 'Notification', id: 'notification', path: '/notification' },
      {
        icon: Settings,
        label: 'Settings',
        id: 'settings',
        children: [
          { label: 'Profile', id: 'profile', path: '/profile' },
          { label: 'Security', id: 'security', path: '/security' },
        ],
      },
    ],
  },
]

interface CollapsedFlyoutProps {
  item: NavItemData
  targetRef: RefObject<HTMLElement | null>
  visible: boolean
  active: string
  onClose?: () => void
  pathForId: (id: string) => string
}

function CollapsedFlyout({ item, targetRef, visible, active: _active, onClose, pathForId }: CollapsedFlyoutProps) {
  const [pos, setPos] = useState({ top: 0, left: 0 })

  useEffect(() => {
    if (visible && targetRef.current) {
      const rect = targetRef.current.getBoundingClientRect()
      setPos({ top: rect.top, left: rect.right + 8 })
    }
  }, [visible, targetRef])

  if (!visible) return null

  return ReactDOM.createPortal(
    <div style={{ top: pos.top, left: pos.left, zIndex: 99999 }} className="fixed min-w-[160px]">
      {/* Arrow */}
      <div
        style={{ top: 14, left: -5 }}
        className="absolute w-2.5 h-2.5 bg-white dark:bg-gray-900 border-l border-t border-gray-100 dark:border-gray-700 rotate-[-45deg]"
      />
      <div className="bg-white dark:bg-gray-900 border border-gray-100 dark:border-gray-700 rounded-xl shadow-xl overflow-hidden">
        {/* Header label */}
        <div className="px-3.5 py-2.5 border-b border-gray-50 dark:border-gray-800">
          <span className="text-[11px] font-bold tracking-widest text-gray-400 dark:text-gray-500 uppercase">
            {item.label}
          </span>
        </div>
        {item.children ? (
          <ul className="py-1.5">
            {item.children.map((child) => (
              <li key={child.id}>
                <NavLink
                  to={pathForId(child.id)}
                  onClick={() => { if (onClose) onClose() }}
                  className={({ isActive }) =>
                    `w-full block text-left px-3.5 py-2 text-sm font-medium transition-colors ${isActive ? 'bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 hover:text-gray-900 dark:hover:text-white'}`
                  }
                >
                  {child.label}
                </NavLink>
              </li>
            ))}
          </ul>
        ) : (
          <NavLink
            to={pathForId(item.id)}
            onClick={() => { if (onClose) onClose() }}
            className="w-full block text-left px-3.5 py-2.5 text-sm font-medium text-gray-600 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800"
          >
            {item.label}
          </NavLink>
        )}
      </div>
    </div>,
    document.body,
  )
}

interface NavItemProps {
  item: NavItemData
  collapsed: boolean
  active: string
  expanded: Record<string, boolean>
  toggleExpand: (id: string) => void
  onClose?: () => void
  pathForId: (id: string) => string
}

function NavItem({ item, collapsed, active: _active, expanded, toggleExpand, onClose, pathForId }: NavItemProps) {
  const Icon = item.icon
  const isExpanded = expanded[item.id]
  const isParentActive = item.children?.some((c) => c.id === _active)
  const [flyoutVisible, setFlyoutVisible] = useState(false)
  const btnRef = useRef<HTMLElement>(null)
  const flyoutTimeout = useRef<ReturnType<typeof setTimeout> | null>(null)

  const showFlyout = () => {
    if (flyoutTimeout.current !== null) clearTimeout(flyoutTimeout.current)
    setFlyoutVisible(true)
  }
  const hideFlyout = () => {
    flyoutTimeout.current = setTimeout(() => setFlyoutVisible(false), 120)
  }

  useEffect(() => () => {
    if (flyoutTimeout.current !== null) clearTimeout(flyoutTimeout.current)
  }, [])

  return (
    <li className="relative">
      {!item.children ? (
        <NavLink
          ref={btnRef as RefObject<HTMLAnchorElement>}
          to={pathForId(item.id)}
          onMouseEnter={() => collapsed && showFlyout()}
          onMouseLeave={() => collapsed && hideFlyout()}
          className={({ isActive }) =>
            `sidebar-link w-full ${isActive ? 'sidebar-link-active' : 'sidebar-link-inactive'} ${collapsed ? 'justify-center px-2' : ''}`
          }
          onClick={() => { if (onClose) onClose() }}
        >
          <Icon size={18} className="shrink-0" />
          {!collapsed && <span className="flex-1 text-left">{item.label}</span>}
        </NavLink>
      ) : (
        <button
          ref={btnRef as RefObject<HTMLButtonElement>}
          onClick={() => { if (!collapsed) toggleExpand(item.id) }}
          onMouseEnter={() => collapsed && showFlyout()}
          onMouseLeave={() => collapsed && hideFlyout()}
          className={`
            sidebar-link w-full
            ${isParentActive ? 'sidebar-link-active' : 'sidebar-link-inactive'}
            ${collapsed ? 'justify-center px-2' : ''}
          `}
        >
          <Icon size={18} className="shrink-0" />
          {!collapsed && (
            <>
              <span className="flex-1 text-left">{item.label}</span>
              <span className="text-gray-400">
                {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              </span>
            </>
          )}
        </button>
      )}

      {collapsed && (
        <div onMouseEnter={showFlyout} onMouseLeave={hideFlyout}>
          <CollapsedFlyout
            item={item}
            targetRef={btnRef}
            visible={flyoutVisible}
            active={_active}
            pathForId={pathForId}
            onClose={onClose}
          />
        </div>
      )}

      {!collapsed && item.children && isExpanded && (
        <ul className="mt-0.5 ml-4 pl-4 border-l border-gray-100 dark:border-gray-800 space-y-0.5">
          {item.children.map((child) => (
            <li key={child.id}>
              <NavLink
                to={pathForId(child.id)}
                onClick={() => { if (onClose) onClose() }}
                className={({ isActive }) =>
                  `w-full block text-left px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${isActive ? 'bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400 font-semibold' : 'text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 hover:bg-gray-50 dark:hover:bg-gray-800/50'}`
                }
              >
                {child.label}
              </NavLink>
            </li>
          ))}
        </ul>
      )}
    </li>
  )
}

interface SidebarProps {
  collapsed: boolean
  onClose: () => void
  mobileOpen: boolean
}

export default function Sidebar({ collapsed, onClose, mobileOpen }: SidebarProps) {
  const location = useLocation()

  const deriveActiveFromPath = (path: string) => {
    if (!path || path === '/') return 'dashboard'
    const seg = path.replace(/^\//, '').split('/')[0]
    return seg.replace(/-([a-z])/g, (_: string, c: string) => c.toUpperCase())
  }

  const currentActive = deriveActiveFromPath(location.pathname)

  const [expanded, setExpanded] = useState<Record<string, boolean>>({
    income: true,
    audience: currentActive === 'followers' || currentActive === 'subscribers',
  })

  const toggleExpand = (id: string) =>
    setExpanded((prev) => ({ ...prev, [id]: !prev[id] }))

  useEffect(() => {
    if (currentActive === 'followers' || currentActive === 'subscribers') {
      setExpanded((prev) => ({ ...prev, audience: true }))
    }
    if (['earnings', 'refunds', 'declines', 'payouts'].includes(currentActive)) {
      setExpanded((prev) => ({ ...prev, income: true }))
    }
  }, [currentActive])

  const pathForId = (id: string): string => {
    if (!id) return '/'
    for (const { items } of navItems) {
      for (const item of items) {
        if (item.id === id && item.path) return item.path
        if (item.children) {
          const child = item.children.find((c) => c.id === id)
          if (child?.path) return child.path
        }
      }
    }
    if (id === 'dashboard') return '/'
    return `/${id.replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase()}`
  }

  const isCollapsedView = collapsed && !mobileOpen

  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-20 lg:hidden backdrop-blur-sm"
          onClick={onClose}
        />
      )}

      <aside
        className={`
          fixed top-0 left-0 h-screen z-30 flex flex-col overflow-hidden
          bg-white dark:bg-gray-950
          border-r border-gray-100 dark:border-gray-800
          transition-all duration-300 ease-in-out
          ${mobileOpen ? 'w-[260px]' : collapsed ? 'w-[68px]' : 'w-[260px]'}
          ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        {/* Logo */}
        <div
          className={`flex items-center h-16 px-4 border-b border-gray-100 dark:border-gray-800 shrink-0 ${isCollapsedView ? 'justify-center' : 'gap-3'}`}
        >
          <div className="w-8 h-8 rounded-xl bg-brand-600 flex items-center justify-center shrink-0 shadow-md shadow-brand-500/30">
            <div className="w-4 h-4 rounded-full border-2 border-white" />
          </div>
          {!isCollapsedView && (
            <span className="font-bold text-gray-900 dark:text-white text-base tracking-tight">
              Logoipsum
            </span>
          )}
          {mobileOpen && (
            <button
              onClick={onClose}
              className="ml-auto lg:hidden p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-500"
            >
              <X size={16} />
            </button>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden py-4 px-3 space-y-5">
          {navItems.map(({ section, items }) => (
            <div key={section}>
              {!isCollapsedView && (
                <p className="text-[10px] font-semibold tracking-widest text-gray-400 dark:text-gray-600 mb-2 px-3">
                  {section}
                </p>
              )}
              <ul className="space-y-0.5">
                {items.map((item) => (
                  <NavItem
                    key={item.id}
                    item={item}
                    collapsed={isCollapsedView}
                    active={currentActive}
                    expanded={expanded}
                    toggleExpand={toggleExpand}
                    onClose={onClose}
                    pathForId={pathForId}
                  />
                ))}
              </ul>
            </div>
          ))}
        </nav>

        {/* Footer */}
        {!isCollapsedView && (
          <div className="mt-auto p-4 border-t border-gray-100 dark:border-gray-800 shrink-0">
            <div className="flex items-center gap-3 p-2 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer transition-colors">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-400 to-brand-600 shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-900 dark:text-white truncate">
                  Durgesh Admin
                </p>
                <p className="text-xs text-gray-400 truncate">durgesh @example.com</p>
              </div>
              <LogOut size={14} className="text-gray-400 shrink-0" />
            </div>
          </div>
        )}
      </aside>
    </>
  )
}
