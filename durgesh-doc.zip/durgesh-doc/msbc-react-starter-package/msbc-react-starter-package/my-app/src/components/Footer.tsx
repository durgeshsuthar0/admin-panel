export default function Footer() {
  return (
    <footer className="border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-950">
      <div className="max-w-7xl mx-auto p-5 lg:p-4 text-sm text-gray-500 dark:text-gray-400 text-center">
        © 2026 Durgesh Kumar All rights reserved.
      </div>
    </footer>
  )
}
