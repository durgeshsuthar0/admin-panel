import { ThemeProvider } from './context/ThemeContext'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './layout/Layout'
import { getRouteEntries } from './routes'
import '@msbc/config-ui/dist/index.css';
import '@msbc/react-toolkit/dist/index.css';

export default function App() {
  const entries = getRouteEntries()

  return (
    <ThemeProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Layout />}>
            {entries.map(({ path, component: C, id }) => (
              path === '/' ? (
                <Route key={id} index element={<C />} />
              ) : (
                <Route key={id} path={path.replace(/^\//, '')} element={<C />} />
              )
            ))}
            {/* 404 Page */}
            <Route path="*" element={<div className="p-8">Page not found</div>} />
          </Route>
        </Routes>
      </BrowserRouter>
    </ThemeProvider>
  )
}
