export default function Followers() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white tracking-tight">Audience Followers</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
            Review your follower count and recent follower activity.
          </p>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="card">
          <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Total Followers</p>
          <p className="text-3xl font-bold text-gray-900 dark:text-white mt-3">24,820</p>
          <p className="text-sm text-emerald-600 dark:text-emerald-400 mt-2">+14.8% growth this month</p>
        </div>
        <div className="card">
          <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">New this week</p>
          <p className="text-3xl font-bold text-gray-900 dark:text-white mt-3">1,752</p>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">Tracked across all campaigns.</p>
        </div>
        <div className="card">
          <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Active followers</p>
          <p className="text-3xl font-bold text-gray-900 dark:text-white mt-3">18,340</p>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">Engaged in the last 30 days.</p>
        </div>
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Followers</h2>
          <span className="text-sm text-gray-400 dark:text-gray-500">Updated just now</span>
        </div>
        <div className="space-y-3">
          {[
            { name: 'Ava Parker', action: 'Started following', time: '2 min ago' },
            { name: 'Leo Kim', action: 'Started following', time: '12 min ago' },
            { name: 'Mia Johnson', action: 'Started following', time: '38 min ago' },
            { name: 'Noah Smith', action: 'Started following', time: '1 hr ago' },
          ].map((item, index) => (
            <div key={index} className="flex items-center justify-between rounded-2xl border border-gray-100 dark:border-gray-800 p-4">
              <div>
                <p className="font-medium text-gray-900 dark:text-white">{item.name}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">{item.action}</p>
              </div>
              <span className="text-xs text-gray-400 dark:text-gray-500">{item.time}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
