export default function Posts() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white tracking-tight">Posts</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-0.5">
            Manage your latest posts and performance metrics.
          </p>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="card">
          <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Total Posts</p>
          <p className="text-3xl font-bold text-gray-900 dark:text-white mt-3">1,429</p>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">Includes published, drafts, and scheduled posts.</p>
        </div>
        <div className="card">
          <p className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">Engagement</p>
          <p className="text-3xl font-bold text-gray-900 dark:text-white mt-3">72.4%</p>
          <p className="text-sm text-emerald-600 dark:text-emerald-400 mt-2">Average engagement rate over the last 30 days.</p>
        </div>
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">Top Posts</h2>
          <span className="text-sm text-gray-400 dark:text-gray-500">Sorted by recent activity</span>
        </div>
        <div className="space-y-3">
          {[
            { title: 'How to scale your brand', views: '12.4k', performance: '+18%' },
            { title: 'Design trends for 2026', views: '9.8k', performance: '+12%' },
            { title: 'React & Tailwind tips', views: '8.1k', performance: '-3%' },
            { title: 'Productivity for creators', views: '7.2k', performance: '+7%' },
          ].map((post, index) => (
            <div key={index} className="flex items-center justify-between rounded-2xl border border-gray-100 dark:border-gray-800 p-4">
              <div>
                <p className="font-medium text-gray-900 dark:text-white">{post.title}</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">{post.views} views</p>
              </div>
              <div className={`text-sm font-semibold ${post.performance.startsWith('+') ? 'text-emerald-500' : 'text-rose-500'}`}>
                {post.performance}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
