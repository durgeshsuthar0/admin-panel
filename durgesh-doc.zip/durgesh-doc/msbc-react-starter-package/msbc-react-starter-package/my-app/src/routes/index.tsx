import { ComponentType } from 'react'
import Dashboard from '../pages/Dashboard'
import Followers from '../pages/Followers'
import Posts from '../pages/Posts'
import PlaceholderPage from '../pages/PlaceholderPage'

interface RouteEntry {
  label: string
  path: string
  component: ComponentType
}

interface RouteConfig {
  [key: string]: RouteEntry
}

export const routeConfig: RouteConfig = {
  dashboard: {
    label: 'Dashboard',
    path: '/',
    component: Dashboard,
  },
  followers: {
    label: 'Followers',
    path: '/followers',
    component: Followers,
  },
  subscribers: {
    label: 'Subscribers',
    path: '/subscribers',
    component: () => (
      <PlaceholderPage
        title="Subscribers"
        description="Review and manage your subscribers from this page."
      />
    ),
  },
  posts: {
    label: 'Posts',
    path: '/posts',
    component: Posts,
  },
  schedules: {
    label: 'Schedules',
    path: '/schedules',
    component: () => (
      <PlaceholderPage
        title="Schedules"
        description="Manage upcoming schedules for posts and campaigns."
      />
    ),
  },
  income: {
    label: 'Income',
    path: '/income',
    component: () => (
      <PlaceholderPage
        title="Income Overview"
        description="View your income performance and reports."
      />
    ),
  },
  earnings: {
    label: 'Earnings',
    path: '/earnings',
    component: () => (
      <PlaceholderPage
        title="Earnings"
        description="Check your earnings trends and payouts."
      />
    ),
  },
  refunds: {
    label: 'Refunds',
    path: '/refunds',
    component: () => (
      <PlaceholderPage
        title="Refunds"
        description="Track refund activity and performance."
      />
    ),
  },
  declines: {
    label: 'Declines',
    path: '/declines',
    component: () => (
      <PlaceholderPage
        title="Declines"
        description="Review declined transactions and issues."
      />
    ),
  },
  payouts: {
    label: 'Payouts',
    path: '/payouts',
    component: () => (
      <PlaceholderPage
        title="Payouts"
        description="View payout history and next disbursements."
      />
    ),
  },
  notification: {
    label: 'Notification',
    path: '/notification',
    component: () => (
      <PlaceholderPage
        title="Notification"
        description="Configure notifications and alerts."
      />
    ),
  },
  profile: {
    label: 'Profile',
    path: '/profile',
    component: () => (
      <PlaceholderPage
        title="Profile"
        description="Manage profile settings and account details."
      />
    ),
  },
  security: {
    label: 'Security',
    path: '/security',
    component: () => (
      <PlaceholderPage
        title="Security"
        description="Update security settings and authentication options."
      />
    ),
  },
}

export function getRouteComponent(routeId: string): ComponentType {
  return routeConfig[routeId]?.component ?? Dashboard
}

export function getRouteEntries(): { id: string; path: string; component: ComponentType }[] {
  return Object.keys(routeConfig).map((id) => ({
    id,
    path: routeConfig[id].path,
    component: routeConfig[id].component,
  }))
}
