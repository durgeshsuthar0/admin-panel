import { useState, useEffect, ReactNode, CSSProperties } from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'

interface MainContentProps {
  collapsed: boolean
  sidebarWidth: number
  mobileOpen: boolean
  onToggleCollapse: () => void
  onMenuOpen: () => void
  children: ReactNode
}

export default function MainContent({
  collapsed,
  sidebarWidth,
  mobileOpen,
  onToggleCollapse,
  onMenuOpen,
  children,
}: MainContentProps) {
  const [isDesktop, setIsDesktop] = useState(window.innerWidth >= 1024)

  useEffect(() => {
    const handleResize = () => setIsDesktop(window.innerWidth >= 1024)
    window.addEventListener('resize', handleResize)
    handleResize()
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  useEffect(() => {
    window.dispatchEvent(new Event('resize'))
  }, [sidebarWidth, collapsed, mobileOpen, isDesktop])

  const style: CSSProperties & { '--sidebar-left': string } = {
    paddingLeft: isDesktop ? sidebarWidth : 0,
    '--sidebar-left': isDesktop ? `${sidebarWidth}px` : '0px',
  }

  return (
    <div className="flex flex-col h-screen transition-all duration-300" style={style}>
      <Header
        collapsed={collapsed}
        onToggleCollapse={onToggleCollapse}
        onMenuOpen={onMenuOpen}
      />

      <main className="flex-1 overflow-y-auto pt-16">
        <div className="mx-auto p-5 lg:p-7 h-full">
          {children}
        </div>
      </main>

      <Footer />
    </div>
  )
}
