import { useState, useEffect } from 'react'
import Sidebar from '../components/Sidebar'
import MainContent from './MainContent'
import { Outlet } from 'react-router-dom'

export default function Layout() {
  const [collapsed, setCollapsed] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  const sidebarWidth = collapsed ? 68 : 260

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) setMobileOpen(false)
    }
    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-950 transition-colors duration-300">
      <Sidebar
        collapsed={collapsed}
        mobileOpen={mobileOpen}
        onClose={() => setMobileOpen(false)}
      />

      <MainContent
        collapsed={collapsed}
        sidebarWidth={sidebarWidth}
        mobileOpen={mobileOpen}
        onToggleCollapse={() => setCollapsed((c) => !c)}
        onMenuOpen={() => setMobileOpen(true)}
      >
        <Outlet />
      </MainContent>
    </div>
  )
}
