import {
  Mail,
  MapPin,
  Phone,
} from "lucide-react";

import { Link } from "react-router-dom";

const InstagramIcon = ({ size = 20, className = "" }) => {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  );
};


export default function Footer() {
  return (
    <footer className="mt-20 bg-ink text-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="inline-flex rounded-2xl bg-white p-3">
            <img src="/driftix-logo.png" className="h-10 w-auto" />
          </div>
          <p className="mt-5 max-w-md text-sm leading-7 text-slate-300">
            Custom clothing for every you. Design your own T-shirts, shirts,
            hoodies and team apparel with a distinctly Driftix experience.
          </p>
        </div>
        <div>
          <h3 className="font-bold">Explore</h3>
          <div className="mt-4 grid gap-3 text-sm text-slate-300">
            <Link to="/shop">Shop all</Link>
            <Link to="/customize">Customize</Link>
            <Link to="/about">About Driftix</Link>
            <Link to="/contact">Contact</Link>
          </div>
        </div>
        <div>
          <h3 className="font-bold">Connect</h3>
          <div className="mt-4 grid gap-3 text-sm text-slate-300">
            <span className="flex gap-2">
              <MapPin className="h-4" />
              Ahmedabad, Gujarat
            </span>
            <span className="flex gap-2">
              <Phone className="h-4" />
              +91 90000 00000
            </span>
            <span className="flex gap-2">
              <Mail className="h-4" />
              hello@driftix.in
            </span>
            {/* <span className="flex gap-2">
              <InstagramIcon size={20} />
              @driftix
            </span> */}
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 px-5 py-5 text-center text-xs text-slate-400">
        © 2026 Driftix. Wear Your Ideas.
      </div>
    </footer>
  );
}
