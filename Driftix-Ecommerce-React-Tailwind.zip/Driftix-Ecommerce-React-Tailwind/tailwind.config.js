/** @type {import('tailwindcss').Config} */
export default {
  content:['./index.html','./src/**/*.{js,jsx}'],
  theme:{extend:{colors:{brand:{50:'#fff7f2',100:'#ffeadf',200:'#ffd2bb',300:'#ffae88',400:'#ff7c4a',500:'#ff5a16',600:'#ef3f08',700:'#c52d08',800:'#9d250e',900:'#7e2110'},ink:'#071226'},boxShadow:{soft:'0 20px 60px rgba(15,23,42,.08)',glow:'0 16px 50px rgba(255,90,22,.24)'},borderRadius:{'4xl':'2rem'}}},
  plugins:[]
}
