# Driftix E-commerce Frontend

A fully responsive React + Tailwind CSS e-commerce starter for Driftix.

## Included
- Modern light-theme home page and unique Driftix visual language
- Product listing with categories, sorting and search
- Product details with size, color and optional custom print text
- Wishlist
- Cart with quantity controls and order totals
- Checkout with address form
- COD flow fully usable in demo
- UPI / Card / Prepaid payment options prepared as UI placeholders (no gateway connected)
- Login / signup demo using localStorage
- Account dashboard and locally stored order history
- Customization studio demo
- About and contact pages
- Responsive mobile navigation
- Driftix logo from the supplied asset

## Run
```bash
npm install
npm run dev
```

Build:
```bash
npm run build
npm run preview
```

## Important integration points
This package is a frontend-first working prototype. Replace localStorage auth/orders with your real API when the backend is ready. Connect payment buttons to Razorpay, Stripe, Cashfree, PayU, etc. later. Product images currently use Unsplash URLs and should be replaced with your Driftix product photography.
