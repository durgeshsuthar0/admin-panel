import React, { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, Grid3X3, LayoutList, X, ChevronDown } from 'lucide-react';
import { products, categories } from '../data/products';
import ProductCard from '../components/ProductCard';

const sortOptions = [
  { label: 'Relevance', value: 'relevance' },
  { label: 'Price: Low to High', value: 'price-asc' },
  { label: 'Price: High to Low', value: 'price-desc' },
  { label: 'Highest Rated', value: 'rating' },
  { label: 'Most Reviews', value: 'reviews' },
  { label: 'Discount', value: 'discount' },
];

const Products = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [sort, setSort] = useState('relevance');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000]);
  const [gridCols, setGridCols] = useState<3 | 4>(4);

  const categoryParam = searchParams.get('category') || 'All';
  const searchQuery = searchParams.get('search') || '';

  const filtered = useMemo(() => {
    let result = [...products];
    if (categoryParam !== 'All' && categoryParam !== 'null') {
      result = result.filter(p => p.category === categoryParam);
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.tags.some(t => t.includes(q))
      );
    }
    result = result.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);

    switch (sort) {
      case 'price-asc': return result.sort((a, b) => a.price - b.price);
      case 'price-desc': return result.sort((a, b) => b.price - a.price);
      case 'rating': return result.sort((a, b) => b.rating - a.rating);
      case 'reviews': return result.sort((a, b) => b.reviewCount - a.reviewCount);
      case 'discount': return result.sort((a, b) => (b.discount || 0) - (a.discount || 0));
      default: return result;
    }
  }, [categoryParam, searchQuery, sort, priceRange]);

  const setCategory = (cat: string) => {
    const params = new URLSearchParams(searchParams);
    params.set('category', cat);
    setSearchParams(params);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-surface-soft border-b border-surface-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {searchQuery ? (
            <div>
              <h1 className="font-display font-extrabold text-2xl text-ink">
                Search: <span className="text-brand-orange">"{searchQuery}"</span>
              </h1>
              <p className="text-ink-muted text-sm mt-1">{filtered.length} results found</p>
            </div>
          ) : (
            <div>
              <h1 className="font-display font-extrabold text-2xl text-ink">
                {categoryParam === 'All' || !categoryParam ? 'All Products' : categoryParam}
              </h1>
              <p className="text-ink-muted text-sm mt-1">{filtered.length} products</p>
            </div>
          )}

          {/* Category Pills */}
          <div className="flex gap-2 mt-4 flex-wrap">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setCategory(cat)}
                className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                  (categoryParam === cat || (cat === 'All' && (!categoryParam || categoryParam === 'null')))
                    ? 'bg-brand-orange text-white'
                    : 'bg-white border border-surface-border text-ink hover:border-brand-orange hover:text-brand-orange'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Controls */}
        <div className="flex items-center justify-between gap-4 mb-6">
          <button
            onClick={() => setFiltersOpen(!filtersOpen)}
            className="flex items-center gap-2 px-4 py-2.5 border border-surface-border rounded-xl text-sm font-medium text-ink hover:border-brand-orange hover:text-brand-orange transition-colors"
          >
            <SlidersHorizontal size={16} />
            Filters
          </button>

          <div className="flex items-center gap-3 ml-auto">
            {/* Grid toggle */}
            <div className="hidden md:flex border border-surface-border rounded-xl overflow-hidden">
              <button
                onClick={() => setGridCols(4)}
                className={`p-2.5 transition-colors ${gridCols === 4 ? 'bg-ink text-white' : 'text-ink-muted hover:bg-surface-mid'}`}
              >
                <Grid3X3 size={16} />
              </button>
              <button
                onClick={() => setGridCols(3)}
                className={`p-2.5 transition-colors ${gridCols === 3 ? 'bg-ink text-white' : 'text-ink-muted hover:bg-surface-mid'}`}
              >
                <LayoutList size={16} />
              </button>
            </div>

            {/* Sort */}
            <div className="relative">
              <select
                value={sort}
                onChange={e => setSort(e.target.value)}
                className="appearance-none px-4 pr-8 py-2.5 border border-surface-border rounded-xl text-sm font-medium text-ink bg-white focus:outline-none focus:border-brand-orange cursor-pointer"
              >
                {sortOptions.map(o => (
                  <option key={o.value} value={o.value}>{o.label}</option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-muted pointer-events-none" />
            </div>
          </div>
        </div>

        <div className="flex gap-6">
          {/* Sidebar Filters */}
          {filtersOpen && (
            <aside className="w-64 shrink-0">
              <div className="bg-white border border-surface-border rounded-2xl p-5 sticky top-24">
                <div className="flex items-center justify-between mb-5">
                  <h3 className="font-display font-bold text-sm">Filters</h3>
                  <button onClick={() => setFiltersOpen(false)} className="text-ink-muted hover:text-ink">
                    <X size={16} />
                  </button>
                </div>

                {/* Price Range */}
                <div className="mb-6">
                  <h4 className="font-medium text-sm text-ink mb-3">Price Range</h4>
                  <div className="space-y-2">
                    {[[0, 1000], [1000, 2000], [2000, 5000], [5000, 10000]].map(([min, max]) => (
                      <label key={`${min}-${max}`} className="flex items-center gap-2 cursor-pointer group">
                        <input
                          type="radio"
                          name="price"
                          className="accent-brand-orange"
                          checked={priceRange[0] === min && priceRange[1] === max}
                          onChange={() => setPriceRange([min, max])}
                        />
                        <span className="text-sm text-ink-muted group-hover:text-ink transition-colors">
                          ₹{min.toLocaleString()} – ₹{max.toLocaleString()}
                        </span>
                      </label>
                    ))}
                    <label className="flex items-center gap-2 cursor-pointer group">
                      <input
                        type="radio"
                        name="price"
                        className="accent-brand-orange"
                        checked={priceRange[0] === 0 && priceRange[1] === 10000}
                        onChange={() => setPriceRange([0, 10000])}
                      />
                      <span className="text-sm text-ink-muted group-hover:text-ink transition-colors">All prices</span>
                    </label>
                  </div>
                </div>

                {/* Rating */}
                <div>
                  <h4 className="font-medium text-sm text-ink mb-3">Minimum Rating</h4>
                  <div className="space-y-2">
                    {[4, 3, 2].map(r => (
                      <label key={r} className="flex items-center gap-2 cursor-pointer group">
                        <input type="radio" name="rating" className="accent-brand-orange" />
                        <span className="text-sm text-ink-muted group-hover:text-ink transition-colors">
                          {r}★ & above
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </aside>
          )}

          {/* Grid */}
          <div className="flex-1 min-w-0">
            {filtered.length === 0 ? (
              <div className="text-center py-24">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="font-display font-bold text-xl text-ink mb-2">No products found</h3>
                <p className="text-ink-muted text-sm">Try adjusting your filters or search term.</p>
              </div>
            ) : (
              <div className={`grid gap-4 lg:gap-5 grid-cols-2 ${gridCols === 4 ? 'lg:grid-cols-4' : 'lg:grid-cols-3'}`}>
                {filtered.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Products;
