import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight, Tag } from 'lucide-react';
import { useApp } from '../context/AppContext';

const Cart = () => {
  const { cart, removeFromCart, updateQuantity, cartTotal } = useApp();
  const navigate = useNavigate();

  const delivery = cartTotal >= 999 ? 0 : 99;
  const savings = cart.reduce((sum, i) => {
    const orig = i.product.originalPrice || i.product.price;
    return sum + (orig - i.product.price) * i.quantity;
  }, 0);

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-surface-soft flex items-center justify-center px-4">
        <div className="text-center">
          <div className="w-24 h-24 bg-brand-orange-pale rounded-full flex items-center justify-center mx-auto mb-6">
            <ShoppingBag size={40} className="text-brand-orange" />
          </div>
          <h2 className="font-display font-extrabold text-2xl text-ink mb-2">Your cart is empty</h2>
          <p className="text-ink-muted text-sm mb-8">Add items to get started.</p>
          <Link
            to="/products"
            className="inline-flex items-center gap-2 bg-brand-orange text-white px-8 py-3.5 rounded-2xl font-display font-semibold text-sm hover:bg-brand-orange-dark shadow-orange transition-all"
          >
            Start Shopping <ArrowRight size={16} />
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-surface-soft">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="font-display font-extrabold text-2xl text-ink mb-8">
          Shopping Cart <span className="text-ink-muted font-normal text-base">({cart.length} items)</span>
        </h1>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cart.map(item => (
              <div key={`${item.product.id}-${item.size}-${item.color}`} className="bg-white rounded-2xl border border-surface-border p-4 flex gap-4">
                <Link to={`/product/${item.product.id}`} className="shrink-0">
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-24 h-24 rounded-xl object-cover bg-surface-soft"
                    onError={e => { (e.target as HTMLImageElement).src = `https://placehold.co/96x96/F8F8FC/1A1A2E?text=Product`; }}
                  />
                </Link>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-xs text-ink-muted mb-0.5">{item.product.category}</p>
                      <Link to={`/product/${item.product.id}`} className="font-display font-semibold text-sm text-ink hover:text-brand-orange transition-colors line-clamp-2">
                        {item.product.name}
                      </Link>
                      <div className="flex gap-3 mt-1.5">
                        {item.size && <span className="text-xs text-ink-muted bg-surface-soft px-2 py-0.5 rounded-lg">Size: {item.size}</span>}
                        {item.color && <span className="text-xs text-ink-muted bg-surface-soft px-2 py-0.5 rounded-lg">Color: {item.color}</span>}
                      </div>
                    </div>
                    <button
                      onClick={() => removeFromCart(item.product.id)}
                      className="text-ink-muted hover:text-red-500 transition-colors p-1"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>

                  <div className="flex items-center justify-between mt-3">
                    {/* Quantity */}
                    <div className="flex items-center border border-surface-border rounded-xl overflow-hidden">
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                        className="w-8 h-8 flex items-center justify-center hover:bg-surface-soft transition-colors"
                      >
                        <Minus size={14} />
                      </button>
                      <span className="w-8 text-center font-display font-bold text-sm">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                        className="w-8 h-8 flex items-center justify-center hover:bg-surface-soft transition-colors"
                      >
                        <Plus size={14} />
                      </button>
                    </div>

                    {/* Price */}
                    <div className="text-right">
                      <div className="font-display font-bold text-ink">
                        ₹{(item.product.price * item.quantity).toLocaleString()}
                      </div>
                      {item.product.originalPrice && (
                        <div className="text-xs text-ink-muted line-through">
                          ₹{(item.product.originalPrice * item.quantity).toLocaleString()}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {/* Coupon */}
            <div className="bg-white rounded-2xl border border-surface-border p-4">
              <div className="flex gap-3">
                <div className="flex-1 flex items-center gap-2 bg-surface-soft border border-surface-border rounded-xl px-4 py-2.5">
                  <Tag size={16} className="text-ink-muted" />
                  <input
                    type="text"
                    placeholder="Enter coupon code"
                    className="bg-transparent flex-1 text-sm text-ink placeholder-ink-muted focus:outline-none"
                  />
                </div>
                <button className="bg-ink text-white px-5 py-2.5 rounded-xl font-display font-semibold text-sm hover:bg-ink-light transition-colors">
                  Apply
                </button>
              </div>
            </div>
          </div>

          {/* Summary */}
          <div>
            <div className="bg-white rounded-2xl border border-surface-border p-5 sticky top-24">
              <h3 className="font-display font-bold text-base text-ink mb-5">Order Summary</h3>

              <div className="space-y-3 text-sm mb-5">
                <div className="flex justify-between text-ink-muted">
                  <span>Subtotal ({cart.reduce((s, i) => s + i.quantity, 0)} items)</span>
                  <span className="font-medium text-ink">₹{cartTotal.toLocaleString()}</span>
                </div>
                {savings > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Discount</span>
                    <span className="font-medium">−₹{savings.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between text-ink-muted">
                  <span>Delivery</span>
                  <span className={`font-medium ${delivery === 0 ? 'text-green-600' : 'text-ink'}`}>
                    {delivery === 0 ? 'FREE' : `₹${delivery}`}
                  </span>
                </div>
                {delivery > 0 && (
                  <p className="text-xs text-brand-orange">
                    Add ₹{(999 - cartTotal).toLocaleString()} more for free delivery!
                  </p>
                )}
              </div>

              <div className="border-t border-surface-border pt-4 mb-5">
                <div className="flex justify-between font-display font-extrabold text-lg text-ink">
                  <span>Total</span>
                  <span>₹{(cartTotal + delivery).toLocaleString()}</span>
                </div>
                {savings > 0 && (
                  <p className="text-xs text-green-600 mt-1">You're saving ₹{savings.toLocaleString()} on this order!</p>
                )}
              </div>

              <button
                onClick={() => navigate('/checkout')}
                className="w-full bg-brand-orange text-white py-3.5 rounded-2xl font-display font-bold text-sm hover:bg-brand-orange-dark shadow-orange transition-all flex items-center justify-center gap-2"
              >
                Proceed to Checkout <ArrowRight size={16} />
              </button>

              <Link
                to="/products"
                className="w-full mt-3 border border-surface-border text-ink py-3 rounded-2xl font-display font-semibold text-sm hover:border-ink transition-colors flex items-center justify-center"
              >
                Continue Shopping
              </Link>

              <div className="mt-5 pt-4 border-t border-surface-border">
                <p className="text-xs text-ink-muted text-center mb-3">Secure checkout</p>
                <div className="flex items-center justify-center gap-2 flex-wrap">
                  {['UPI', 'CARD', 'COD', 'EMI'].map(m => (
                    <span key={m} className="text-xs bg-surface-soft border border-surface-border rounded-lg px-2 py-1 font-medium text-ink-muted">
                      {m}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
