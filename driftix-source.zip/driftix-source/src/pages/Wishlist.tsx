import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { products } from '../data/products';
import ProductCard from '../components/ProductCard';

const Wishlist = () => {
  const { wishlist } = useApp();
  const wishlisted = products.filter(p => wishlist.includes(p.id));

  return (
    <div className="min-h-screen bg-white">
      <div className="bg-surface-soft border-b border-surface-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <h1 className="font-display font-extrabold text-2xl text-ink">My Wishlist</h1>
          <p className="text-ink-muted text-sm mt-1">{wishlisted.length} saved items</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {wishlisted.length === 0 ? (
          <div className="text-center py-24">
            <div className="w-24 h-24 bg-brand-orange-pale rounded-full flex items-center justify-center mx-auto mb-6">
              <Heart size={40} className="text-brand-orange" />
            </div>
            <h2 className="font-display font-extrabold text-2xl text-ink mb-2">Nothing saved yet</h2>
            <p className="text-ink-muted text-sm mb-8">Tap the ♥ on any product to save it here.</p>
            <Link
              to="/products"
              className="inline-flex items-center gap-2 bg-brand-orange text-white px-8 py-3.5 rounded-2xl font-display font-semibold text-sm hover:bg-brand-orange-dark shadow-orange transition-all"
            >
              Start Browsing <ArrowRight size={16} />
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
            {wishlisted.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Wishlist;
