import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { User, Package, MapPin, Heart, LogOut, ChevronRight, ShoppingBag } from 'lucide-react';
import { useApp } from '../context/AppContext';

type Tab = 'profile' | 'orders' | 'addresses' | 'wishlist';

const Account = () => {
  const { user, logout, orders, wishlist } = useApp();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>('profile');

  if (!user) {
    navigate('/auth');
    return null;
  }

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const sideLinks = [
    { tab: 'profile' as Tab, icon: User, label: 'My Profile' },
    { tab: 'orders' as Tab, icon: Package, label: 'My Orders', badge: orders.length },
    { tab: 'addresses' as Tab, icon: MapPin, label: 'Addresses' },
    { tab: 'wishlist' as Tab, icon: Heart, label: 'Wishlist', badge: wishlist.length },
  ];

  const statusColors: Record<string, string> = {
    placed: 'bg-blue-100 text-blue-700',
    confirmed: 'bg-amber-100 text-amber-700',
    shipped: 'bg-purple-100 text-purple-700',
    delivered: 'bg-green-100 text-green-700',
    cancelled: 'bg-red-100 text-red-700',
  };

  return (
    <div className="min-h-screen bg-surface-soft">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="font-display font-extrabold text-2xl text-ink mb-6">My Account</h1>

        <div className="grid lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* User Card */}
            <div className="bg-white rounded-2xl border border-surface-border p-5 mb-4">
              <div className="w-16 h-16 bg-gradient-to-br from-brand-orange to-brand-orange-dark rounded-2xl flex items-center justify-center text-white text-2xl font-display font-extrabold mx-auto mb-3">
                {user.name[0].toUpperCase()}
              </div>
              <p className="font-display font-bold text-base text-ink text-center">{user.name}</p>
              <p className="text-ink-muted text-xs text-center">{user.email}</p>
            </div>

            {/* Nav */}
            <div className="bg-white rounded-2xl border border-surface-border overflow-hidden">
              {sideLinks.map(({ tab: t, icon: Icon, label, badge }) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className={`w-full flex items-center gap-3 px-4 py-3.5 text-sm font-medium transition-colors border-b border-surface-border last:border-0 ${
                    tab === t ? 'bg-brand-orange-pale text-brand-orange' : 'text-ink-muted hover:bg-surface-soft hover:text-ink'
                  }`}
                >
                  <Icon size={16} />
                  <span className="flex-1 text-left">{label}</span>
                  {badge !== undefined && badge > 0 && (
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${tab === t ? 'bg-brand-orange text-white' : 'bg-surface-mid text-ink-muted'}`}>
                      {badge}
                    </span>
                  )}
                  <ChevronRight size={14} className="opacity-40" />
                </button>
              ))}
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-3 px-4 py-3.5 text-sm font-medium text-red-500 hover:bg-red-50 transition-colors"
              >
                <LogOut size={16} />
                Sign Out
              </button>
            </div>
          </div>

          {/* Content */}
          <div className="lg:col-span-3">
            <div className="bg-white rounded-2xl border border-surface-border p-6">
              {/* Profile */}
              {tab === 'profile' && (
                <div>
                  <h2 className="font-display font-bold text-lg text-ink mb-6">Personal Info</h2>
                  <div className="grid sm:grid-cols-2 gap-5">
                    {[
                      { label: 'Full Name', value: user.name, type: 'text' },
                      { label: 'Email Address', value: user.email, type: 'email' },
                      { label: 'Phone Number', value: user.phone || '', type: 'tel', placeholder: 'Not added' },
                    ].map(f => (
                      <div key={f.label}>
                        <label className="block text-xs font-medium text-ink-muted mb-1.5">{f.label}</label>
                        <input
                          type={f.type}
                          defaultValue={f.value}
                          placeholder={f.placeholder || ''}
                          className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange transition-colors"
                        />
                      </div>
                    ))}
                  </div>
                  <button className="mt-6 bg-brand-orange text-white px-8 py-3 rounded-2xl font-display font-semibold text-sm hover:bg-brand-orange-dark shadow-orange transition-all">
                    Save Changes
                  </button>
                </div>
              )}

              {/* Orders */}
              {tab === 'orders' && (
                <div>
                  <h2 className="font-display font-bold text-lg text-ink mb-6">My Orders</h2>
                  {orders.length === 0 ? (
                    <div className="text-center py-12">
                      <ShoppingBag size={40} className="text-ink-muted mx-auto mb-3" />
                      <p className="font-display font-bold text-ink mb-1">No orders yet</p>
                      <p className="text-ink-muted text-sm mb-6">Start shopping to see your orders here.</p>
                      <Link to="/products" className="inline-flex items-center gap-2 bg-brand-orange text-white px-6 py-3 rounded-2xl font-semibold text-sm hover:bg-brand-orange-dark shadow-orange transition-all">
                        Shop Now
                      </Link>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {orders.map(order => (
                        <div key={order.id} className="border border-surface-border rounded-2xl p-4">
                          <div className="flex items-center justify-between mb-3">
                            <div>
                              <p className="font-display font-bold text-sm text-ink">{order.id}</p>
                              <p className="text-xs text-ink-muted">
                                {new Date(order.placedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
                              </p>
                            </div>
                            <div className="text-right">
                              <span className={`text-xs font-bold px-3 py-1 rounded-full capitalize ${statusColors[order.status] || 'bg-surface-mid text-ink-muted'}`}>
                                {order.status}
                              </span>
                              <p className="font-display font-extrabold text-ink text-sm mt-1">₹{order.total?.toLocaleString()}</p>
                            </div>
                          </div>
                          <div className="flex gap-2 flex-wrap">
                            {order.items.map(item => (
                              <img
                                key={item.product.id}
                                src={item.product.images[0]}
                                alt={item.product.name}
                                title={item.product.name}
                                className="w-12 h-12 rounded-xl object-cover bg-surface-soft"
                              />
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Addresses */}
              {tab === 'addresses' && (
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="font-display font-bold text-lg text-ink">Saved Addresses</h2>
                    <button className="text-sm font-semibold text-brand-orange hover:underline">+ Add New</button>
                  </div>
                  <div className="text-center py-12 text-ink-muted">
                    <MapPin size={40} className="mx-auto mb-3" />
                    <p className="font-medium">No addresses saved yet.</p>
                    <p className="text-sm">Add an address during checkout to save it here.</p>
                  </div>
                </div>
              )}

              {/* Wishlist */}
              {tab === 'wishlist' && (
                <div>
                  <h2 className="font-display font-bold text-lg text-ink mb-6">My Wishlist</h2>
                  {wishlist.length === 0 ? (
                    <div className="text-center py-12">
                      <Heart size={40} className="text-ink-muted mx-auto mb-3" />
                      <p className="font-display font-bold text-ink mb-1">Your wishlist is empty</p>
                      <p className="text-ink-muted text-sm mb-6">Save products you love.</p>
                      <Link to="/products" className="inline-flex items-center gap-2 bg-brand-orange text-white px-6 py-3 rounded-2xl font-semibold text-sm hover:bg-brand-orange-dark shadow-orange transition-all">
                        Browse Products
                      </Link>
                    </div>
                  ) : (
                    <p className="text-ink-muted text-sm">{wishlist.length} items in your wishlist. <Link to="/wishlist" className="text-brand-orange hover:underline">View Wishlist →</Link></p>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Account;
