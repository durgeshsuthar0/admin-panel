import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { MapPin, CreditCard, Smartphone, Truck, ChevronRight, Check, ArrowLeft, Banknote } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Address, Order } from '../types';

type Step = 'address' | 'payment' | 'review';

const Checkout = () => {
  const { cart, cartTotal, user, placeOrder } = useApp();
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('address');
  const [paymentMethod, setPaymentMethod] = useState<Order['paymentMethod']>('COD');
  const [address, setAddress] = useState<Address>({
    id: 'a1',
    name: user?.name || '',
    line1: '',
    line2: '',
    city: '',
    state: '',
    pincode: '',
    phone: '',
    isDefault: true,
  });

  const delivery = cartTotal >= 999 ? 0 : 99;
  const total = cartTotal + delivery;
  const steps: Step[] = ['address', 'payment', 'review'];
  const stepLabels = { address: 'Delivery Address', payment: 'Payment', review: 'Review Order' };

  const handleAddressNext = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('payment');
  };

  const handlePlaceOrder = () => {
    const order = placeOrder(address, paymentMethod);
    if (order) {
      navigate(`/order-success/${order.id}`, { state: { order } });
    }
  };

  if (cart.length === 0) {
    navigate('/cart');
    return null;
  }

  return (
    <div className="min-h-screen bg-surface-soft">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Progress */}
        <div className="flex items-center gap-0 mb-8">
          {steps.map((s, i) => (
            <React.Fragment key={s}>
              <div className={`flex items-center gap-2 ${i > 0 ? 'flex-1' : ''}`}>
                {i > 0 && (
                  <div className={`flex-1 h-0.5 mx-2 ${steps.indexOf(step) > i - 1 ? 'bg-brand-orange' : 'bg-surface-border'}`} />
                )}
                <div className={`flex items-center gap-2 ${i > 0 ? '' : ''}`}>
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                    steps.indexOf(step) > i
                      ? 'bg-green-500 text-white'
                      : step === s
                        ? 'bg-brand-orange text-white'
                        : 'bg-surface-border text-ink-muted'
                  }`}>
                    {steps.indexOf(step) > i ? <Check size={14} /> : i + 1}
                  </div>
                  <span className={`text-xs font-medium hidden sm:block ${step === s ? 'text-ink' : 'text-ink-muted'}`}>
                    {stepLabels[s]}
                  </span>
                </div>
              </div>
            </React.Fragment>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main */}
          <div className="lg:col-span-2">
            {/* Address Step */}
            {step === 'address' && (
              <div className="bg-white rounded-2xl border border-surface-border p-6">
                <div className="flex items-center gap-3 mb-6">
                  <MapPin size={20} className="text-brand-orange" />
                  <h2 className="font-display font-bold text-lg text-ink">Delivery Address</h2>
                </div>
                <form onSubmit={handleAddressNext} className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-ink-muted mb-1.5">Full Name *</label>
                      <input
                        required
                        type="text"
                        value={address.name}
                        onChange={e => setAddress(a => ({ ...a, name: e.target.value }))}
                        placeholder="Raj Kumar"
                        className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-ink-muted mb-1.5">Phone Number *</label>
                      <input
                        required
                        type="tel"
                        value={address.phone}
                        onChange={e => setAddress(a => ({ ...a, phone: e.target.value }))}
                        placeholder="+91 98765 43210"
                        className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange transition-colors"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-ink-muted mb-1.5">Address Line 1 *</label>
                    <input
                      required
                      type="text"
                      value={address.line1}
                      onChange={e => setAddress(a => ({ ...a, line1: e.target.value }))}
                      placeholder="House/Flat no., Building name, Street"
                      className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-ink-muted mb-1.5">Address Line 2</label>
                    <input
                      type="text"
                      value={address.line2}
                      onChange={e => setAddress(a => ({ ...a, line2: e.target.value }))}
                      placeholder="Area, Colony, Landmark (optional)"
                      className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange transition-colors"
                    />
                  </div>
                  <div className="grid sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-ink-muted mb-1.5">City *</label>
                      <input
                        required
                        type="text"
                        value={address.city}
                        onChange={e => setAddress(a => ({ ...a, city: e.target.value }))}
                        placeholder="Mumbai"
                        className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-ink-muted mb-1.5">State *</label>
                      <input
                        required
                        type="text"
                        value={address.state}
                        onChange={e => setAddress(a => ({ ...a, state: e.target.value }))}
                        placeholder="Maharashtra"
                        className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-ink-muted mb-1.5">PIN Code *</label>
                      <input
                        required
                        type="text"
                        value={address.pincode}
                        onChange={e => setAddress(a => ({ ...a, pincode: e.target.value }))}
                        placeholder="400001"
                        maxLength={6}
                        className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange transition-colors"
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-brand-orange text-white py-3.5 rounded-2xl font-display font-bold text-sm hover:bg-brand-orange-dark shadow-orange transition-all mt-2"
                  >
                    Continue to Payment →
                  </button>
                </form>
              </div>
            )}

            {/* Payment Step */}
            {step === 'payment' && (
              <div className="bg-white rounded-2xl border border-surface-border p-6">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <CreditCard size={20} className="text-brand-orange" />
                    <h2 className="font-display font-bold text-lg text-ink">Payment Method</h2>
                  </div>
                  <button onClick={() => setStep('address')} className="flex items-center gap-1 text-sm text-ink-muted hover:text-ink transition-colors">
                    <ArrowLeft size={14} /> Back
                  </button>
                </div>

                <div className="space-y-3">
                  {[
                    {
                      value: 'COD' as const,
                      icon: Banknote,
                      title: 'Cash on Delivery',
                      desc: 'Pay when your order arrives',
                    },
                    {
                      value: 'UPI' as const,
                      icon: Smartphone,
                      title: 'UPI',
                      desc: 'GPay, PhonePe, Paytm, BHIM & more',
                    },
                    {
                      value: 'CARD' as const,
                      icon: CreditCard,
                      title: 'Credit / Debit Card',
                      desc: 'Visa, Mastercard, RuPay',
                    },
                    {
                      value: 'PREPAID' as const,
                      icon: Truck,
                      title: 'Prepaid (Net Banking / Wallet)',
                      desc: 'Pay online via net banking or wallets',
                    },
                  ].map(opt => (
                    <label
                      key={opt.value}
                      className={`flex items-center gap-4 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                        paymentMethod === opt.value
                          ? 'border-brand-orange bg-brand-orange-pale'
                          : 'border-surface-border hover:border-surface-mid'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment"
                        value={opt.value}
                        checked={paymentMethod === opt.value}
                        onChange={() => setPaymentMethod(opt.value)}
                        className="sr-only"
                      />
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                        paymentMethod === opt.value ? 'bg-brand-orange text-white' : 'bg-surface-soft text-ink-muted'
                      }`}>
                        <opt.icon size={20} />
                      </div>
                      <div className="flex-1">
                        <div className="font-display font-semibold text-sm text-ink">{opt.title}</div>
                        <div className="text-xs text-ink-muted">{opt.desc}</div>
                      </div>
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                        paymentMethod === opt.value ? 'border-brand-orange bg-brand-orange' : 'border-surface-border'
                      }`}>
                        {paymentMethod === opt.value && <Check size={10} className="text-white" />}
                      </div>
                    </label>
                  ))}
                </div>

                {/* UPI input */}
                {paymentMethod === 'UPI' && (
                  <div className="mt-4 p-4 bg-surface-soft rounded-2xl">
                    <label className="block text-xs font-medium text-ink-muted mb-2">Enter UPI ID</label>
                    <input
                      type="text"
                      placeholder="yourname@upi"
                      className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange bg-white transition-colors"
                    />
                  </div>
                )}

                {/* Card input */}
                {paymentMethod === 'CARD' && (
                  <div className="mt-4 p-4 bg-surface-soft rounded-2xl space-y-3">
                    <div>
                      <label className="block text-xs font-medium text-ink-muted mb-2">Card Number</label>
                      <input type="text" placeholder="1234 5678 9012 3456" maxLength={19}
                        className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange bg-white transition-colors" />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-ink-muted mb-2">Expiry</label>
                        <input type="text" placeholder="MM / YY"
                          className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange bg-white transition-colors" />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-ink-muted mb-2">CVV</label>
                        <input type="password" placeholder="•••" maxLength={4}
                          className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange bg-white transition-colors" />
                      </div>
                    </div>
                  </div>
                )}

                <button
                  onClick={() => setStep('review')}
                  className="w-full bg-brand-orange text-white py-3.5 rounded-2xl font-display font-bold text-sm hover:bg-brand-orange-dark shadow-orange transition-all mt-6"
                >
                  Review Order →
                </button>
              </div>
            )}

            {/* Review Step */}
            {step === 'review' && (
              <div className="bg-white rounded-2xl border border-surface-border p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="font-display font-bold text-lg text-ink">Review Your Order</h2>
                  <button onClick={() => setStep('payment')} className="flex items-center gap-1 text-sm text-ink-muted hover:text-ink transition-colors">
                    <ArrowLeft size={14} /> Back
                  </button>
                </div>

                {/* Delivery Address */}
                <div className="p-4 bg-surface-soft rounded-2xl mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-xs font-bold text-ink uppercase tracking-wide">Delivering to</p>
                    <button onClick={() => setStep('address')} className="text-xs text-brand-orange font-semibold">Edit</button>
                  </div>
                  <p className="font-semibold text-sm text-ink">{address.name}</p>
                  <p className="text-sm text-ink-muted">{address.line1}{address.line2 ? `, ${address.line2}` : ''}</p>
                  <p className="text-sm text-ink-muted">{address.city}, {address.state} – {address.pincode}</p>
                  <p className="text-sm text-ink-muted">{address.phone}</p>
                </div>

                {/* Payment */}
                <div className="p-4 bg-surface-soft rounded-2xl mb-6">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-xs font-bold text-ink uppercase tracking-wide">Payment</p>
                    <button onClick={() => setStep('payment')} className="text-xs text-brand-orange font-semibold">Edit</button>
                  </div>
                  <p className="font-semibold text-sm text-ink">
                    {paymentMethod === 'COD' ? 'Cash on Delivery'
                      : paymentMethod === 'UPI' ? 'UPI Payment'
                      : paymentMethod === 'CARD' ? 'Credit / Debit Card'
                      : 'Prepaid (Net Banking / Wallet)'}
                  </p>
                </div>

                {/* Items */}
                <div className="space-y-3 mb-6">
                  {cart.map(item => (
                    <div key={item.product.id} className="flex gap-3 items-center">
                      <img
                        src={item.product.images[0]}
                        alt={item.product.name}
                        className="w-12 h-12 rounded-xl object-cover bg-surface-soft"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-ink line-clamp-1">{item.product.name}</p>
                        <p className="text-xs text-ink-muted">Qty: {item.quantity}{item.size ? ` · ${item.size}` : ''}</p>
                      </div>
                      <p className="font-display font-bold text-sm text-ink">₹{(item.product.price * item.quantity).toLocaleString()}</p>
                    </div>
                  ))}
                </div>

                <button
                  onClick={handlePlaceOrder}
                  className="w-full bg-brand-orange text-white py-4 rounded-2xl font-display font-extrabold text-base hover:bg-brand-orange-dark shadow-orange transition-all"
                >
                  Place Order — ₹{total.toLocaleString()}
                </button>
                <p className="text-xs text-ink-muted text-center mt-3">
                  By placing your order, you agree to Driftix's Terms of Service.
                </p>
              </div>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div>
            <div className="bg-white rounded-2xl border border-surface-border p-5 sticky top-24">
              <h3 className="font-display font-bold text-sm text-ink mb-4">Order Summary</h3>
              <div className="space-y-3 max-h-64 overflow-y-auto mb-4 scrollbar-hide">
                {cart.map(item => (
                  <div key={item.product.id} className="flex gap-3 items-center">
                    <img src={item.product.images[0]} alt={item.product.name}
                      className="w-12 h-12 rounded-xl object-cover bg-surface-soft shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-ink line-clamp-2">{item.product.name}</p>
                      <p className="text-xs text-ink-muted">×{item.quantity}</p>
                    </div>
                    <p className="text-xs font-bold text-ink shrink-0">₹{(item.product.price * item.quantity).toLocaleString()}</p>
                  </div>
                ))}
              </div>
              <div className="border-t border-surface-border pt-4 space-y-2 text-sm">
                <div className="flex justify-between text-ink-muted">
                  <span>Subtotal</span><span>₹{cartTotal.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-ink-muted">
                  <span>Delivery</span>
                  <span className={delivery === 0 ? 'text-green-600 font-medium' : ''}>{delivery === 0 ? 'FREE' : `₹${delivery}`}</span>
                </div>
                <div className="flex justify-between font-display font-extrabold text-base text-ink pt-2 border-t border-surface-border">
                  <span>Total</span><span>₹{total.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
