import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Heart, ShoppingCart, Zap, Star, Shield, Truck, ArrowLeft, ChevronLeft, ChevronRight, Check, Share2 } from 'lucide-react';
import { getProductById, products } from '../data/products';
import { useApp } from '../context/AppContext';
import ProductCard from '../components/ProductCard';

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const product = getProductById(id || '');
  const { addToCart, toggleWishlist, isWishlisted } = useApp();

  const [imgIdx, setImgIdx] = useState(0);
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [tab, setTab] = useState<'desc' | 'features' | 'reviews'>('desc');
  const [addedFeedback, setAddedFeedback] = useState(false);

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">😕</div>
          <h2 className="font-display font-bold text-2xl text-ink mb-2">Product not found</h2>
          <Link to="/products" className="text-brand-orange hover:underline">Back to shop</Link>
        </div>
      </div>
    );
  }

  const wishlisted = isWishlisted(product.id);
  const related = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);

  const handleAddToCart = () => {
    addToCart(product, quantity, selectedSize, selectedColor);
    setAddedFeedback(true);
    setTimeout(() => setAddedFeedback(false), 2000);
  };

  const handleBuyNow = () => {
    addToCart(product, quantity, selectedSize, selectedColor);
    navigate('/cart');
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Breadcrumb */}
      <div className="bg-surface-soft border-b border-surface-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <nav className="flex items-center gap-2 text-xs text-ink-muted">
            <Link to="/" className="hover:text-ink transition-colors">Home</Link>
            <span>/</span>
            <Link to="/products" className="hover:text-ink transition-colors">Shop</Link>
            <span>/</span>
            <Link to={`/products?category=${product.category}`} className="hover:text-ink transition-colors">{product.category}</Link>
            <span>/</span>
            <span className="text-ink font-medium">{product.name}</span>
          </nav>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-ink-muted hover:text-ink text-sm mb-6 transition-colors">
          <ArrowLeft size={16} /> Back
        </button>

        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16">
          {/* Images */}
          <div>
            <div className="relative rounded-3xl overflow-hidden bg-surface-soft aspect-square mb-4">
              <img
                src={product.images[imgIdx]}
                alt={product.name}
                className="w-full h-full object-cover"
                onError={e => { (e.target as HTMLImageElement).src = `https://placehold.co/600x600/F8F8FC/1A1A2E?text=${encodeURIComponent(product.name)}`; }}
              />
              {product.images.length > 1 && (
                <>
                  <button
                    onClick={() => setImgIdx(i => (i - 1 + product.images.length) % product.images.length)}
                    className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 rounded-full flex items-center justify-center shadow-card hover:bg-white transition-colors"
                  >
                    <ChevronLeft size={18} />
                  </button>
                  <button
                    onClick={() => setImgIdx(i => (i + 1) % product.images.length)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 rounded-full flex items-center justify-center shadow-card hover:bg-white transition-colors"
                  >
                    <ChevronRight size={18} />
                  </button>
                </>
              )}
              {/* Badges */}
              <div className="absolute top-4 left-4 flex flex-col gap-2">
                {product.discount && (
                  <span className="bg-brand-orange text-white text-sm font-bold px-3 py-1 rounded-xl">-{product.discount}%</span>
                )}
                {product.isNew && <span className="bg-ink text-white text-sm font-bold px-3 py-1 rounded-xl">NEW</span>}
              </div>
            </div>

            {/* Thumbnails */}
            <div className="flex gap-3">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setImgIdx(i)}
                  className={`w-16 h-16 rounded-xl overflow-hidden border-2 transition-colors ${
                    i === imgIdx ? 'border-brand-orange' : 'border-surface-border hover:border-brand-orange-light'
                  }`}
                >
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Details */}
          <div>
            <p className="text-brand-orange text-xs font-bold uppercase tracking-widest mb-2">{product.category}</p>
            <h1 className="font-display font-extrabold text-2xl lg:text-3xl text-ink mb-3">{product.name}</h1>

            {/* Rating */}
            <div className="flex items-center gap-3 mb-5">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} className={i < Math.floor(product.rating) ? 'text-amber-400 fill-amber-400' : 'text-surface-border'} />
                ))}
              </div>
              <span className="font-semibold text-sm text-ink">{product.rating}</span>
              <span className="text-ink-muted text-sm">({product.reviewCount.toLocaleString()} reviews)</span>
            </div>

            {/* Price */}
            <div className="flex items-center gap-4 mb-6 pb-6 border-b border-surface-border">
              <span className="font-display font-extrabold text-4xl text-ink">₹{product.price.toLocaleString()}</span>
              {product.originalPrice && (
                <>
                  <span className="text-ink-muted line-through text-lg">₹{product.originalPrice.toLocaleString()}</span>
                  <span className="bg-green-100 text-green-700 text-sm font-bold px-2 py-0.5 rounded-lg">
                    Save ₹{(product.originalPrice - product.price).toLocaleString()}
                  </span>
                </>
              )}
            </div>

            {/* Colors */}
            {product.colors && (
              <div className="mb-5">
                <p className="font-medium text-sm text-ink mb-2.5">
                  Color: <span className="text-ink-muted">{selectedColor || 'Select a color'}</span>
                </p>
                <div className="flex gap-2">
                  {product.colors.map(c => (
                    <button
                      key={c.name}
                      title={c.name}
                      onClick={() => setSelectedColor(c.name)}
                      className={`w-8 h-8 rounded-full border-2 transition-all ${
                        selectedColor === c.name ? 'border-brand-orange scale-110' : 'border-surface-border hover:border-ink-muted'
                      }`}
                      style={{ backgroundColor: c.hex }}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Sizes */}
            {product.sizes && (
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2.5">
                  <p className="font-medium text-sm text-ink">
                    Size: <span className="text-ink-muted">{selectedSize || 'Select size'}</span>
                  </p>
                  <button className="text-brand-orange text-xs font-semibold hover:underline">Size guide</button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map(s => (
                    <button
                      key={s}
                      onClick={() => setSelectedSize(s)}
                      className={`min-w-[3rem] px-3 py-2 rounded-xl text-sm font-medium border transition-all ${
                        selectedSize === s
                          ? 'bg-ink text-white border-ink'
                          : 'border-surface-border text-ink hover:border-ink transition-colors'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity */}
            <div className="flex items-center gap-3 mb-6">
              <p className="font-medium text-sm text-ink">Qty:</p>
              <div className="flex items-center border border-surface-border rounded-xl overflow-hidden">
                <button
                  onClick={() => setQuantity(q => Math.max(1, q - 1))}
                  className="w-10 h-10 flex items-center justify-center text-ink hover:bg-surface-soft transition-colors font-bold"
                >−</button>
                <span className="w-12 text-center font-display font-bold text-sm">{quantity}</span>
                <button
                  onClick={() => setQuantity(q => q + 1)}
                  className="w-10 h-10 flex items-center justify-center text-ink hover:bg-surface-soft transition-colors font-bold"
                >+</button>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-3 mb-6">
              <button
                onClick={handleAddToCart}
                className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl font-display font-semibold text-sm transition-all ${
                  addedFeedback
                    ? 'bg-green-500 text-white'
                    : 'bg-brand-orange-pale text-brand-orange hover:bg-brand-orange hover:text-white'
                }`}
              >
                {addedFeedback ? <><Check size={18} /> Added to Cart!</> : <><ShoppingCart size={18} /> Add to Cart</>}
              </button>
              <button
                onClick={handleBuyNow}
                className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl font-display font-semibold text-sm bg-ink text-white hover:bg-ink-light transition-all shadow-lg"
              >
                <Zap size={18} /> Buy Now
              </button>
              <button
                onClick={() => toggleWishlist(product.id)}
                className={`w-12 h-12 flex items-center justify-center rounded-2xl border-2 transition-all ${
                  wishlisted ? 'border-brand-orange bg-brand-orange-pale text-brand-orange' : 'border-surface-border text-ink hover:border-brand-orange'
                }`}
              >
                <Heart size={18} fill={wishlisted ? 'currentColor' : 'none'} />
              </button>
            </div>

            {/* Delivery info */}
            <div className="bg-surface-soft rounded-2xl p-4 space-y-3">
              {[
                { icon: Truck, text: 'Free delivery on orders above ₹999' },
                { icon: Shield, text: '30-day easy returns & exchange' },
                { icon: Zap, text: 'Usually dispatched within 24 hours' },
              ].map(({ icon: Icon, text }) => (
                <div key={text} className="flex items-center gap-3 text-sm text-ink-muted">
                  <Icon size={16} className="text-brand-orange shrink-0" />
                  {text}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-14">
          <div className="flex gap-1 border-b border-surface-border mb-8">
            {(['desc', 'features', 'reviews'] as const).map(t => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`px-6 py-3 font-display font-semibold text-sm capitalize transition-colors border-b-2 -mb-px ${
                  tab === t ? 'text-brand-orange border-brand-orange' : 'text-ink-muted border-transparent hover:text-ink'
                }`}
              >
                {t === 'desc' ? 'Description' : t === 'features' ? 'Features' : 'Reviews'}
              </button>
            ))}
          </div>

          {tab === 'desc' && (
            <div className="max-w-2xl">
              <p className="text-ink-muted leading-relaxed">{product.description}</p>
            </div>
          )}
          {tab === 'features' && (
            <ul className="space-y-3 max-w-lg">
              {product.features.map(f => (
                <li key={f} className="flex items-center gap-3 text-sm text-ink">
                  <div className="w-5 h-5 bg-brand-orange-pale rounded-full flex items-center justify-center shrink-0">
                    <Check size={12} className="text-brand-orange" />
                  </div>
                  {f}
                </li>
              ))}
            </ul>
          )}
          {tab === 'reviews' && (
            <div className="max-w-2xl space-y-4">
              {[
                { name: 'Arjun M.', rating: 5, text: 'Absolutely love it! Quality is top-notch and fits perfectly.', date: '3 days ago' },
                { name: 'Priya S.', rating: 4, text: 'Great product, exactly as described. Fast delivery too!', date: '1 week ago' },
                { name: 'Rahul K.', rating: 5, text: 'Best purchase this year. Will definitely buy again.', date: '2 weeks ago' },
              ].map((r, i) => (
                <div key={i} className="border border-surface-border rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 bg-ink rounded-full flex items-center justify-center text-white text-sm font-bold">
                        {r.name[0]}
                      </div>
                      <div>
                        <div className="font-display font-semibold text-sm text-ink">{r.name}</div>
                        <div className="flex gap-0.5 mt-0.5">
                          {[...Array(5)].map((_, j) => (
                            <Star key={j} size={10} className={j < r.rating ? 'text-amber-400 fill-amber-400' : 'text-surface-border'} />
                          ))}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs text-ink-muted">{r.date}</span>
                  </div>
                  <p className="text-sm text-ink-muted">{r.text}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Related Products */}
        {related.length > 0 && (
          <div className="mt-16">
            <h3 className="font-display font-extrabold text-2xl text-ink mb-6">You may also like</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
              {related.map(p => <ProductCard key={p.id} product={p} />)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductDetail;
