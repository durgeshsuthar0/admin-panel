import React, { useState } from 'react';
import { Mail, Phone, MapPin, MessageSquare, Clock, Send, Check } from 'lucide-react';

const Contact = () => {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 4000);
    setForm({ name: '', email: '', subject: '', message: '' });
  };

  const contacts = [
    { icon: Mail, title: 'Email Us', value: 'support@driftix.in', sub: 'We reply within 24 hours' },
    { icon: Phone, title: 'Call Us', value: '+91 98765 43210', sub: 'Mon–Sat, 10am – 7pm IST' },
    { icon: MapPin, title: 'Visit Us', value: 'Bandra West, Mumbai', sub: 'Maharashtra 400050, India' },
    { icon: Clock, title: 'Support Hours', value: 'Mon – Sat', sub: '10:00 AM – 7:00 PM IST' },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-ink text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <span className="text-brand-orange text-xs font-bold uppercase tracking-widest mb-3 block">Get in Touch</span>
          <h1 className="font-display font-extrabold text-4xl lg:text-5xl text-white mb-4">We're here to help.</h1>
          <p className="text-white/60 text-lg max-w-md mx-auto">Have a question, concern, or just want to say hello? We'd love to hear from you.</p>
        </div>
      </div>

      {/* Contact Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {contacts.map(c => (
            <div key={c.title} className="bg-white rounded-2xl border border-surface-border shadow-card p-5 text-center">
              <div className="w-12 h-12 bg-brand-orange-pale rounded-2xl flex items-center justify-center mx-auto mb-3">
                <c.icon size={20} className="text-brand-orange" />
              </div>
              <p className="font-display font-bold text-sm text-ink mb-1">{c.title}</p>
              <p className="text-ink text-xs font-medium">{c.value}</p>
              <p className="text-ink-muted text-xs">{c.sub}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Form + FAQ */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Form */}
          <div>
            <h2 className="font-display font-extrabold text-2xl text-ink mb-6">Send us a message</h2>

            {sent && (
              <div className="bg-green-50 border border-green-200 rounded-2xl p-4 flex items-center gap-3 mb-6">
                <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center shrink-0">
                  <Check size={16} className="text-white" />
                </div>
                <div>
                  <p className="font-display font-semibold text-green-800 text-sm">Message sent!</p>
                  <p className="text-green-600 text-xs">We'll get back to you within 24 hours.</p>
                </div>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-ink-muted mb-1.5">Your Name *</label>
                  <input
                    required
                    type="text"
                    value={form.name}
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                    placeholder="Raj Kumar"
                    className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-ink-muted mb-1.5">Email Address *</label>
                  <input
                    required
                    type="email"
                    value={form.email}
                    onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                    placeholder="raj@email.com"
                    className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange transition-colors"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-ink-muted mb-1.5">Subject *</label>
                <select
                  required
                  value={form.subject}
                  onChange={e => setForm(f => ({ ...f, subject: e.target.value }))}
                  className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange transition-colors bg-white text-ink"
                >
                  <option value="">Select a topic</option>
                  <option>Order Issue</option>
                  <option>Product Question</option>
                  <option>Return / Exchange</option>
                  <option>Delivery Tracking</option>
                  <option>Payment Issue</option>
                  <option>Feedback / Suggestion</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-ink-muted mb-1.5">Message *</label>
                <textarea
                  required
                  rows={5}
                  value={form.message}
                  onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                  placeholder="Tell us how we can help you..."
                  className="w-full px-4 py-3 border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange transition-colors resize-none"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-brand-orange text-white py-3.5 rounded-2xl font-display font-bold text-sm hover:bg-brand-orange-dark shadow-orange transition-all flex items-center justify-center gap-2"
              >
                <Send size={16} /> Send Message
              </button>
            </form>
          </div>

          {/* FAQ */}
          <div>
            <h2 className="font-display font-extrabold text-2xl text-ink mb-6">Common Questions</h2>
            <div className="space-y-4">
              {[
                {
                  q: 'How long does delivery take?',
                  a: 'Most orders are delivered within 3–5 business days across India. Metro cities typically receive orders in 1–2 business days.',
                },
                {
                  q: 'What is your return policy?',
                  a: 'We offer 30-day hassle-free returns on all products. Items must be unused, in original packaging. Initiate a return from your account page.',
                },
                {
                  q: 'Do you offer Cash on Delivery?',
                  a: 'Yes! COD is available on all orders across India. You can also pay via UPI, credit/debit card, or net banking.',
                },
                {
                  q: 'How do I track my order?',
                  a: 'Once your order ships, you\'ll receive a tracking link via email and SMS. You can also track from the "My Orders" section in your account.',
                },
                {
                  q: 'Are all products genuine?',
                  a: 'Absolutely. Every Driftix product is 100% authentic, sourced and quality-checked directly by our team. We stand behind every item we sell.',
                },
              ].map((faq, i) => (
                <details key={i} className="group border border-surface-border rounded-2xl overflow-hidden">
                  <summary className="flex items-center justify-between px-5 py-4 cursor-pointer font-display font-semibold text-sm text-ink hover:text-brand-orange transition-colors list-none">
                    {faq.q}
                    <span className="text-brand-orange text-lg font-bold group-open:rotate-45 transition-transform">+</span>
                  </summary>
                  <div className="px-5 pb-4 text-sm text-ink-muted leading-relaxed">{faq.a}</div>
                </details>
              ))}
            </div>

            <div className="mt-8 bg-brand-orange-pale border border-brand-orange/20 rounded-2xl p-5">
              <div className="flex items-start gap-3">
                <MessageSquare size={20} className="text-brand-orange shrink-0 mt-0.5" />
                <div>
                  <p className="font-display font-bold text-sm text-ink mb-1">Still have questions?</p>
                  <p className="text-ink-muted text-xs leading-relaxed">
                    Our support team is available Mon–Sat, 10am–7pm IST. Average response time: under 4 hours.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
