import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Zap, Shield, Heart, Globe } from 'lucide-react';

const About = () => {
  const values = [
    { icon: Zap, title: 'Built to Perform', desc: 'Every product goes through rigorous testing before it reaches you. We don\'t cut corners.' },
    { icon: Shield, title: 'Made to Last', desc: 'Quality over everything. We use premium materials so your gear lasts as long as your ambitions.' },
    { icon: Heart, title: 'Community First', desc: 'Driftix is built by movers, for movers. Your feedback shapes what we build next.' },
    { icon: Globe, title: 'Conscious Design', desc: 'We\'re committed to reducing our environmental footprint with every collection.' },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className="bg-ink text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-brand-orange text-xs font-bold uppercase tracking-widest mb-4 block">Our Story</span>
              <h1 className="font-display font-extrabold text-4xl lg:text-6xl text-white leading-tight mb-6">
                Gear built for<br />
                <span className="text-brand-orange">relentless</span><br />
                motion.
              </h1>
              <p className="text-white/60 text-lg leading-relaxed max-w-md">
                Driftix started in 2022 with a simple belief: gear should move with you, not hold you back. We design products for the pace of modern life.
              </p>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=700&q=80"
                alt="Driftix team"
                className="w-full rounded-3xl object-cover aspect-square opacity-80"
                onError={e => { (e.target as HTMLImageElement).src = 'https://placehold.co/600x600/1A1A2E/E84D0E?text=Driftix'; }}
              />
              {/* Floating stat */}
              <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-card-hover p-4">
                <div className="font-display font-extrabold text-3xl text-ink">50K+</div>
                <div className="text-ink-muted text-sm">happy movers</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="border-b border-surface-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { value: '2022', label: 'Founded' },
              { value: '50K+', label: 'Happy Customers' },
              { value: '200+', label: 'Products' },
              { value: '4.9★', label: 'Average Rating' },
            ].map(s => (
              <div key={s.label} className="text-center">
                <div className="font-display font-extrabold text-4xl text-ink mb-1">{s.value}</div>
                <div className="text-ink-muted text-sm">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <img
              src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=700&q=80"
              alt="Driftix product"
              className="w-full rounded-3xl object-cover aspect-video"
              onError={e => { (e.target as HTMLImageElement).src = 'https://placehold.co/700x400/F8F8FC/1A1A2E?text=Driftix'; }}
            />
          </div>
          <div>
            <span className="text-brand-orange text-xs font-bold uppercase tracking-widest mb-4 block">Mission</span>
            <h2 className="font-display font-extrabold text-3xl lg:text-4xl text-ink mb-6">
              We exist to make premium gear accessible.
            </h2>
            <p className="text-ink-muted leading-relaxed mb-5">
              For too long, high-quality performance gear has been out of reach for most people. Driftix is our answer to that: thoughtfully designed, rigorously tested, and priced fairly.
            </p>
            <p className="text-ink-muted leading-relaxed mb-8">
              From runners to remote workers, gym-goers to globe-trotters, we design gear that meets you where you are and grows with you as you push further.
            </p>
            <Link
              to="/products"
              className="inline-flex items-center gap-2 bg-brand-orange text-white px-8 py-3.5 rounded-2xl font-display font-semibold text-sm hover:bg-brand-orange-dark shadow-orange transition-all"
            >
              Shop the Collection <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="bg-surface-soft py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-brand-orange text-xs font-bold uppercase tracking-widest mb-3 block">What We Stand For</span>
            <h2 className="font-display font-extrabold text-3xl lg:text-4xl text-ink">Our values</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map(v => (
              <div key={v.title} className="bg-white rounded-2xl border border-surface-border p-6 hover:shadow-card-hover transition-shadow">
                <div className="w-12 h-12 bg-brand-orange-pale rounded-2xl flex items-center justify-center mb-4">
                  <v.icon size={22} className="text-brand-orange" />
                </div>
                <h3 className="font-display font-bold text-base text-ink mb-2">{v.title}</h3>
                <p className="text-ink-muted text-sm leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="bg-gradient-to-br from-brand-orange to-brand-orange-dark rounded-3xl p-10 lg:p-16 text-center text-white">
          <h2 className="font-display font-extrabold text-3xl lg:text-4xl mb-4">Ready to start moving?</h2>
          <p className="text-white/80 text-lg mb-8 max-w-md mx-auto">Explore our full collection and find your next favourite piece of gear.</p>
          <Link
            to="/products"
            className="inline-flex items-center gap-2 bg-white text-brand-orange px-10 py-4 rounded-2xl font-display font-extrabold text-base hover:bg-brand-orange-pale transition-all shadow-lg"
          >
            Shop Now <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default About;
