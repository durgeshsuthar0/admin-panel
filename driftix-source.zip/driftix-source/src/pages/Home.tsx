import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Zap, Shield, RotateCcw, Truck, ChevronLeft, ChevronRight } from 'lucide-react';
import { products } from '../data/products';
import ProductCard from '../components/ProductCard';
import { LOGO_ICON } from '../assets/logos';

const heroSlides = [
  {
    tag: 'New Drop — Fall 2026',
    headline: 'Move Without\nLimits.',
    sub: 'Premium gear engineered for every pace of your life. Street to summit, office to gym.',
    cta: 'Shop the Collection',
    ctaLink: '/products',
    bg: 'from-[#FFF0EB] to-[#FFE5D9]',
    accent: 'bg-brand-orange',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=700&q=80',
    stat1: '50K+', stat1Label: 'happy movers',
    stat2: '4.9★', stat2Label: 'avg. rating',
  },
  {
    tag: 'Limited Stock',
    headline: 'Gear That\nKeeps Up.',
    sub: 'From trail to track, Driftix is built for relentless pursuit. Performance meets style.',
    cta: 'Explore Gear',
    ctaLink: '/products?category=Electronics',
    bg: 'from-[#EBF0FF] to-[#E0E9FF]',
    accent: 'bg-blue-600',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=700&q=80',
    stat1: '200+', stat1Label: 'product styles',
    stat2: '48hr', stat2Label: 'fast delivery',
  },
];

const categoryCards = [
  { name: 'Footwear', image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80', count: 24 },
  { name: 'Clothing', image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400&q=80', count: 38 },
  { name: 'Bags', image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&q=80', count: 16 },
  { name: 'Electronics', image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&q=80', count: 12 },
  { name: 'Accessories', image: 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=400&q=80', count: 30 },
];

const Home = () => {
  const [slide, setSlide] = useState(0);
  const trending = products.filter(p => p.isTrending);
  const newArrivals = products.filter(p => p.isNew);

  useEffect(() => {
    const t = setInterval(() => setSlide(s => (s + 1) % heroSlides.length), 5000);
    return () => clearInterval(t);
  }, []);

  const current = heroSlides[slide];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className={`bg-gradient-to-br ${current.bg} transition-all duration-700`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className={`inline-block ${current.accent} text-white text-xs font-bold px-3 py-1.5 rounded-full mb-6 tracking-wide uppercase`}>
                {current.tag}
              </span>
              <h1 className="font-display font-extrabold text-5xl sm:text-6xl lg:text-7xl text-ink leading-[1.05] tracking-tight mb-6 whitespace-pre-line">
                {current.headline}
              </h1>
              <p className="text-ink-muted text-lg leading-relaxed mb-8 max-w-md">
                {current.sub}
              </p>
              <div className="flex items-center gap-4 mb-10">
                <Link
                  to={current.ctaLink}
                  className="inline-flex items-center gap-2 bg-ink text-white px-7 py-3.5 rounded-2xl font-display font-semibold text-sm hover:bg-ink-light transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5"
                >
                  {current.cta} <ArrowRight size={16} />
                </Link>
                <Link
                  to="/about"
                  className="inline-flex items-center gap-2 text-ink font-display font-semibold text-sm hover:text-brand-orange transition-colors"
                >
                  Our story
                </Link>
              </div>
              {/* Stats */}
              <div className="flex items-center gap-8">
                <div>
                  <div className="font-display font-extrabold text-2xl text-ink">{current.stat1}</div>
                  <div className="text-ink-muted text-xs">{current.stat1Label}</div>
                </div>
                <div className="w-px h-8 bg-ink/20" />
                <div>
                  <div className="font-display font-extrabold text-2xl text-ink">{current.stat2}</div>
                  <div className="text-ink-muted text-xs">{current.stat2Label}</div>
                </div>
              </div>
            </div>

            {/* Hero image */}
            <div className="relative flex items-center justify-center">
              <div className="relative w-full max-w-md mx-auto">
                <div className="absolute inset-0 bg-white/30 rounded-3xl blur-xl transform scale-95" />
                <img
                  src={current.image}
                  alt="Hero product"
                  className="relative w-full aspect-square object-cover rounded-3xl shadow-2xl"
                  onError={e => { (e.target as HTMLImageElement).src = `https://placehold.co/500x500/E84D0E/FFFFFF?text=Driftix`; }}
                />
                {/* Floating badge */}
                <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-card p-3 flex items-center gap-3">
                  <img src={LOGO_ICON} alt="Driftix" className="w-8 h-8 object-contain" />
                  <div>
                    <div className="font-display font-bold text-sm text-ink">Premium Quality</div>
                    <div className="text-xs text-ink-muted">Verified & trusted</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Slide controls */}
          <div className="flex items-center justify-center gap-3 mt-10">
            {heroSlides.map((_, i) => (
              <button
                key={i}
                onClick={() => setSlide(i)}
                className={`transition-all duration-300 rounded-full ${
                  i === slide ? 'w-8 h-2 bg-brand-orange' : 'w-2 h-2 bg-ink/20 hover:bg-ink/40'
                }`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Trust Bar */}
      <section className="border-y border-surface-border bg-surface-soft">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { icon: Truck, text: 'Free delivery above ₹999' },
              { icon: RotateCcw, text: '30-day easy returns' },
              { icon: Shield, text: '100% authentic products' },
              { icon: Zap, text: '48-hour fast shipping' },
            ].map(({ icon: Icon, text }) => (
              <div key={text} className="flex items-center gap-3 justify-center">
                <div className="w-8 h-8 bg-brand-orange-pale rounded-lg flex items-center justify-center shrink-0">
                  <Icon size={16} className="text-brand-orange" />
                </div>
                <span className="text-xs font-medium text-ink-muted">{text}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="text-brand-orange text-xs font-bold uppercase tracking-widest mb-2">Browse</p>
            <h2 className="font-display font-extrabold text-3xl lg:text-4xl text-ink">Shop by Category</h2>
          </div>
          <Link to="/products" className="text-sm font-semibold text-ink hover:text-brand-orange transition-colors flex items-center gap-1">
            View all <ArrowRight size={14} />
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {categoryCards.map(cat => (
            <Link
              key={cat.name}
              to={`/products?category=${cat.name}`}
              className="group relative overflow-hidden rounded-2xl aspect-square bg-surface-soft hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1"
            >
              <img
                src={cat.image}
                alt={cat.name}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                onError={e => { (e.target as HTMLImageElement).src = `https://placehold.co/300x300/F8F8FC/1A1A2E?text=${cat.name}`; }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <div className="font-display font-bold text-white text-sm">{cat.name}</div>
                <div className="text-white/70 text-xs">{cat.count} items</div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Trending */}
      <section className="bg-surface-soft py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-8">
            <div>
              <p className="text-brand-orange text-xs font-bold uppercase tracking-widest mb-2">What's Hot</p>
              <h2 className="font-display font-extrabold text-3xl lg:text-4xl text-ink">Trending Now</h2>
            </div>
            <Link to="/products" className="text-sm font-semibold text-ink hover:text-brand-orange transition-colors flex items-center gap-1">
              See all <ArrowRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
            {trending.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="bg-ink rounded-3xl overflow-hidden">
          <div className="grid lg:grid-cols-2 gap-0">
            <div className="p-10 lg:p-14 flex flex-col justify-center">
              <span className="text-brand-orange text-xs font-bold uppercase tracking-widest mb-4">Driftix Promise</span>
              <h2 className="font-display font-extrabold text-3xl lg:text-4xl text-white leading-tight mb-4">
                Built different.<br />Made for you.
              </h2>
              <p className="text-white/60 text-sm leading-relaxed mb-8 max-w-sm">
                Every Driftix product is designed with the modern mover in mind. Premium materials, intentional design, obsessive quality control.
              </p>
              <Link
                to="/about"
                className="inline-flex items-center gap-2 text-white border border-white/30 hover:border-brand-orange hover:text-brand-orange px-6 py-3 rounded-xl font-semibold text-sm transition-all w-fit"
              >
                Our story <ArrowRight size={14} />
              </Link>
            </div>
            <div className="relative min-h-56 lg:min-h-0">
              <img
                src="https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=700&q=80"
                alt="Driftix lifestyle"
                className="absolute inset-0 w-full h-full object-cover opacity-60"
                onError={e => { (e.target as HTMLImageElement).src = 'https://placehold.co/600x400/1A1A2E/E84D0E?text=Driftix'; }}
              />
              <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/30 to-transparent lg:hidden" />
            </div>
          </div>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="bg-surface-soft py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-8">
            <div>
              <p className="text-brand-orange text-xs font-bold uppercase tracking-widest mb-2">Just In</p>
              <h2 className="font-display font-extrabold text-3xl lg:text-4xl text-ink">New Arrivals</h2>
            </div>
            <Link to="/products?sort=new" className="text-sm font-semibold text-ink hover:text-brand-orange transition-colors flex items-center gap-1">
              View all <ArrowRight size={14} />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
            {newArrivals.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* All Products */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-end justify-between mb-8">
          <div>
            <p className="text-brand-orange text-xs font-bold uppercase tracking-widest mb-2">Full Range</p>
            <h2 className="font-display font-extrabold text-3xl lg:text-4xl text-ink">All Products</h2>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-6">
          {products.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
        <div className="text-center mt-10">
          <Link
            to="/products"
            className="inline-flex items-center gap-2 bg-brand-orange text-white px-8 py-3.5 rounded-2xl font-display font-semibold text-sm hover:bg-brand-orange-dark shadow-orange transition-all hover:shadow-lg hover:-translate-y-0.5"
          >
            View All Products <ArrowRight size={16} />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
