import React from 'react';
import { Link, useParams, useLocation } from 'react-router-dom';
import { CheckCircle, Package, MapPin, CreditCard, ArrowRight } from 'lucide-react';

const OrderSuccess = () => {
  const { id } = useParams<{ id: string }>();
  const { state } = useLocation();
  const order = state?.order;

  const steps = [
    { label: 'Order Placed', done: true, icon: CheckCircle },
    { label: 'Confirmed', done: false, icon: Package },
    { label: 'Shipped', done: false, icon: Package },
    { label: 'Delivered', done: false, icon: Package },
  ];

  return (
    <div className="min-h-screen bg-surface-soft flex items-center justify-center px-4 py-12">
      <div className="max-w-lg w-full">
        {/* Success Card */}
        <div className="bg-white rounded-3xl border border-surface-border overflow-hidden shadow-card-hover">
          {/* Top Banner */}
          <div className="bg-gradient-to-br from-green-500 to-green-600 p-8 text-center">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <CheckCircle size={40} className="text-green-500" />
            </div>
            <h1 className="font-display font-extrabold text-2xl text-white mb-1">Order Placed!</h1>
            <p className="text-green-100 text-sm">Your Driftix gear is on its way.</p>
          </div>

          <div className="p-6">
            {/* Order ID */}
            <div className="bg-surface-soft rounded-2xl p-4 mb-5">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-ink-muted mb-0.5">Order ID</p>
                  <p className="font-display font-bold text-ink">{id || 'ORD123456'}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-ink-muted mb-0.5">Estimated Delivery</p>
                  <p className="font-display font-bold text-ink text-sm">3–5 business days</p>
                </div>
              </div>
            </div>

            {/* Tracking Steps */}
            <div className="flex items-center justify-between mb-6">
              {steps.map((s, i) => (
                <React.Fragment key={s.label}>
                  <div className="flex flex-col items-center gap-1">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      s.done ? 'bg-green-500 text-white' : 'bg-surface-border text-ink-muted'
                    }`}>
                      <s.icon size={16} />
                    </div>
                    <span className="text-[10px] text-ink-muted text-center">{s.label}</span>
                  </div>
                  {i < steps.length - 1 && (
                    <div className={`flex-1 h-0.5 mx-1 ${s.done ? 'bg-green-500' : 'bg-surface-border'}`} />
                  )}
                </React.Fragment>
              ))}
            </div>

            {/* Order Info */}
            {order && (
              <div className="space-y-3 mb-6">
                {order.address && (
                  <div className="flex gap-3 p-3 bg-surface-soft rounded-xl">
                    <MapPin size={16} className="text-brand-orange shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-semibold text-ink">{order.address.name}</p>
                      <p className="text-xs text-ink-muted">{order.address.line1}, {order.address.city}</p>
                    </div>
                  </div>
                )}
                <div className="flex gap-3 p-3 bg-surface-soft rounded-xl">
                  <CreditCard size={16} className="text-brand-orange shrink-0 mt-0.5" />
                  <div>
                    <p className="text-xs font-semibold text-ink">Payment Method</p>
                    <p className="text-xs text-ink-muted">
                      {order.paymentMethod === 'COD' ? 'Cash on Delivery'
                        : order.paymentMethod === 'UPI' ? 'UPI'
                        : order.paymentMethod === 'CARD' ? 'Card Payment'
                        : 'Prepaid'}
                    </p>
                  </div>
                </div>
                <div className="flex justify-between p-3 bg-surface-soft rounded-xl">
                  <span className="text-xs text-ink-muted">Order Total</span>
                  <span className="font-display font-extrabold text-ink">₹{order.total?.toLocaleString()}</span>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="space-y-3">
              <Link
                to="/account"
                className="flex items-center justify-center gap-2 w-full bg-ink text-white py-3.5 rounded-2xl font-display font-bold text-sm hover:bg-ink-light transition-colors"
              >
                Track Order <ArrowRight size={16} />
              </Link>
              <Link
                to="/products"
                className="flex items-center justify-center w-full border border-surface-border text-ink py-3 rounded-2xl font-display font-semibold text-sm hover:border-ink transition-colors"
              >
                Continue Shopping
              </Link>
            </div>

            <p className="text-xs text-ink-muted text-center mt-4">
              A confirmation will be sent to your registered email. Questions? <Link to="/contact" className="text-brand-orange hover:underline">Contact us</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderSuccess;
