import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Eye, EyeOff, User, Mail, Lock, Phone, ArrowRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { LOGO_ICON } from '../assets/logos';

const Auth = () => {
  const { login, signup, user } = useApp();
  const navigate = useNavigate();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [form, setForm] = useState({
    name: '', email: '', phone: '', password: '', confirmPassword: '',
  });

  if (user) { navigate('/account'); return null; }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (mode === 'signup' && form.password !== form.confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    setLoading(true);
    try {
      let ok = false;
      if (mode === 'login') {
        ok = await login(form.email, form.password);
      } else {
        ok = await signup(form.name, form.email, form.password);
      }
      if (ok) navigate('/');
      else setError('Something went wrong. Please try again.');
    } catch {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const field = (
    icon: React.ReactNode,
    name: keyof typeof form,
    type: string,
    placeholder: string
  ) => (
    <div className="relative">
      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-ink-muted">{icon}</div>
      <input
        type={name === 'password' || name === 'confirmPassword' ? (showPass ? 'text' : 'password') : type}
        value={form[name]}
        onChange={e => setForm(f => ({ ...f, [name]: e.target.value }))}
        placeholder={placeholder}
        required
        className="w-full pl-11 pr-4 py-3.5 border border-surface-border rounded-2xl text-sm focus:outline-none focus:border-brand-orange transition-colors bg-white"
      />
      {(name === 'password' || name === 'confirmPassword') && (
        <button
          type="button"
          onClick={() => setShowPass(!showPass)}
          className="absolute right-4 top-1/2 -translate-y-1/2 text-ink-muted hover:text-ink transition-colors"
        >
          {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
        </button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-surface-soft flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md">
        {/* Card */}
        <div className="bg-white rounded-3xl shadow-card-hover border border-surface-border overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-br from-ink to-ink-light p-8 text-center">
            <img src={LOGO_ICON} alt="Driftix" className="w-14 h-14 object-contain mx-auto mb-4 brightness-0 invert" />
            <h1 className="font-display font-extrabold text-2xl text-white mb-1">
              {mode === 'login' ? 'Welcome back' : 'Create account'}
            </h1>
            <p className="text-white/60 text-sm">
              {mode === 'login' ? 'Sign in to your Driftix account' : 'Join thousands of Driftix movers'}
            </p>
          </div>

          {/* Toggle */}
          <div className="flex border-b border-surface-border">
            {(['login', 'signup'] as const).map(m => (
              <button
                key={m}
                onClick={() => { setMode(m); setError(''); }}
                className={`flex-1 py-3.5 font-display font-semibold text-sm transition-colors ${
                  mode === m ? 'text-brand-orange border-b-2 border-brand-orange' : 'text-ink-muted hover:text-ink'
                }`}
              >
                {m === 'login' ? 'Sign In' : 'Sign Up'}
              </button>
            ))}
          </div>

          <div className="p-8">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-2xl px-4 py-3 mb-5">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'signup' && field(<User size={16} />, 'name', 'text', 'Your full name')}
              {field(<Mail size={16} />, 'email', 'email', 'your@email.com')}
              {mode === 'signup' && field(<Phone size={16} />, 'phone', 'tel', '+91 Phone number')}
              {field(<Lock size={16} />, 'password', 'password', 'Password')}
              {mode === 'signup' && field(<Lock size={16} />, 'confirmPassword', 'password', 'Confirm password')}

              {mode === 'login' && (
                <div className="text-right">
                  <Link to="#" className="text-xs text-brand-orange hover:underline">Forgot password?</Link>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-brand-orange text-white py-3.5 rounded-2xl font-display font-bold text-sm hover:bg-brand-orange-dark shadow-orange transition-all flex items-center justify-center gap-2 disabled:opacity-70"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    {mode === 'login' ? 'Sign In' : 'Create Account'}
                    <ArrowRight size={16} />
                  </>
                )}
              </button>
            </form>

            {/* Divider */}
            <div className="flex items-center gap-3 my-5">
              <div className="flex-1 h-px bg-surface-border" />
              <span className="text-xs text-ink-muted">or continue with</span>
              <div className="flex-1 h-px bg-surface-border" />
            </div>

            {/* Social */}
            <div className="grid grid-cols-2 gap-3">
              {['Google', 'Apple'].map(provider => (
                <button
                  key={provider}
                  type="button"
                  className="flex items-center justify-center gap-2 border border-surface-border rounded-2xl py-3 text-sm font-medium text-ink hover:border-ink transition-colors"
                >
                  <span className="text-base">{provider === 'Google' ? '🇬' : '🍎'}</span>
                  {provider}
                </button>
              ))}
            </div>

            <p className="text-center text-xs text-ink-muted mt-6">
              By continuing, you agree to Driftix's{' '}
              <Link to="#" className="text-brand-orange hover:underline">Terms</Link>
              {' '}and{' '}
              <Link to="#" className="text-brand-orange hover:underline">Privacy Policy</Link>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Auth;
