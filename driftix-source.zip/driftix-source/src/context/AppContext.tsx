import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CartItem, User, Order, Product, Address } from '../types';

interface AppContextType {
  // Cart
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, size?: string, color?: string) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartTotal: number;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  isWishlisted: (productId: string) => boolean;

  // Auth
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;

  // Orders
  orders: Order[];
  placeOrder: (address: Address, paymentMethod: Order['paymentMethod']) => Order | null;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('driftix_cart');
    return saved ? JSON.parse(saved) : [];
  });
  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('driftix_wishlist');
    return saved ? JSON.parse(saved) : [];
  });
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('driftix_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('driftix_orders');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => { localStorage.setItem('driftix_cart', JSON.stringify(cart)); }, [cart]);
  useEffect(() => { localStorage.setItem('driftix_wishlist', JSON.stringify(wishlist)); }, [wishlist]);
  useEffect(() => { if (user) localStorage.setItem('driftix_user', JSON.stringify(user)); }, [user]);
  useEffect(() => { localStorage.setItem('driftix_orders', JSON.stringify(orders)); }, [orders]);

  const addToCart = (product: Product, quantity = 1, size?: string, color?: string) => {
    setCart(prev => {
      const existing = prev.find(i => i.product.id === product.id && i.size === size && i.color === color);
      if (existing) {
        return prev.map(i =>
          i.product.id === product.id && i.size === size && i.color === color
            ? { ...i, quantity: i.quantity + quantity }
            : i
        );
      }
      return [...prev, { product, quantity, size, color }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(i => i.product.id !== productId));
  };

  const updateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) { removeFromCart(productId); return; }
    setCart(prev => prev.map(i => i.product.id === productId ? { ...i, quantity } : i));
  };

  const clearCart = () => setCart([]);

  const cartCount = cart.reduce((sum, i) => sum + i.quantity, 0);
  const cartTotal = cart.reduce((sum, i) => sum + i.product.price * i.quantity, 0);

  const toggleWishlist = (productId: string) => {
    setWishlist(prev =>
      prev.includes(productId) ? prev.filter(id => id !== productId) : [...prev, productId]
    );
  };

  const isWishlisted = (productId: string) => wishlist.includes(productId);

  const login = async (email: string, _password: string): Promise<boolean> => {
    // Simulate API call
    await new Promise(r => setTimeout(r, 800));
    const mockUser: User = {
      id: 'u1',
      name: email.split('@')[0].replace(/[^a-zA-Z]/g, ' ').trim() || 'Driftix User',
      email,
      addresses: [],
    };
    setUser(mockUser);
    return true;
  };

  const signup = async (name: string, email: string, _password: string): Promise<boolean> => {
    await new Promise(r => setTimeout(r, 800));
    const mockUser: User = {
      id: 'u' + Date.now(),
      name,
      email,
      addresses: [],
    };
    setUser(mockUser);
    return true;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('driftix_user');
  };

  const placeOrder = (address: Address, paymentMethod: Order['paymentMethod']): Order | null => {
    if (cart.length === 0) return null;
    const order: Order = {
      id: 'ORD' + Date.now(),
      items: [...cart],
      total: cartTotal,
      address,
      paymentMethod,
      status: 'placed',
      placedAt: new Date(),
    };
    setOrders(prev => [order, ...prev]);
    clearCart();
    return order;
  };

  return (
    <AppContext.Provider value={{
      cart, addToCart, removeFromCart, updateQuantity, clearCart, cartCount, cartTotal,
      wishlist, toggleWishlist, isWishlisted,
      user, login, signup, logout,
      orders, placeOrder,
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
};
