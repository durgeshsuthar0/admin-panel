import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, ArrowRight, Music, AtSign, Play } from 'lucide-react';
import { LOGO_FULL } from '../assets/logos';

const Footer = () => {
  return (
    <footer className="bg-ink text-white">
      {/* Newsletter */}
      <div className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="font-display font-bold text-2xl">Stay ahead of the drift.</h3>
              <p className="text-white/60 mt-1 text-sm">New drops, exclusive deals, early access — in your inbox.</p>
            </div>
            <form className="flex w-full lg:w-auto gap-3" onSubmit={e => e.preventDefault()}>
              <input
                type="email"
                placeholder="your@email.com"
                className="flex-1 lg:w-72 px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-sm text-white placeholder-white/40 focus:outline-none focus:border-brand-orange transition-colors"
              />
              <button
                type="submit"
                className="bg-brand-orange text-white px-6 py-3 rounded-xl font-medium text-sm hover:bg-brand-orange-light transition-colors flex items-center gap-2 whitespace-nowrap"
              >
                Subscribe <ArrowRight size={14} />
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="col-span-2 lg:col-span-1">
            <img src={LOGO_FULL} alt="Driftix" className="h-8 w-auto mb-4 brightness-0 invert" />
            <p className="text-white/50 text-sm leading-relaxed max-w-xs">
              Modern gear for modern movers. Built for the pace of your life.
            </p>
            <div className="flex items-center gap-4 mt-6">
              {[AtSign, Music, Play].map((Icon, i) => (
                <a key={i} href="#" className="w-9 h-9 bg-white/10 hover:bg-brand-orange rounded-lg flex items-center justify-center transition-colors">
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-display font-semibold text-sm mb-4">Shop</h4>
            <ul className="space-y-3">
              {['All Products', 'Footwear', 'Clothing', 'Bags', 'Accessories', 'Electronics'].map(item => (
                <li key={item}>
                  <Link to={`/products?category=${item}`} className="text-white/50 hover:text-white text-sm transition-colors">
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold text-sm mb-4">Help</h4>
            <ul className="space-y-3">
              {['My Account', 'Orders', 'Returns & Exchanges', 'Size Guide', 'Track Order', 'FAQs'].map(item => (
                <li key={item}>
                  <Link to="#" className="text-white/50 hover:text-white text-sm transition-colors">{item}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-display font-semibold text-sm mb-4">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-white/50 text-sm">
                <Mail size={14} className="mt-0.5 shrink-0" />
                support@driftix.in
              </li>
              <li className="flex items-start gap-2 text-white/50 text-sm">
                <Phone size={14} className="mt-0.5 shrink-0" />
                +91 98765 43210
              </li>
              <li className="flex items-start gap-2 text-white/50 text-sm">
                <MapPin size={14} className="mt-0.5 shrink-0" />
                Driftix HQ, Bandra West,<br />Mumbai, 400050
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/30 text-xs">© 2026 Driftix. All rights reserved.</p>
          <div className="flex items-center gap-4 text-white/30 text-xs">
            <Link to="#" className="hover:text-white transition-colors">Privacy Policy</Link>
            <Link to="#" className="hover:text-white transition-colors">Terms of Use</Link>
            <Link to="#" className="hover:text-white transition-colors">Shipping Policy</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
