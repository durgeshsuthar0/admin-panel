import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { ShoppingCart, Heart, User, Search, Menu, X, ChevronDown } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { LOGO_FULL } from '../assets/logos';

const Navbar = () => {
  const { cartCount, user, wishlist } = useApp();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => { setMenuOpen(false); setSearchOpen(false); }, [location]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?search=${encodeURIComponent(searchQuery)}`);
      setSearchQuery('');
      setSearchOpen(false);
    }
  };

  const navLinks = [
    { label: 'Shop', href: '/products' },
    { label: 'About', href: '/about' },
    { label: 'Contact', href: '/contact' },
  ];

  return (
    <>
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white shadow-card' : 'bg-white/95 backdrop-blur-md'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-18">
            {/* Logo */}
            <Link to="/" className="flex items-center shrink-0">
              <img src={LOGO_FULL} alt="Driftix" className="h-8 lg:h-10 w-auto object-contain" />
            </Link>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-8">
              {navLinks.map(link => (
                <Link
                  key={link.href}
                  to={link.href}
                  className={`font-display font-medium text-sm tracking-wide transition-colors hover:text-brand-orange ${
                    location.pathname === link.href ? 'text-brand-orange' : 'text-ink'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2">
              {/* Search */}
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className="p-2 rounded-xl hover:bg-surface-mid transition-colors"
                aria-label="Search"
              >
                <Search size={20} className="text-ink" />
              </button>

              {/* Wishlist */}
              <Link to="/wishlist" className="p-2 rounded-xl hover:bg-surface-mid transition-colors relative">
                <Heart size={20} className="text-ink" />
                {wishlist.length > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-brand-orange rounded-full text-white text-[10px] font-bold flex items-center justify-center">
                    {wishlist.length}
                  </span>
                )}
              </Link>

              {/* Cart */}
              <Link to="/cart" className="p-2 rounded-xl hover:bg-surface-mid transition-colors relative">
                <ShoppingCart size={20} className="text-ink" />
                {cartCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-brand-orange rounded-full text-white text-[10px] font-bold flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </Link>

              {/* User */}
              <Link
                to={user ? '/account' : '/auth'}
                className="hidden lg:flex items-center gap-2 ml-2 bg-ink text-white px-4 py-2 rounded-xl font-display font-medium text-sm hover:bg-ink-light transition-colors"
              >
                <User size={16} />
                {user ? user.name.split(' ')[0] : 'Login'}
              </Link>

              {/* Mobile Menu */}
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="lg:hidden p-2 rounded-xl hover:bg-surface-mid transition-colors"
              >
                {menuOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>
        </div>

        {/* Search Bar */}
        {searchOpen && (
          <div className="border-t border-surface-border bg-white px-4 sm:px-6 lg:px-8 py-3">
            <form onSubmit={handleSearch} className="max-w-2xl mx-auto flex gap-3">
              <input
                autoFocus
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search products, brands, categories..."
                className="flex-1 px-4 py-2.5 bg-surface-soft border border-surface-border rounded-xl text-sm focus:outline-none focus:border-brand-orange transition-colors"
              />
              <button
                type="submit"
                className="bg-brand-orange text-white px-6 py-2.5 rounded-xl text-sm font-medium hover:bg-brand-orange-dark transition-colors"
              >
                Search
              </button>
            </form>
          </div>
        )}

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="lg:hidden border-t border-surface-border bg-white px-4 py-4 space-y-1">
            {navLinks.map(link => (
              <Link
                key={link.href}
                to={link.href}
                className="flex items-center px-4 py-3 rounded-xl font-display font-medium text-sm text-ink hover:bg-surface-soft hover:text-brand-orange transition-colors"
              >
                {link.label}
              </Link>
            ))}
            <Link
              to={user ? '/account' : '/auth'}
              className="flex items-center gap-2 px-4 py-3 rounded-xl font-display font-medium text-sm text-ink hover:bg-surface-soft hover:text-brand-orange transition-colors"
            >
              <User size={16} />
              {user ? `My Account (${user.name.split(' ')[0]})` : 'Login / Sign Up'}
            </Link>
          </div>
        )}
      </nav>
      <div className="h-16 lg:h-18" />
    </>
  );
};

export default Navbar;
