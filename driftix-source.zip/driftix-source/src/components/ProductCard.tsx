import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Star, ShoppingCart, Eye } from 'lucide-react';
import { Product } from '../types';
import { useApp } from '../context/AppContext';

interface ProductCardProps {
  product: Product;
  variant?: 'default' | 'compact';
}

const ProductCard = ({ product, variant = 'default' }: ProductCardProps) => {
  const { addToCart, toggleWishlist, isWishlisted } = useApp();
  const [imgIdx, setImgIdx] = useState(0);
  const [addedFeedback, setAddedFeedback] = useState(false);

  const wishlisted = isWishlisted(product.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    addToCart(product, 1);
    setAddedFeedback(true);
    setTimeout(() => setAddedFeedback(false), 1500);
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    toggleWishlist(product.id);
  };

  return (
    <Link to={`/product/${product.id}`} className="group block">
      <div className="bg-white rounded-2xl overflow-hidden border border-surface-border shadow-card hover:shadow-card-hover transition-all duration-300 hover:-translate-y-1">
        {/* Image */}
        <div className="relative overflow-hidden bg-surface-soft aspect-square">
          <img
            src={product.images[imgIdx]}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            onError={e => { (e.target as HTMLImageElement).src = `https://placehold.co/400x400/F8F8FC/1A1A2E?text=${encodeURIComponent(product.name)}`; }}
          />

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            {product.discount && (
              <span className="bg-brand-orange text-white text-xs font-bold px-2 py-0.5 rounded-lg">
                -{product.discount}%
              </span>
            )}
            {product.isNew && (
              <span className="bg-ink text-white text-xs font-bold px-2 py-0.5 rounded-lg">NEW</span>
            )}
            {product.isTrending && (
              <span className="bg-amber-500 text-white text-xs font-bold px-2 py-0.5 rounded-lg">🔥 HOT</span>
            )}
          </div>

          {/* Actions overlay */}
          <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <button
              onClick={handleWishlist}
              className={`w-9 h-9 rounded-xl flex items-center justify-center shadow-card transition-colors ${
                wishlisted ? 'bg-brand-orange text-white' : 'bg-white text-ink hover:bg-brand-orange hover:text-white'
              }`}
            >
              <Heart size={16} fill={wishlisted ? 'currentColor' : 'none'} />
            </button>
            <button
              onClick={e => { e.preventDefault(); }}
              className="w-9 h-9 bg-white rounded-xl flex items-center justify-center shadow-card hover:bg-brand-orange hover:text-white text-ink transition-colors"
            >
              <Eye size={16} />
            </button>
          </div>

          {/* Image dots */}
          {product.images.length > 1 && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              {product.images.map((_, i) => (
                <button
                  key={i}
                  onClick={e => { e.preventDefault(); setImgIdx(i); }}
                  className={`w-1.5 h-1.5 rounded-full transition-colors ${i === imgIdx ? 'bg-brand-orange' : 'bg-white/70'}`}
                />
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div className="p-4">
          <p className="text-xs text-ink-muted font-medium mb-1">{product.category}</p>
          <h3 className="font-display font-semibold text-sm text-ink leading-tight line-clamp-2 mb-2">
            {product.name}
          </h3>

          {/* Rating */}
          <div className="flex items-center gap-1.5 mb-3">
            <div className="flex items-center gap-0.5">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  size={12}
                  className={i < Math.floor(product.rating) ? 'text-amber-400 fill-amber-400' : 'text-surface-border'}
                />
              ))}
            </div>
            <span className="text-xs text-ink-muted">({product.reviewCount.toLocaleString()})</span>
          </div>

          {/* Price */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="font-display font-bold text-ink text-lg">
                ₹{product.price.toLocaleString()}
              </span>
              {product.originalPrice && (
                <span className="text-xs text-ink-muted line-through">
                  ₹{product.originalPrice.toLocaleString()}
                </span>
              )}
            </div>
            <button
              onClick={handleAddToCart}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                addedFeedback
                  ? 'bg-green-500 text-white'
                  : 'bg-brand-orange-pale text-brand-orange hover:bg-brand-orange hover:text-white'
              }`}
            >
              <ShoppingCart size={14} />
              {addedFeedback ? 'Added!' : 'Add'}
            </button>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
