/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          orange: '#E84D0E',
          'orange-light': '#FF6B35',
          'orange-dark': '#C23D0A',
          'orange-pale': '#FFF0EB',
        },
        ink: {
          DEFAULT: '#1A1A2E',
          light: '#2D2D44',
          muted: '#6B6B8A',
        },
        surface: {
          DEFAULT: '#FFFFFF',
          soft: '#F8F8FC',
          mid: '#F0F0F8',
          border: '#E4E4F0',
        }
      },
      fontFamily: {
        display: ['Syne', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
      },
      borderRadius: {
        '2xl': '1rem',
        '3xl': '1.5rem',
        '4xl': '2rem',
      },
      boxShadow: {
        'card': '0 2px 20px rgba(26,26,46,0.08)',
        'card-hover': '0 8px 40px rgba(26,26,46,0.16)',
        'orange': '0 8px 32px rgba(232,77,14,0.3)',
      }
    },
  },
  plugins: [],
}
